# Arquivos da versão 2D — 2dmu

Este pacote contém somente a página 2D e os sprites que ela carrega. Não inclui o servidor Node.js nem os modelos 3D.

## Envio para GitHub
1. Extraia este ZIP.
2. No repositório `murilocastronv-coder/2dmu`, abra **Add file → Upload files**.
3. Envie `pixel.html`, `mu-spr-dkn.png`, `mu-spr-dwz.png`, `mu-spr-elf.png`, `mu-spr-sum.png` e `manifest.json` para a raiz do repositório.
4. Para publicar a página 2D como página inicial, renomeie `pixel.html` para `index.html` antes de enviar, ou configure a rota principal para servir `pixel.html`. Faça isso apenas se quiser substituir a página inicial atual.
5. O HTML referencia `icon-192.png`; renomeie `mu-app-192.png` para `icon-192.png` e envie também.

Observação: este é o pacote de interface 2D. Ele não substitui automaticamente rotas de login, banco de dados ou multiplayer do servidor existente.
