'use strict';
// Eternal Realms: servidor multiplayer autoritativo.
// Sem dependências obrigatórias: HTTP e WebSocket são implementados aqui.
// Usa PostgreSQL quando DATABASE_URL existe (Render); senão grava em data.json (desenvolvimento).
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
// Funciona com os arquivos dentro de public/ ou todos soltos na raiz do repositório.
const FLAT = !fs.existsSync(path.join(__dirname, 'public', 'index.html'));
// Procura um arquivo pelo nome exato; se não existir, usa o mais novo que comece igual (o celular renomeia downloads repetidos, ex.: "shared (1).js")
function pickFile(dir, base, ext) {
  const exact = path.join(dir, base + ext); if (fs.existsSync(exact)) return exact;
  let best = null, bt = -1;
  try { for (const f of fs.readdirSync(dir)) { const l = f.toLowerCase(); if (l.startsWith(base) && l.endsWith(ext)) { const m = fs.statSync(path.join(dir, f)).mtimeMs; if (m > bt) { bt = m; best = path.join(dir, f); } } } } catch (e) {}
  return best;
}
const SHARED_FILE = pickFile(FLAT ? __dirname : path.join(__dirname, 'public'), 'shared', '.js');
if (!SHARED_FILE) {
  let ls = []; try { ls = fs.readdirSync(__dirname); } catch (e) {}
  console.error('[ERRO FATAL] Não achei o arquivo shared.js. Ele precisa estar na raiz do repositório com esse nome exato (minúsculas, sem "(1)").');
  console.error('Arquivos que existem aqui:', ls.join(', '));
  process.exit(1);
}
if (path.basename(SHARED_FILE) !== 'shared.js') console.error('[aviso] usando', path.basename(SHARED_FILE), 'no lugar de shared.js; renomeie o arquivo no GitHub para shared.js.');
const S = require(SHARED_FILE);

const PORT = process.env.PORT || 3000;
const SECRET = process.env.SECRET || 'dev-secret-troque-em-producao';
if (process.env.NODE_ENV === 'production' && (!process.env.SECRET || process.env.SECRET.length < 32 || process.env.SECRET === 'dev-secret-troque-em-producao')) {
  console.error('[ERRO FATAL] Configure SECRET com pelo menos 32 caracteres aleatórios no ambiente de produção.');
  process.exit(1);
}
if (!process.env.SECRET) console.warn('[aviso] Defina SECRET com pelo menos 32 caracteres em produção.');
const PUB = FLAT ? __dirname : path.join(__dirname, 'public');
const MU_DATA_FILE = pickFile(PUB, 'mu-data', '.js');
let MU_D = null; try { if (MU_DATA_FILE) MU_D = require(MU_DATA_FILE); } catch (e) { console.error('[MU PvP] não foi possível carregar mu-data.js:', e.message); }
const INDEX_FILE = pickFile(PUB, 'index', '.html') || path.join(PUB, 'index.html');
const PIXEL_FILE = path.join(PUB, 'pixel.html');
const WOW_FILE = path.join(PUB, 'wow.html');
const MU_HOME = path.join(PUB, 'mu-home.html');
const HOME_FILE = fs.existsSync(MU_HOME) ? MU_HOME : fs.existsSync(PIXEL_FILE) ? PIXEL_FILE : fs.existsSync(WOW_FILE) ? WOW_FILE : INDEX_FILE; // página inicial: cliente pixel com login e criação de conta
const PUBLIC_FILES = new Set(['pixel.html', 'mu.html', 'mu-home.html', 'mu-market.html', 'mu-data.js', 'mu-i18n.js', 'shared.js', 'favicon.ico', 'MuonlineClaude.apk', 'manifest.json', 'icon-192.png', 'icon-512.png', 'wow.html', 'status.html', 'guerreiro.glb', 'mu-app.html', 'mu-app.webmanifest', 'mu-app-icon.svg', 'mu-trailer.mp4', 'mu-trailer.webm']); // no modo raiz, só estes arquivos são públicos
const now = () => Date.now();
const rand = (a, b) => a + Math.random() * (b - a);
const randi = (a, b) => Math.floor(rand(a, b + 1));
const clamp = S.clamp;
const dist = (a, b) => Math.hypot(a.x - b.x, a.z - b.z);
const r1 = v => Math.round(v * 10) / 10;
const r2 = v => Math.round(v * 100) / 100;
const log = (...a) => console.log(new Date().toISOString(), ...a);

/* =============================== BANCO DE DADOS =============================== */
const DB = (() => {
  let pool = null, mem = null, timer = null;
  const FILE = path.join(__dirname, 'data.json');
  const persist = () => { clearTimeout(timer); timer = setTimeout(() => fs.writeFile(FILE, JSON.stringify(mem), e => e && console.error(e)), 400); };
  return {
    kind: () => pool ? 'postgres' : 'arquivo',
    async init() {
      if (process.env.DATABASE_URL) {
        const { Pool } = require('pg');
        const pgConfig = {
          connectionString: process.env.DATABASE_URL,
          ssl: process.env.PGSSL === 'true' ? { rejectUnauthorized: false } : false,
          max: 8
        };
        // Keep this game's tables isolated from other applications sharing the same PostgreSQL database.
        const bootstrap = new Pool({ ...pgConfig, max: 1 });
        try {
          await bootstrap.query('CREATE SCHEMA IF NOT EXISTS muonlineclaude');
        } finally {
          await bootstrap.end();
        }
        pool = new Pool({ ...pgConfig, options: '-c search_path=muonlineclaude,public' });
        await pool.query(`CREATE TABLE IF NOT EXISTS accounts(id SERIAL PRIMARY KEY, username TEXT NOT NULL, ulow TEXT UNIQUE NOT NULL, email TEXT UNIQUE NOT NULL, pass TEXT NOT NULL, created TIMESTAMPTZ DEFAULT now());
          CREATE TABLE IF NOT EXISTS chars(id SERIAL PRIMARY KEY, account_id INT NOT NULL REFERENCES accounts(id), name TEXT NOT NULL, lname TEXT UNIQUE NOT NULL, data JSONB NOT NULL, lvl INT DEFAULT 1, pvp INT DEFAULT 0, updated TIMESTAMPTZ DEFAULT now());
          CREATE INDEX IF NOT EXISTS chars_acc ON chars(account_id);
          CREATE TABLE IF NOT EXISTS guilds(lname TEXT PRIMARY KEY, data JSONB NOT NULL);
          CREATE TABLE IF NOT EXISTS kv(key TEXT PRIMARY KEY, data JSONB NOT NULL);
          CREATE TABLE IF NOT EXISTS logs(id SERIAL PRIMARY KEY, at TIMESTAMPTZ DEFAULT now(), kind TEXT, data JSONB);`);
      } else {
        try { mem = JSON.parse(fs.readFileSync(FILE, 'utf8')); } catch (e) { mem = { seqA: 0, seqC: 0, accounts: [], chars: [], guilds: {} }; }
        if (!mem.kv) mem.kv = {};
      }
    },
    async accountByLogin(q) {
      q = q.toLowerCase();
      if (pool) return (await pool.query('SELECT * FROM accounts WHERE ulow=$1 OR email=$1 LIMIT 1', [q])).rows[0] || null;
      return mem.accounts.find(a => a.ulow === q || a.email === q) || null;
    },
    async accountById(id) {
      if (pool) return (await pool.query('SELECT * FROM accounts WHERE id=$1', [id])).rows[0] || null;
      return mem.accounts.find(a => a.id === id) || null;
    },
    async accountExists(ulow, email) {
      if (pool) { const r = await pool.query('SELECT ulow,email FROM accounts WHERE ulow=$1 OR email=$2', [ulow, email]); return r.rows; }
      return mem.accounts.filter(a => a.ulow === ulow || a.email === email);
    },
    async createAccount(username, email, pass) {
      if (pool) return (await pool.query('INSERT INTO accounts(username,ulow,email,pass) VALUES($1,$2,$3,$4) RETURNING *', [username, username.toLowerCase(), email, pass])).rows[0];
      const a = { id: ++mem.seqA, username, ulow: username.toLowerCase(), email, pass }; mem.accounts.push(a); persist(); return a;
    },
    async setPass(id, pass) {
      if (pool) { await pool.query('UPDATE accounts SET pass=$2 WHERE id=$1', [id, pass]); return; }
      const a = mem.accounts.find(x => x.id === id); if (a) { a.pass = pass; persist(); }
    },
    async countAccounts() {
      if (pool) return +(await pool.query('SELECT count(*) FROM accounts')).rows[0].count;
      return mem.accounts.length;
    },
    async countChars() {
      if (pool) return +(await pool.query('SELECT count(*) FROM chars')).rows[0].count;
      return mem.chars.length;
    },
    async charsOf(accId) {
      if (pool) return (await pool.query('SELECT id,data FROM chars WHERE account_id=$1 ORDER BY id', [accId])).rows;
      return mem.chars.filter(c => c.account_id === accId).map(c => ({ id: c.id, data: c.data }));
    },
    async charById(id) {
      if (pool) return (await pool.query('SELECT * FROM chars WHERE id=$1', [id])).rows[0] || null;
      return mem.chars.find(c => c.id === id) || null;
    },
    async nameTaken(name) {
      if (pool) return (await pool.query('SELECT 1 FROM chars WHERE lname=$1', [name.toLowerCase()])).rowCount > 0;
      return mem.chars.some(c => c.lname === name.toLowerCase());
    },
    async createChar(accId, name, data) {
      if (pool) return (await pool.query('INSERT INTO chars(account_id,name,lname,data) VALUES($1,$2,$3,$4) RETURNING id', [accId, name, name.toLowerCase(), JSON.stringify(data)])).rows[0].id;
      const c = { id: ++mem.seqC, account_id: accId, name, lname: name.toLowerCase(), data, lvl: 1, pvp: 0 }; mem.chars.push(c); persist(); return c.id;
    },
    async saveChar(id, data) {
      if (pool) return pool.query('UPDATE chars SET data=$1,lvl=$2,pvp=$3,updated=now() WHERE id=$4', [JSON.stringify(data), data.lvl, data.pvpKills || 0, id]);
      const c = mem.chars.find(x => x.id === id); if (c) { c.data = JSON.parse(JSON.stringify(data)); c.lvl = data.lvl; c.pvp = data.pvpKills || 0; persist(); }
    },
    async top(col, n) {
      if (pool) return (await pool.query(`SELECT name,data->>'cls' AS cls,lvl,pvp,COALESCE((data->>'resets')::int,0) AS resets,data->>'map' AS map,data->>'guild' AS guild FROM chars ORDER BY ${col === 'pvp' ? 'pvp DESC' : col === 'resets' ? "COALESCE((data->>'resets')::int,0) DESC, lvl DESC" : 'lvl DESC'}, id LIMIT $1`, [n])).rows;
      return mem.chars.map(c => ({ name: c.name, cls: c.data.cls, lvl: c.data.lvl, pvp: c.data.pvpKills || 0, resets: c.data.resets || 0, map: c.data.map, guild: c.data.guild }))
        .sort((a, b) => col === 'pvp' ? b.pvp - a.pvp : col === 'resets' ? (b.resets - a.resets) || (b.lvl - a.lvl) : b.lvl - a.lvl).slice(0, n);
    },
    async loadGuilds() {
      if (pool) return (await pool.query('SELECT data FROM guilds')).rows.map(r => r.data);
      return Object.values(mem.guilds);
    },
    async saveGuild(g) {
      if (pool) return pool.query('INSERT INTO guilds(lname,data) VALUES($1,$2) ON CONFLICT(lname) DO UPDATE SET data=$2', [g.name.toLowerCase(), JSON.stringify(g)]);
      mem.guilds[g.name.toLowerCase()] = g; persist();
    },
    async deleteGuild(name) {
      if (pool) return pool.query('DELETE FROM guilds WHERE lname=$1', [name.toLowerCase()]);
      delete mem.guilds[name.toLowerCase()]; persist();
    },
    async kvGet(key) {
      if (pool) { const r = await pool.query('SELECT data FROM kv WHERE key=$1', [key]); return r.rows[0] ? r.rows[0].data : null; }
      return mem.kv[key] || null;
    },
    async kvSet(key, data) {
      if (pool) return pool.query('INSERT INTO kv(key,data) VALUES($1,$2) ON CONFLICT(key) DO UPDATE SET data=$2', [key, JSON.stringify(data)]);
      mem.kv[key] = data; persist();
    },
    async kvDel(key) {
      if (pool) return pool.query('DELETE FROM kv WHERE key=$1', [key]);
      delete mem.kv[key]; persist();
    },
    async deleteChar(id) {
      if (pool) return pool.query('DELETE FROM chars WHERE id=$1', [id]);
      mem.chars = mem.chars.filter(c => c.id !== id); persist();
    },
    async kvList(prefix) {   // [{key,data}] (ranking do MU Legends)
      if (pool) return (await pool.query('SELECT key,data FROM kv WHERE key LIKE $1', [prefix.replace(/[%_]/g, '') + '%'])).rows;
      return Object.entries(mem.kv).filter(([k, v]) => k.startsWith(prefix) && v).map(([key, data]) => ({ key, data }));
    },
    async allChars() {   // [{id,name,data}] (ranking semanal; poucos milhares de personagens: ok)
      if (pool) return (await pool.query('SELECT id,name,data,account_id FROM chars')).rows;
      return mem.chars.map(c => ({ id: c.id, name: c.name, data: c.data, account_id: c.account_id }));
    },
    async allAccounts() {   // [{id,username,ulow,email}] (painel de administração)
      if (pool) return (await pool.query('SELECT id,username,ulow,email FROM accounts')).rows;
      return mem.accounts.map(a => ({ id: a.id, username: a.username, ulow: a.ulow, email: a.email }));
    },
    async logsOf(kind) {   // [{at,data}] de um tipo de registro (recuperação de itens)
      if (pool) return (await pool.query('SELECT at,data FROM logs WHERE kind=$1 ORDER BY id', [kind])).rows;
      return (mem.logs || []).filter(l => l.kind === kind);
    },
    async log(kind, data) {
      log('[log]', kind, JSON.stringify(data));
      if (pool) pool.query('INSERT INTO logs(kind,data) VALUES($1,$2)', [kind, JSON.stringify(data)]).catch(() => {});
      else if (mem) { (mem.logs = mem.logs || []).push({ at: new Date().toISOString(), kind, data }); if (mem.logs.length > 3000) mem.logs.splice(0, mem.logs.length - 3000); persist(); }
    },
  };
})();

/* =============================== AUTENTICAÇÃO =============================== */
function hashPass(p) { const salt = crypto.randomBytes(16).toString('hex'); return salt + ':' + crypto.scryptSync(p, salt, 64).toString('hex'); }
function checkPass(p, stored) {
  try { const [salt, h] = stored.split(':'); return crypto.timingSafeEqual(Buffer.from(h, 'hex'), crypto.scryptSync(p, salt, 64)); } catch (e) { return false; }
}
function sign(obj) { const b = Buffer.from(JSON.stringify(obj)).toString('base64url'); return b + '.' + crypto.createHmac('sha256', SECRET).update(b).digest('base64url'); }
function verify(tok) {
  if (typeof tok !== 'string' || tok.length > 600) return null;
  const [b, s] = tok.split('.'); if (!b || !s) return null;
  const s2 = crypto.createHmac('sha256', SECRET).update(b).digest('base64url');
  if (s.length !== s2.length || !crypto.timingSafeEqual(Buffer.from(s), Buffer.from(s2))) return null;
  try { const o = JSON.parse(Buffer.from(b, 'base64url').toString()); return o.exp > now() ? o : null; } catch (e) { return null; }
}
const makeToken = accId => sign({ a: accId, exp: now() + 30 * 864e5 });
const hits = new Map();
function limited(ip, max = 25) { const t = now(); let h = hits.get(ip); if (!h || t - h.t > 60000) { h = { t, n: 0 }; hits.set(ip, h); } return ++h.n > max; }

/* =============================== HTTP =============================== */
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css', '.json': 'application/json', '.png': 'image/png', '.svg': 'image/svg+xml', '.ico': 'image/x-icon', '.apk': 'application/vnd.android.package-archive', '.jpg': 'image/jpeg', '.webp': 'image/webp', '.glb': 'model/gltf-binary', '.mp4': 'video/mp4', '.webm': 'video/webm', '.webmanifest': 'application/manifest+json' };
function sendJson(res, code, obj) { const b = JSON.stringify(obj); res.writeHead(code, { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' }); res.end(b); }
function readBody(req) {
  return new Promise((ok, bad) => { let n = 0; const ch = []; req.on('data', d => { n += d.length; if (n > 262144) { bad(new Error('grande')); req.destroy(); } else ch.push(d); });
    req.on('end', () => { try { ok(JSON.parse(Buffer.concat(ch).toString() || '{}')); } catch (e) { bad(e); } }); req.on('error', bad); });
}
/* ===== CUPONS DE DESCONTO (loja premium e VIPs) — kv "mucoupons" = { CODIGO: { pct, on, until, max, used, opened, at, by, ann } } ===== */
async function couponAll() {
  let c = (await DB.kvGet('mucoupons')) || {}; if (!c || typeof c !== 'object') c = {};
  if (!couponAll.seeded) { couponAll.seeded = 1; if (!(await DB.kvGet('mucpseed'))) { if (!c.PROMO2026) c.PROMO2026 = { pct: 20, on: true, until: 0, max: 0, used: 0, opened: 0, at: Date.now(), by: 'sistema', ann: true }; await DB.kvSet('mucoupons', c); await DB.kvSet('mucpseed', 1); } }   // cupom PROMO2026 (20%) criado uma vez
  return c; }
async function couponGet(code) {   // cupom válido agora (ligado, dentro da validade e do limite de usos) ou null
  const k = String(code || '').trim().toUpperCase().replace(/[^A-Z0-9_-]/g, '').slice(0, 24); if (!k) return null;
  const c = (await couponAll())[k]; if (!c || c.on === false) return null; const t = Date.now();
  if (c.until && c.until < t) return null; if (c.max && (c.used | 0) >= c.max) return null; const pct = Math.max(1, Math.min(90, c.pct | 0)); return { code: k, pct };
}
async function couponMark(code, field) { try { const all = await couponAll(), c = all[code]; if (!c) return; c[field] = (c[field] | 0) + 1; await DB.kvSet('mucoupons', all); } catch (_) {} }
async function sendMail(to, subject, text) {   // e-mail pelo Resend (precisa de RESEND_API_KEY; sem ela o pedido só aparece no log)
  const key = process.env.RESEND_API_KEY || '';
  if (!key) { console.warn('[email] RESEND_API_KEY não configurada: e-mail "' + subject + '" NÃO foi enviado'); return false; }
  try { const r = await fetch((process.env.RESEND_API || 'https://api.resend.com') + '/emails', { method: 'POST', headers: { Authorization: 'Bearer ' + key, 'Content-Type': 'application/json' },
      body: JSON.stringify({ from: process.env.MAIL_FROM || 'MuOnlineClaude <onboarding@resend.dev>', to: [to], subject, text }) });
    if (!r.ok) console.error('[email] falhou', r.status, (await r.text()).slice(0, 200)); return r.ok; } catch (e) { console.error('[email] falhou:', e.message); return false; }
}
const ipOf = req => (req.headers['x-forwarded-for'] || '').split(',')[0].trim() || req.socket.remoteAddress;
let statsCache = { t: 0, accounts: 0, chars: 0 };
const wowSeen = new Map();   // presença no jogo 3D: sid -> último ping (conta quem pingou nos últimos 75 s)
const wowOnline = () => { const t = Date.now(); let n = 0, pl = 0; for (const [k, v] of wowSeen) { if (t - v.t > 45000) wowSeen.delete(k); else { n++; if (v.play) pl++; } } return { n, pl }; };
/* recorde diário de jogadores no 3D (dia pelo horário de Brasília), guardado no banco: sobrevive a deploys */
let PEAK = { days: {}, u: {} }, peakLoaded = false, peakDirty = 0;
const dayKey = () => new Date(Date.now() - 3 * 3600e3).toISOString().slice(0, 10);
async function peakTick() {
  try {
    if (!peakLoaded) { const o = await DB.kvGet('peak:wow'); if (o && o.days) PEAK = { u: {}, ...o }; peakLoaded = true; }
    const w = wowOnline(), n = Math.max(w.n, RT.count()), k = dayKey();
    const U = PEAK.u[k] || (PEAK.u[k] = []); if (U.length < 20000) for (const [sid, v] of wowSeen) if (v.play && !U.includes(sid)) { U.push(sid); peakDirty = 1; }
    if (n > (PEAK.days[k] || 0)) { PEAK.days[k] = n; peakDirty = 1; }
    if (!PEAK.days[k]) { PEAK.days[k] = 0; peakDirty = 1; }
    if (peakDirty) { peakDirty = 0; const ks = Object.keys(PEAK.days).sort(); while (ks.length > 120) { const d0 = ks.shift(); delete PEAK.days[d0]; delete PEAK.u[d0]; } await DB.kvSet('peak:wow', PEAK); }
  } catch (e) { console.error('peak', e.message); }
}
setInterval(peakTick, 20000); setTimeout(peakTick, 3000);
function peakInfo() {
  const ks = Object.keys(PEAK.days).sort(), k = dayKey(); let all = 0, allDay = '', week = 0, weekDay = '';
  for (const d of ks.slice(-7)) if (PEAK.days[d] > week) { week = PEAK.days[d]; weekDay = d; }
  for (const d of ks) if (PEAK.days[d] > all) { all = PEAK.days[d]; allDay = d; }
  return { today: PEAK.days[k] || 0, week, weekDay, all, allDay, uniq: (PEAK.u[k] || []).length, days: ks.slice(-14).map(d => [d, PEAK.days[d], (PEAK.u[d] || []).length]) };
}
async function getStats() {
  if (now() - statsCache.t > 15000) { statsCache = { t: now(), accounts: await DB.countAccounts(), chars: await DB.countChars() }; }
  return { accounts: statsCache.accounts, characters: statsCache.chars, ver: BUILD };   // público: só contas e heróis
}
async function getPrivStats() {   // só o administrador: online agora + picos
  const s = await getStats();
  let online = 0; for (const p of byChar.values()) if (p.ws) online++;
  const w = wowOnline();
  return { ...s, online, wow: Math.max(w.n, RT.count()), wowPlaying: Math.max(w.pl, RT.count()), channels: rooms.size, peak: peakInfo() };
}

/* =============================== LOJA (Stripe) ===============================
   Pagamento com dinheiro de verdade (EUR) -> cristais 💎, ingressos 🎟️ da roleta e itens premium entregues na hora.
   Os preços e o catálogo ficam no shared.js (PREM_PACKS, TICKET_PACKS, PREM). Variáveis no Render (nunca no código):
     STRIPE_SECRET_KEY      chave secreta do Stripe (sk_live_... / rk_live_... ou sk_test_... para testar)
     STRIPE_WEBHOOK_SECRET  segredo do webhook (whsec_...)
     PUBLIC_URL             endereço do site (padrão https://muonlineclaude.com)
     NOTIFY_EMAIL           e-mail que recebe aviso de cada pagamento (padrão murilocastronv@gmail.com)
     RESEND_API_KEY         (opcional) chave do resend.com para mandar esse aviso por e-mail
   Sem as duas primeiras chaves a loja fica desligada e o jogo funciona normal. */

/* =============================== PAINEL DE ADMINISTRAÇÃO (3D) ===============================
   SÓ a conta do dono: o servidor confere usuário E e-mail da conta em TODA ação (o botão escondido no jogo não é segurança).
   Variáveis opcionais no Render: ADMIN_USER (padrão murilonv) e ADMIN_EMAIL (padrão murilocastronv@gmail.com). */
const ADM_USER = (process.env.ADMIN_USER || 'murilonv').toLowerCase(), ADM_MAIL = (process.env.ADMIN_EMAIL || 'murilocastronv@gmail.com').toLowerCase();
const ADM_SIC = { arma: '🗡️', cabeca: '⛑️', peito: '🥋', pernas: '👖', anel: '💍' }, ADM_SLOTS = Object.keys(ADM_SIC);
function admItem(slot, rar, lvl, name) {   // mesma fórmula do jogo (genItem)
  lvl = Math.max(1, lvl | 0); const f = 1 + rar * .4, it = { id: 'a' + crypto.randomBytes(5).toString('hex'), slot, rar, lvl, ic: ADM_SIC[slot], name };
  if (slot === 'arma') it.atk = Math.round(2 + lvl * 1.5 * f);
  else if (slot === 'anel') { it.atk = Math.round(1 + lvl * .7 * f); it.crit = rar >= 2 ? +(.005 * rar).toFixed(3) : 0; }
  else { it.arm = Math.round(2 + lvl * 1.3 * f); it.hp = Math.round(lvl * 2.2 * f); }
  it.price = Math.round(((it.atk || 0) * 4 + (it.arm || 0) * 3 + (it.hp || 0)) * 1.1) + 3; return it;
}
async function admAuth(b, req) {
  if (limited(ipOf(req), 90)) return [null, [429, { error: 'rate' }]];
  const t = verify(b.token); if (!t) return [null, [401, { error: 'auth' }]];
  const a = await DB.accountById(t.a);
  if (!a || String(a.ulow || a.username || '').toLowerCase() !== ADM_USER || String(a.email || '').toLowerCase() !== ADM_MAIL) return [null, [403, { error: 'forbidden' }]];
  return [a, null];
}
async function admChar(name) {   // personagem pelo nome (sem diferenciar maiúsculas)
  const q = String(name || '').trim().toLowerCase(); if (!q) return null;
  const all = await DB.allChars(); const c = all.find(x => String((x.data && x.data.name) || x.name || '').toLowerCase() === q);
  return c ? await DB.charById(c.id) : null;
}
async function admEdit(row, fn) {   // altera o salvamento do personagem direto no servidor (vale também com o jogador offline)
  return RT.lock('wow:' + row.id, async () => {
    const sv = (await DB.kvGet('wow:' + row.id)) || WOW.convert(row.data); sv.inv = Array.isArray(sv.inv) ? sv.inv : []; sv.eq = sv.eq && typeof sv.eq === 'object' ? sv.eq : {};
    const r = fn(sv); sv.tv = (sv.tv | 0) + 1; sv.t = Date.now();
    await DB.kvSet('wow:' + row.id, sv); RT.setLevel(row.id, sv.lvl); RT.admReload(row.id); return r;
  });
}
const admClean = (v, n) => String(v == null ? '' : v).replace(/[\u0000-\u001f\u007f<>]/g, '').trim().slice(0, n);
async function admApi(b, req) {
  const [adm, err] = await admAuth(b, req); if (err) return err;
  const act = String(b.a || '');
  if (act === 'me') {   // o botão do painel só aparece se isto responder ok; o dono também vira Game Master (selo [GM])
    if (!(await DB.kvGet('gm:' + adm.id))) { await DB.kvSet('gm:' + adm.id, 1); RT.setGm(adm.id, true); }
    return { ok: true, user: adm.username };
  }
  if (act === 'max') {   // meu personagem: nível máximo + equipamento lendário no nível máximo + ouro e poções
    const row = await DB.charById(+b.char); if (!row || row.account_id !== adm.id) return [400, { error: 'char' }];
    await admEdit(row, sv => {
      sv.lvl = WD.LV_CAP; sv.xp = 0; sv.rest = 0; sv.gold = 999999999;
      const nm = { arma: 'Lâmina do Administrador', cabeca: 'Coroa do Administrador', peito: 'Armadura do Administrador', pernas: 'Grevas do Administrador', anel: 'Anel do Administrador' };
      for (const sl of ADM_SLOTS) sv.eq[sl] = admItem(sl, 5, WD.LV_CAP, nm[sl]);
      const p = sv.inv.find(x => x.id === 'pot'); if (p) p.n = 99; else sv.inv.push({ id: 'pot', name: 'Poção de Cura', ic: '🧪', n: 99, stack: 1, price: 6, rar: 1 });
    });
    DB.log('adm_max', { id: row.id }); return { ok: true };
  }
  if (act === 'stats') return await getPrivStats();
  if (act === 'gms') { return { list: (await DB.kvGet('gm:list')) || [] }; }
  if (act === 'announce') { const x = admClean(b.text, 120); if (!x) return [400, { error: 'empty' }]; RT.announce(x); return { ok: true }; }
  // daqui para baixo: ações em outro jogador, pelo nome do personagem
  const row = await admChar(b.name); if (!row) return [404, { error: 'noChar' }];
  const online = RT.isOnline(row.id), nm = (row.data && row.data.name) || '?';
  if (act === 'inv') {
    const sv = (await DB.kvGet('wow:' + row.id)) || WOW.convert(row.data), gm = !!(await DB.kvGet('gm:' + row.account_id));
    const sm = it => it && { id: it.id, name: it.name, rar: it.rar | 0, slot: it.slot, n: it.n | 0, lvl: it.lvl | 0, ic: it.ic };
    return { name: nm, cls: sv.cls, lvl: sv.lvl, gold: sv.gold, gm, online, inv: sv.inv.map(sm), eq: Object.fromEntries(ADM_SLOTS.map(k => [k, sm(sv.eq && sv.eq[k])])) };
  }
  if (act === 'gm') {
    const on = !!b.on; if (row.account_id === adm.id) return [400, { error: 'self' }];
    await DB.kvSet('gm:' + row.account_id, on ? 1 : null);
    const L = ((await DB.kvGet('gm:list')) || []).filter(x => x.a !== row.account_id); if (on) L.push({ a: row.account_id, n: nm });
    await DB.kvSet('gm:list', L); RT.setGm(row.account_id, on); DB.log('adm_gm', { acc: row.account_id, on }); return { ok: true };
  }
  if (act === 'give') {
    const slot = String(b.slot || ''), rar = Math.max(0, Math.min(5, b.rar | 0)), lvl = Math.max(1, Math.min(WD.LV_CAP, b.lvl | 0 || 1)), qty = Math.max(1, Math.min(10, b.qty | 0 || 1));
    if (!ADM_SLOTS.includes(slot)) return [400, { error: 'slot' }];
    const rn = ['Gasto', 'Comum', 'Incomum', 'Raro', 'Épico', 'Lendário'], base = { arma: 'Arma', cabeca: 'Elmo', peito: 'Peitoral', pernas: 'Grevas', anel: 'Anel' };
    const name = admClean(b.itemName, 30) || (base[slot] + ' ' + rn[rar] + ' de Game Master');
    let full = false; await admEdit(row, sv => { for (let i = 0; i < qty; i++) { if (sv.inv.length >= 40) { full = true; break; } sv.inv.push(admItem(slot, rar, lvl, name)); } });
    DB.log('adm_give', { to: row.id, slot, rar, lvl, qty }); return { ok: true, full };
  }
  if (act === 'pot') { const n = Math.max(1, Math.min(99, b.n | 0 || 1)); await admEdit(row, sv => { const p = sv.inv.find(x => x.id === 'pot'); if (p) p.n = Math.min(999, (p.n | 0) + n); else sv.inv.push({ id: 'pot', name: 'Poção de Cura', ic: '🧪', n, stack: 1, price: 6, rar: 1 }); }); return { ok: true }; }
  if (act === 'gold') { const d = Math.max(-1e9, Math.min(1e9, Math.floor(+b.n || 0))); await admEdit(row, sv => { sv.gold = Math.max(0, Math.min(1e12, (sv.gold | 0) + d)); }); DB.log('adm_gold', { to: row.id, d }); return { ok: true }; }
  if (act === 'level') { const l = Math.max(1, Math.min(WD.LV_CAP, b.lvl | 0)); await admEdit(row, sv => { sv.lvl = l; sv.xp = 0; }); DB.log('adm_level', { to: row.id, l }); return { ok: true }; }
  if (act === 'take') {   // remove item da mochila (id) ou do equipamento (slot)
    let removed = false;
    await admEdit(row, sv => {
      if (b.slot && ADM_SLOTS.includes(String(b.slot))) { if (sv.eq[b.slot]) { sv.eq[b.slot] = null; removed = true; } }
      else { const i = sv.inv.findIndex(x => x && x.id === String(b.id)); if (i >= 0) { sv.inv.splice(i, 1); removed = true; } }
    });
    DB.log('adm_take', { to: row.id }); return { ok: removed };
  }
  if (act === 'kick') return { ok: RT.kick(nm) };
  if (act === 'mute') return { ok: RT.mute(nm, b.min) };
  return [400, { error: 'act' }];
}

const SHOP = (() => {
  const KEY = process.env.STRIPE_SECRET_KEY || '', WHSEC = process.env.STRIPE_WEBHOOK_SECRET || '';
  const URLBASE = (process.env.PUBLIC_URL || 'https://muonlineclaude.com').replace(/\/+$/, '');
  const CUR = S.SHOP_CUR;   // moeda antiga (só para pedidos feitos antes da troca)
  const MUDX = require('./mu-data.js');
  if (+process.env.MU_EUR_USD > 0) MUDX.PRICE_FX.usd = +process.env.MU_EUR_USD;
  if (+process.env.MU_EUR_BRL > 0) MUDX.PRICE_FX.brl = +process.env.MU_EUR_BRL;
  const pickCur = c => MUDX.PRICE_CURS.includes(String(c || '').toLowerCase()) ? String(c).toLowerCase() : 'usd';
  const NOTIFY = process.env.NOTIFY_EMAIL || 'murilocastronv@gmail.com', RESEND = process.env.RESEND_API_KEY || '';
  const enabled = () => !!(KEY && WHSEC);
  const inflight = new Set();

  function product(kind, id) {   // preço SEMPRE vem do servidor (shared.js), nunca do navegador
    if (kind === 'cry') { const p = S.PREM_PACKS.find(x => x.id === id); return p && { kind, id, cents: p.cents, label: p.cry + ' cristais' }; }
    if (kind === 'tk') { const p = S.TICKET_PACKS.find(x => x.id === id); return p && { kind, id, cents: p.cents, label: p.n + ' ingresso(s) da Roleta' }; }
    if (kind === 'wow') { const p = WSHOP.BY_ID[id]; return p && { kind, id, cents: p.cents, label: 'Reinos de Valdor — ' + p.n[0] }; }
    if (kind === 'mu') return MU ? MU.product(id) : null;
    if (kind === 'item') { const p = S.PREM_BY_ID[id]; return p && !p.divine && p.price > 0 ? { kind, id, cents: p.price, label: S.premName(id, 'pt') } : null; }
    return null;
  }
  function verifySig(raw, header) {   // formato do Stripe: t=...,v1=hmac_sha256(segredo, t + "." + corpo)
    if (!WHSEC || typeof header !== 'string') return false;
    const parts = header.split(',').map(x => x.trim().split('='));
    const t = (parts.find(p => p[0] === 't') || [])[1], v1 = parts.filter(p => p[0] === 'v1').map(p => p[1]);
    if (!t || !v1.length || Math.abs(Date.now() / 1000 - +t) > 300) return false;
    const exp = crypto.createHmac('sha256', WHSEC).update(Buffer.concat([Buffer.from(t + '.'), raw])).digest('hex');
    return v1.some(x => x.length === exp.length && crypto.timingSafeEqual(Buffer.from(x), Buffer.from(exp)));
  }
  async function grant(charId, kind, id) {   // entrega no personagem (online: na hora; offline: direto no banco)
    if (kind === 'mu') { await MU.grant(charId, id, 'stripe'); return; }   // MU Legends: vai para a caixa de entrega do herói
    if (kind === 'wow') {   // item do jogo 3D: vale para a CONTA inteira (todos os heróis dela)
      const row = await DB.charById(charId); if (!row) throw new Error('personagem não existe');
      const k = 'wowshop:' + row.account_id, st = (await DB.kvGet(k)) || { own: [], eq: {} };
      if (!st.own.includes(id)) st.own.push(id);
      await DB.kvSet(k, st); return;
    }
    const p = byChar.get(charId), H = SYS && SYS.helpers;
    const apply = (c, online) => {
      if (kind === 'cry') { c.crystals = (c.crystals || 0) + S.PREM_PACKS.find(x => x.id === id).cry; return null; }
      if (kind === 'tk') { const s = H ? H.ensure(c) : (c.sys = c.sys || {}); s.tk = (s.tk || 0) + S.TICKET_PACKS.find(x => x.id === id).n; return null; }
      const it = S.premItem(id); if (c.inv.length < S.INV_MAX) { c.inv.push(it); return null; }
      return it;   // inventário cheio: vai para o Correio
    };
    if (p) {
      const mail = apply(p.c, true);
      if (mail) { if (H) H.addMailTo(p, { kind: 'shop', item: mail }); else p.c.inv.push(mail); }
      markDirty(p); await saveNow(p);
      if (p.ws) {
        p.ws.send({ t: 'me', c: p.c });
        if (kind === 'cry') msgTo(p, 'shop_ok', { n: S.PREM_PACKS.find(x => x.id === id).cry });
        else if (kind === 'tk') msgTo(p, 'shop_tk', { n: S.TICKET_PACKS.find(x => x.id === id).n });
        else msgTo(p, mail ? 'shop_mail' : 'shop_item', { it: S.premItem(id) });
      }
      return;
    }
    const row = await DB.charById(charId); if (!row) throw new Error('personagem não existe');
    const c = row.data, mail = apply(c, false);
    if (mail && H) { await DB.saveChar(charId, c); await H.addMail(charId, { kind: 'shop', item: mail }); } else { if (mail) c.inv.push(mail); await DB.saveChar(charId, c); }
  }
  async function notify(subject, text) {   // aviso por e-mail ao dono a cada pagamento (precisa de RESEND_API_KEY; sem ela só vai para o log)
    log('[loja] ' + subject + ' | ' + text.replace(/\n/g, ' · '));
    if (!RESEND) return;
    try { await fetch((process.env.RESEND_API || 'https://api.resend.com') + '/emails', { method: 'POST', headers: { Authorization: 'Bearer ' + RESEND, 'Content-Type': 'application/json' },
      body: JSON.stringify({ from: 'Eternal Realms <onboarding@resend.dev>', to: [NOTIFY], subject, text }) }); } catch (e) { console.error('[loja] e-mail falhou:', e.message); }
  }
  async function deliver(s) {   // idempotente: cada pagamento (sessão) só entrega uma vez
    const md = s.metadata || {}, pr = product(md.kind, md.id), charId = +md.char;
    if (!pr || !charId) { DB.log('shop_bad', { id: s.id }); return 'ignorado'; }
    const sc = String(s.currency).toLowerCase(), want = md.amt ? +md.amt : (sc === CUR ? pr.cents : MUDX.priceIn(pr.cents, sc));
    if ((md.cur ? sc !== md.cur : !(sc === CUR || MUDX.PRICE_CURS.includes(sc))) || s.amount_total !== want) { DB.log('shop_valor_diferente', { id: s.id, total: s.amount_total, cur: s.currency }); await notify('⚠️ Pagamento com valor diferente', 'Sessão ' + s.id + ' recebeu ' + s.amount_total + ' ' + s.currency + ' mas o produto custa ' + pr.cents + '. Nada foi entregue; confira no Stripe.'); return 'ignorado'; }
    const key = 'order:' + s.id; if (inflight.has(key)) return 'em andamento'; inflight.add(key);
    try {
      const o = await DB.kvGet(key); if (o && o.st === 'done') return 'já entregue';
      const rec = { char: charId, kind: pr.kind, id: pr.id, cents: pr.cents, at: now() };
      await DB.kvSet(key, { ...rec, st: 'delivering' });
      await grant(charId, pr.kind, pr.id);
      await DB.kvSet(key, { ...rec, st: 'done', done: now() });
      DB.log('shop', { id: s.id, char: charId, kind: pr.kind, prod: pr.id, cents: pr.cents, coupon: md.coupon }); if (md.coupon) couponMark(md.coupon, 'used');
      const row = await DB.charById(charId), who = row && row.data ? row.data.name : '#' + charId;
      await notify('💰 Pagamento recebido: ' + (s.amount_total / 100).toFixed(2) + ' ' + sc.toUpperCase(),
        'Produto: ' + pr.label + '\nValor: ' + (s.amount_total / 100).toFixed(2) + ' ' + sc.toUpperCase() + '\nPersonagem: ' + who + ' (id ' + charId + ')\nComprador: ' + ((s.customer_details && s.customer_details.email) || s.customer_email || '?') + '\nPedido Stripe: ' + s.id + '\nStatus: entregue ao personagem.');
      return 'entregue';
    } finally { inflight.delete(key); }
  }
  function readRaw(req) {
    return new Promise((ok, bad) => { let n = 0; const ch = []; req.on('data', d => { n += d.length; if (n > 256 * 1024) { bad(new Error('grande')); req.destroy(); } else ch.push(d); }); req.on('end', () => ok(Buffer.concat(ch))); req.on('error', bad); });
  }
  async function webhook(req, res) {
    try {
      const raw = await readRaw(req);
      if (!verifySig(raw, req.headers['stripe-signature'])) { sendJson(res, 400, { error: 'assinatura' }); return; }
      const ev = JSON.parse(raw.toString());
      if ((ev.type === 'checkout.session.completed' || ev.type === 'checkout.session.async_payment_succeeded') && ev.data && ev.data.object && ev.data.object.payment_status === 'paid') {
        const r = await deliver(ev.data.object); log('[loja]', ev.type, ev.data.object.id, r);
      }
      sendJson(res, 200, { received: true });
    } catch (e) { console.error('[loja] webhook', e.message); sendJson(res, 500, { error: 'server' }); }   // 500 = o Stripe tenta de novo
  }
  async function checkout(b, req) {
    if (!enabled()) return [503, { error: 'shop_off' }];
    if (limited(ipOf(req), 12)) return [429, { error: 'rate' }];
    const t = verify(b.token); if (!t) return [401, { error: 'auth' }];
    const pr = product(String(b.kind || 'cry'), String(b.id || b.pack || '')); if (!pr) return [400, { error: 'pack' }];
    const row = await DB.charById(+b.char); if (!row || row.account_id !== t.a) return [400, { error: 'char' }];
    const acc = await DB.accountById(t.a); if (!acc) return [401, { error: 'auth' }];
    if (pr.kind === 'wow') { const st = await DB.kvGet('wowshop:' + t.a); if (st && st.own.includes(pr.id)) return [409, { error: 'owned' }]; }
    if (pr.kind === 'mu' && MU && MU.zenOf) { const z = MU.zenOf(pr.id); if (z) { const sv = await DB.kvGet('mu:' + row.id); if (sv && (+sv.gold || 0) + z > 2e9) return [409, { error: 'zen_full' }]; } }   // não vende Zen para quem já está no limite
    const name = (row.data && row.data.name) || row.name || '?';
    const f = new URLSearchParams();
    f.set('mode', 'payment'); const back = pr.kind === 'mu' ? (b.from === 'home' ? '/' : '/jogar') : '/'; f.set('success_url', URLBASE + back + '?pago=ok'); f.set('cancel_url', URLBASE + back + '?pago=cancelado');
    f.set('client_reference_id', String(row.id)); f.set('customer_email', acc.email);
    const cur = pickCur(b.cur), pb = pr.kind === 'mu' && MUDX.MU_SHOP_BY_ID ? MUDX.MU_SHOP_BY_ID[pr.id] : null;
    let amt = cur === 'brl' && pb && pb.brl ? pb.brl : MUDX.priceIn(pr.cents, cur);   // o preço é calculado aqui no servidor, nunca vem do navegador (VIP: preço exato em reais)
    let cp = null; if (b.coupon) { cp = await couponGet(b.coupon); if (!cp) return [400, { error: 'coupon' }]; amt = Math.max(cur === 'brl' ? 300 : 60, Math.round(amt * (100 - cp.pct) / 100)); }   // cupom: desconto calculado no servidor
    for (const pre of ['metadata', 'payment_intent_data[metadata]']) { f.set(pre + '[char]', String(row.id)); f.set(pre + '[kind]', pr.kind); f.set(pre + '[id]', pr.id); f.set(pre + '[acc]', String(t.a)); f.set(pre + '[cur]', cur); f.set(pre + '[amt]', String(amt)); if (cp) f.set(pre + '[coupon]', cp.code); }
    f.set('line_items[0][quantity]', '1'); f.set('line_items[0][price_data][currency]', cur); f.set('line_items[0][price_data][unit_amount]', String(amt));
    f.set('line_items[0][price_data][product_data][name]', pr.label + ' — ' + name); f.set('line_items[0][price_data][product_data][description]', pr.kind === 'mu' ? 'MuOnlineClaude' : 'Eternal Realms');
    let r, j; try { r = await fetch((process.env.STRIPE_API || 'https://api.stripe.com') + '/v1/checkout/sessions', { method: 'POST', headers: { Authorization: 'Bearer ' + KEY, 'Content-Type': 'application/x-www-form-urlencoded' }, body: f }); j = await r.json(); } catch (e) { return [502, { error: 'net_err' }]; }
    if (!r.ok || !j.url) { console.error('[loja] stripe', r.status, j && j.error && j.error.message); return [502, { error: 'shop_err' }]; }
    DB.log('shop_checkout', { id: j.id, char: row.id, kind: pr.kind, prod: pr.id, cur, amt, coupon: cp ? cp.code : undefined }); if (cp) couponMark(cp.code, 'opened');
    return { url: j.url };
  }
  return { enabled, cur: 'usd', curs: MUDX.PRICE_CURS, fx: MUDX.PRICE_FX, webhook, checkout, deliver, verifySig };
})();

let MU = null;   // MU Legends 3D (mu.js), criado depois das rotas
const WOW = require('./wow'), WD = WOW.WD;
const WSHOP = require('./wowshop');
const RT = require('./wowrt')({ verify, DB, WSHOP, log, CLS_MAP: WOW.CLS_MAP });   // multiplayer em tempo real do 3D (WebSocket /ws3d)
async function wowAuth(b) {
  const t = verify(b.token); if (!t) return [null, [401, { error: 'auth' }]];
  const row = await DB.charById(+b.char); if (!row || row.account_id !== t.a) return [null, [400, { error: 'char' }]];
  return [row, null];
}
/* chat do mundo do 3D: guarda só as últimas mensagens na memória (elas somem da tela em 15 s, então não precisa de banco) */
const wowMsgs = []; let wowMsgId = 0; const wowLastSay = new Map();
const muMsgs = []; let muMsgId = 0; const muLastSay = new Map(), muMuted = new Map();   // chat próprio do MuOnlineClaude
const API = {
  'POST /api/wow/ping': async (b, req) => {
    const sid = String(b.sid || '').slice(0, 40); if (!/^[a-z0-9]{8,40}$/i.test(sid)) return [400, { error: 'sid' }];
    if (b.leave) wowSeen.delete(sid); else if (wowSeen.size < 20000) wowSeen.set(sid, { t: Date.now(), play: b.play ? 1 : 0 });
    return { ok: true };
  },
  'POST /api/wow/chars': async b => {
    const t = verify(b.token); if (!t) return [401, { error: 'auth' }];
    const rows = await DB.charsOf(t.a);
    return { chars: await Promise.all(rows.map(async r => { const sv = await DB.kvGet('wow:' + r.id); return { id: r.id, name: r.data.name, oldCls: r.data.cls, oldLvl: r.data.lvl, cls: (sv && sv.cls) || WOW.CLS_MAP[r.data.cls] || 'guerreiro', race: (sv && sv.race) || '', lvl: sv ? sv.lvl : WOW.newLevel(r.data.lvl), converted: !!sv }; })) };
  },
  'POST /api/wow/load': async b => {
    const [row, err] = await wowAuth(b); if (err) return err;
    let sv = await DB.kvGet('wow:' + row.id);
    if (!sv) { sv = WOW.convert(row.data); await DB.kvSet('wow:' + row.id, sv); DB.log('wow_convert', { id: row.id }); }
    return { sv };
  },
  'POST /api/wow/create': async b => {   // herói novo direto no 3D: 12 classes × 11 raças
    const t = verify(b.token); if (!t) return [401, { error: 'auth' }];
    const name = String(b.name || '').trim(), cls = String(b.cls || ''), race = String(b.race || '');
    if (!/^[A-Za-zÀ-ÿ0-9]{3,12}$/.test(name)) return [400, { error: 'err_name' }];
    if (!WOW.WD.CLASSES[cls]) return [400, { error: 'bad_class' }];
    if (!WOW.WD.RACES[race]) return [400, { error: 'bad_race' }];
    if ((await DB.charsOf(t.a)).length >= 5) return [400, { error: 'max_chars' }];
    if (await DB.nameTaken(name)) return [409, { error: 'nameTaken' }];
    const data = S.newChar(name, WOW.OLD_CLS(cls)); const id = await DB.createChar(t.a, name, data); statsCache.t = 0;
    await DB.kvSet('wow:' + id, WOW.fresh(name, cls, race, b.look)); DB.log('wow_create', { id, cls, race });
    return { id, name, cls, race };
  },
  'POST /api/wow/race': async b => {   // herói convertido do 2D escolhe raça e aparência (uma única vez)
    const [row, err] = await wowAuth(b); if (err) return err;
    const race = String(b.race || ''); if (!WOW.WD.RACES[race]) return [400, { error: 'bad_race' }];
    const sv = await DB.kvGet('wow:' + row.id) || WOW.convert(row.data);
    if (sv.race) return [409, { error: 'already' }];
    sv.race = race; sv.look = WOW.cleanLook(b.look); await DB.kvSet('wow:' + row.id, sv); return { ok: true };
  },
  'POST /api/wow/save': async b => {
    const [row, err] = await wowAuth(b); if (err) return err;
    return RT.lock('wow:' + row.id, async () => {
      const prev = await DB.kvGet('wow:' + row.id) || WOW.convert(row.data);
      if (b.sv && (b.sv.tv | 0) < (prev.tv | 0)) return [409, { error: 'stale', sv: prev }];   // um salvamento antigo não pode desfazer uma troca
      const sv = WOW.sanitize(b.sv, prev); if (!sv) return [400, { error: 'bad_save' }];
      await DB.kvSet('wow:' + row.id, sv); RT.setLevel(row.id, sv.lvl); return { ok: true };
    });
  },
  /* chat do MuOnlineClaude: canal próprio (não mistura com o jogo anterior). GM aparece com [GM]. */
  'POST /api/mu/say': async (b, req) => {
    const [row, err] = await wowAuth(b); if (err) return err;
    if (muMuted.has(row.account_id) && muMuted.get(row.account_id) > Date.now()) return [403, { error: 'muted' }];
    let text = String(b.text || '').replace(/[\u0000-\u001f\u007f\u200b-\u200f\u202a-\u202e\u2066-\u2069]/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 120);
    if (!text) return [400, { error: 'empty' }];
    const t = Date.now(), last = muLastSay.get(row.account_id) || { t: 0, x: '' };
    if (t - last.t < 1200) return [429, { error: 'slow' }];
    if (text === last.x && t - last.t < 10000) return [429, { error: 'dup' }];
    muLastSay.set(row.account_id, { t, x: text }); if (muLastSay.size > 5000) muLastSay.clear();
    const gm = !!(await DB.kvGet('gm:' + row.account_id));
    let vt = ''; try { if (MU && MU.vipOf) vt = (await MU.vipOf(row.account_id)).tier; } catch (_) {}
    const m = { id: ++muMsgId, t, n: (row.data && row.data.name) || row.name || '?', x: text, gm: gm ? 1 : 0, v: vt };
    muMsgs.push(m); while (muMsgs.length > 80) muMsgs.shift();
    return { ok: true, id: m.id };
  },
  'GET /api/mu/chat': async (b, req) => {
    const since = +new URL(req.url, 'http://x').searchParams.get('since') || 0, t = Date.now();
    return { last: muMsgId, msgs: muMsgs.filter(m => m.id > since && t - m.t < 60000).map(m => ({ id: m.id, n: m.n, x: m.x, gm: m.gm, v: m.v || '', sys: m.sys ? 1 : 0, k: m.k || '', a: m.a || [], age: t - m.t })) };
  },
  'POST /api/wow/say': async (b, req) => {   // manda uma mensagem para todos que estão no 3D
    const [row, err] = await wowAuth(b); if (err) return err;
    let text = String(b.text || '').replace(/[\u0000-\u001f\u007f\u200b-\u200f\u202a-\u202e\u2066-\u2069]/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 90);
    if (!text) return [400, { error: 'empty' }];
    const t = Date.now(), last = wowLastSay.get(row.account_id) || { t: 0, x: '' };
    if (t - last.t < 1200) return [429, { error: 'slow' }];
    if (text === last.x && t - last.t < 10000) return [429, { error: 'dup' }];
    wowLastSay.set(row.account_id, { t, x: text }); if (wowLastSay.size > 5000) wowLastSay.clear();
    const m = { id: ++wowMsgId, t, n: (row.data && row.data.name) || row.name || '?', x: text };
    wowMsgs.push(m); while (wowMsgs.length > 60) wowMsgs.shift();
    return { ok: true, id: m.id };
  },
  'GET /api/wow/chat': async (b, req) => {   // mensagens novas (as de mais de 30 s nem vale a pena mandar)
    const since = +new URL(req.url, 'http://x').searchParams.get('since') || 0, t = Date.now();
    return { last: wowMsgId, msgs: wowMsgs.filter(m => m.id > since && t - m.t < 30000).map(m => ({ id: m.id, n: m.n, x: m.x, age: t - m.t })) };
  },
  'GET /api/wow/catalog': async () => ({ cur: SHOP.cur, on: SHOP.enabled(), items: WSHOP.ITEMS }),
  'POST /api/wow/shop': async b => {   // o que a conta já comprou e o que está equipado
    const t = verify(b.token); if (!t) return [401, { error: 'auth' }];
    const st = (await DB.kvGet('wowshop:' + t.a)) || { own: [], eq: {} };
    return { own: st.own, eq: st.eq || {} };
  },
  'POST /api/wow/equip': async (b, req) => {   // equipa/desequipa (1 item por categoria); só vale para o que a conta comprou
    if (limited(ipOf(req), 60)) return [429, { error: 'rate' }];
    const t = verify(b.token); if (!t) return [401, { error: 'auth' }];
    const cat = String(b.cat || ''); if (!WSHOP.CATS.includes(cat)) return [400, { error: 'cat' }];
    const k = 'wowshop:' + t.a, st = (await DB.kvGet(k)) || { own: [], eq: {} }; st.eq = st.eq || {};
    if (!b.id) delete st.eq[cat];
    else { const it = WSHOP.BY_ID[String(b.id)]; if (!it || it.cat !== cat || !st.own.includes(it.id)) return [403, { error: 'not_owned' }]; st.eq[cat] = it.id; }
    await DB.kvSet(k, st); return { ok: true, eq: st.eq };
  },
  'GET /api/stats': async () => getStats(),
  'POST /api/wow/evtest': async b => process.env.WOW_EV_DEBUG ? { ok: RT._evStart(+b.id | 0), n: RT._evCount() } : [404, { error: 'x' }],   // só existe com WOW_EV_DEBUG (testes locais)
  'GET /api/shop': async () => ({ on: SHOP.enabled(), cur: SHOP.cur }),
  'POST /api/checkout': async (b, req) => SHOP.checkout(b, req),
  'GET /api/ranking': async () => {
    const lvl = await DB.top('lvl', 20), pvp = await DB.top('pvp', 20), rst = await DB.top('resets', 20);
    for (const p of byChar.values()) { for (const row of lvl) if (row.name === p.c.name) { row.lvl = p.c.lvl; row.resets = p.c.resets || 0; } for (const row of pvp) if (row.name === p.c.name) row.pvp = p.c.pvpKills; for (const row of rst) if (row.name === p.c.name) { row.lvl = p.c.lvl; row.resets = p.c.resets || 0; } }
    lvl.sort((a, b) => b.lvl - a.lvl); pvp.sort((a, b) => b.pvp - a.pvp); rst.sort((a, b) => ((b.resets || 0) - (a.resets || 0)) || (b.lvl - a.lvl));
    const gl = [...guilds.values()].map(g => ({ name: g.name, members: g.members.length, power: g.members.reduce((s, m) => s + (m.lvl || 1), 0) })).sort((a, b) => b.power - a.power).slice(0, 20);
    return { level: lvl, resets: rst.filter(r => r.resets > 0), pvp: pvp.filter(r => r.pvp > 0), guilds: gl };
  },
  'POST /api/register': async (b, req) => {
    if (limited(ipOf(req), 10)) return [429, { error: 'rate' }];
    const user = String(b.username || '').trim(), email = String(b.email || '').trim().toLowerCase(), pw = String(b.password || '');
    if (!/^[A-Za-z0-9_]{3,16}$/.test(user)) return [400, { error: 'err_user' }];
    if (!/^[^\s@]{1,64}@[^\s@]{1,190}\.[^\s@]{2,}$/.test(email)) return [400, { error: 'err_email' }];
    if (pw.length < 6 || pw.length > 100) return [400, { error: 'err_pw' }];
    const ex = await DB.accountExists(user.toLowerCase(), email);
    if (ex.some(a => a.ulow === user.toLowerCase())) return [409, { error: 'userTaken' }];
    if (ex.length) return [409, { error: 'emailTaken' }];
    const a = await DB.createAccount(user, email, hashPass(pw)); statsCache.t = 0;
    DB.log('register', { id: a.id, user });
    return { token: makeToken(a.id), user: a.username };
  },
  /* recuperar senha por e-mail: o link vale 1 hora e só pode ser usado uma vez. A resposta é sempre a mesma (não revela se o e-mail existe).
     Para o e-mail sair de verdade: RESEND_API_KEY + domínio verificado no resend.com + MAIL_FROM (ex.: Eternal Realms <no-reply@muonlineclaude.com>) no Render. */
  'POST /api/forgot': async (b, req) => {
    if (limited(ipOf(req), 5)) return [429, { error: 'rate' }];
    const q = String(b.email || '').trim().toLowerCase().slice(0, 200); if (!q) return [400, { error: 'err_email' }];
    try {
      const a = await DB.accountByLogin(q);
      if (a && a.email) {
        const last = await DB.kvGet('pwreset:last:' + a.id);
        if (!last || now() - last > 60000) {
          await DB.kvSet('pwreset:last:' + a.id, now());
          const tokn = crypto.randomBytes(24).toString('hex');
          await DB.kvSet('pwreset:' + crypto.createHash('sha256').update(tokn).digest('hex'), { a: a.id, exp: now() + 3600e3 });
          const base = (process.env.PUBLIC_URL || 'https://muonlineclaude.com').replace(/\/+$/, ''), link = base + '/?reset=' + tokn;
          await sendMail(a.email, 'Redefinir senha · Reset your password', 'Olá, ' + a.username + '!\n\nPara criar uma nova senha, abra este link (vale por 1 hora):\n' + link + '\n\nSe não foi você, ignore este e-mail: sua senha continua a mesma.\n\n---\nHi ' + a.username + '! To set a new password open this link (valid for 1 hour):\n' + link + '\nIf you did not ask for this, just ignore this e-mail.');
        }
      }
    } catch (e) { console.error('[senha]', e.message); }
    return { ok: true };
  },
  'POST /api/reset': async (b, req) => {
    if (limited(ipOf(req), 10)) return [429, { error: 'rate' }];
    const tokn = String(b.token || '').slice(0, 100), pw = String(b.password || '');
    if (pw.length < 6 || pw.length > 100) return [400, { error: 'err_pw' }];
    const key = 'pwreset:' + crypto.createHash('sha256').update(tokn).digest('hex'), r = await DB.kvGet(key);
    if (!r || !r.a || r.exp < now()) return [400, { error: 'badReset' }];
    const a = await DB.accountById(r.a); if (!a) return [400, { error: 'badReset' }];
    await DB.setPass(a.id, hashPass(pw)); await DB.kvSet(key, null); DB.log('pw_reset', { id: a.id });
    return { token: makeToken(a.id), user: a.username };
  },
  'POST /api/login': async (b, req) => {
    if (limited(ipOf(req), 20)) return [429, { error: 'rate' }];
    const a = await DB.accountByLogin(String(b.id || '').trim());
    if (!a || !checkPass(String(b.password || ''), a.pass)) return [401, { error: 'badLogin' }];
    return { token: makeToken(a.id), user: a.username };
  },
  'POST /api/me': async b => {
    const t = verify(b.token); if (!t) return [401, { error: 'auth' }];
    const a = await DB.accountById(t.a); if (!a) return [401, { error: 'auth' }];
    const rows = await DB.charsOf(a.id);
    return { user: a.username, chars: rows.map(r => { const live = byChar.get(r.id); const d = live ? live.c : r.data; return { id: r.id, name: d.name, cls: d.cls, lvl: d.lvl, map: d.map, online: !!(live && live.ws) }; }) };
  },
  'POST /api/char': async b => {
    const t = verify(b.token); if (!t) return [401, { error: 'auth' }];
    const name = String(b.name || '').trim(), cls = String(b.cls || '');
    if (!/^[A-Za-zÀ-ÿ0-9]{3,12}$/.test(name)) return [400, { error: 'err_name' }];
    if (!S.CLASSES[cls]) return [400, { error: 'pick_class' }];
    if ((await DB.charsOf(t.a)).length >= 5) return [400, { error: 'max_chars' }];
    if (await DB.nameTaken(name)) return [409, { error: 'nameTaken' }];
    const data = S.newChar(name, cls); const id = await DB.createChar(t.a, name, data); statsCache.t = 0;
    return { id, name, cls, lvl: 1, map: 'valoria' };
  },
};
API['POST /api/adm'] = admApi;
/* MuOnlineClaude (jogo principal em / e /jogar). O jogo anterior continua em /classico. */
MU = require('./mu')({ API, DB, verify, log, limited, ipOf, S, shopOn: () => SHOP.enabled(),
  stats: { reset: () => { statsCache.t = 0; }, get: async () => { const s = await getStats(); const w = wowOnline(); return { accounts: s.accounts, characters: s.characters, online: Math.max(w.pl, RT.count()) }; } } });
/* ---- extras do MuOnlineClaude ligados aqui (sem mexer no mu.js) ----
   1) Evolução de classe: fica salva para sempre em kv "murank:<herói>" (o reset não desfaz) e volta em todo load/save.
   2) Troca: achar herói pelo nome.
   3) Pacotes de Zen da loja: respeitam o limite de 2 bilhões (ver checkout). */
const MUD = require('./mu-data.js');
MU.zenOf = id => { const p = MUD.MU_SHOP_BY_ID[id]; return p && p.zen ? +p.zen : 0; };
(() => {
  const RK = id => 'murank:' + id;
  const inject = async (charId, j) => { if (!charId || !j || typeof j !== 'object') return j; const r = (await DB.kvGet(RK(charId))) | 0; if (j.sv) j.sv.classRank = r; j.classRank = r; return j; };
  const wrap = (key, before) => {
    const orig = API[key]; if (!orig) return;
    API[key] = async (b, req) => {
      const charId = +(b && b.char) || 0;
      if (before && charId) { try { await before(b); } catch (e) { console.error('[mu evo]', e.message); } }
      const r = await orig(b, req);
      if (Array.isArray(r)) { if (r[0] < 300) await inject(charId, r[1]); return r; }
      return inject(charId, r);
    };
  };
  wrap('POST /api/mu/load');
  wrap('POST /api/mu/save', async b => {   // valida a evolução pedida pelo jogo antes do salvamento normal
    const t = verify(b.token); if (!t || !b.sv || typeof b.sv !== 'object') return;
    const row = await DB.charById(+b.char); if (!row || row.account_id !== t.a) return;
    const cur = (await DB.kvGet(RK(row.id))) | 0, want = Math.max(0, Math.min(2, b.sv.classRank | 0));
    if (want !== cur + 1) return;   // sobe um passo por vez e nunca desce
    const E = MUD.CLASS_EVO[want], prev = await DB.kvGet('mu:' + row.id); if (!prev) return;
    if (!((prev.level | 0) >= E.lvl || (prev.resets | 0) > 0)) return;
    const pg = +prev.gold || 0, ng = +b.sv.gold || 0;
    if (pg < E.fee || ng + E.fee > pg + 200000) return;   // precisa ter pago a taxa em Zen (folga de 200 mil para o Zen catado entre dois salvamentos)
    await DB.kvSet(RK(row.id), want); DB.log('mu_evolve', { char: row.id, rank: want });
  });
  API['POST /api/mu/findchar'] = async (b, req) => {   // troca: digitar o nome do herói em vez do número
    if (limited(ipOf(req), 30)) return [429, { error: 'rate' }];
    const t = verify(b.token); if (!t) return [401, { error: 'auth' }];
    const q = String(b.name || '').trim().toLowerCase(); if (!q) return [400, { error: 'name' }];
    const all = await DB.allChars(); const c = all.find(x => String((x.data && x.data.name) || x.name || '').toLowerCase() === q);
    if (!c) return [404, { error: 'trade_target' }];
    const sv = await DB.kvGet('mu:' + c.id); if (!sv) return [404, { error: 'trade_target' }];
    return { id: c.id, name: sv.name, cls: sv.cls, level: sv.level, resets: sv.resets | 0 };
  };
})();
/* ---- ANTI-HACK de itens do MuOnlineClaude ----
   O combate roda no navegador, então o servidor confere cada salvamento contra a última cópia guardada:
   - item duplicado (mesmo id em dois lugares) some;
   - item NOVO só é aceito se puder ter caído de monstro (ou ser comprado no NPC): +0..+4, nível compatível
     com os monstros que o herói alcança, opções dentro dos limites do drop, poucos por minuto;
   - itens de evento/ADM nunca nascem no navegador (vêm do servidor); itens da loja já têm o livro-razão do mu.js;
   - item que já existia não pode trocar raridade/opções; +7..+9 gasta Jewel of Bless e +10..+15 Jewel of Soul;
   - joias novas: no máximo algumas por salvamento.
   Tudo que falha é desfeito, o jogo recebe de volta a cópia do servidor e a conta ganha um registro em kv "mucheat:<conta>". */
(() => {
  const B = MUD.BASES, LIM = { dmgPct: .12, hp: 30, mp: 24, crit: .05, aspd: .1, defPct: .1, hpRegen: 3 };
  const NOPT = { 2: 1, 3: 2, 4: 3, 5: 3, 6: 4 };
  const SHOPSET = new Set(); for (const k in MUD.SHOPS) for (const id of MUD.SHOPS[k].items) SHOPSET.add(id);
  const DROPX = new Set(Object.values(MUD.DROP_EXCL || {}).flat());
  const mapTop = {}; for (const id in MUD.MAPS) { let t = 1; for (const sp of MUD.MAPS[id].spawns || []) t = Math.max(t, sp.lvl | 0); mapTop[id] = t; }
  const monTop = (lv, rs) => { let t = 1; for (const id in MUD.MAPS) if (rs > 0 || (MUD.MAPS[id].lvl | 0) <= lv) t = Math.max(t, mapTop[id]); return t; };
  const JEWELS = ['bless', 'soul', 'chaos'];
  const OPTCAP = { dmgPct: .25, hp: 500, mp: 400, crit: .1, aspd: .15, defPct: .15, hpRegen: 50 };
  const optKey = o => { if (!o || typeof o !== 'object') return ''; return Object.keys(OPTCAP).filter(k => +o[k] > 0).map(k => k + ':' + Math.round(Math.min(OPTCAP[k], +o[k]) * 100)).join(','); };
  const all = (sv, ware) => { const o = []; for (const it of (sv && sv.inv) || []) if (it) o.push(it); for (const k in (sv && sv.equip) || {}) if (sv.equip[k]) o.push(sv.equip[k]); for (const it of ware || []) if (it) o.push(it); return o; };
  const cnt = (list, id) => list.reduce((n, it) => n + (it && it.b === id ? Math.max(1, it.q | 0) : 0), 0);
  const optsOk = (it, b) => {
    if (!it.o) return true; if (typeof it.o !== 'object') return false;
    const ks = Object.keys(it.o); if (ks.length > (NOPT[it.r | 0] || 0)) return false;
    const t = (b.tier | 0) + 1;
    for (const k of ks) { const v = +it.o[k], m = LIM[k]; if (m === undefined || !(v >= 0)) return false; if (v > (k === 'hp' || k === 'mp' || k === 'hpRegen' ? m * t : m + .04) + 1e-9) return false; }
    return true;
  };
  function check(b, prev, prevWare) {
    const sv = b.sv, out = [], dtMin = Math.min(600, Math.max(.05, (Date.now() - (prev.t || Date.now())) / 60000));
    const lv = prev.level | 0, rs = prev.resets | 0, top = monTop(lv, rs);
    const known = new Map(); for (const it of all(prev, prevWare)) if (it && it.u) known.set(it.u, it);
    const ware = Array.isArray(b.ware) ? b.ware : null;
    const seen = new Set(); let fresh = 0, freshX = 0; const evOn0 = !!(MU.evActive && MU.evActive()), freshMax = 10 + dtMin * (evOn0 ? 80 : 30), freshXMax = 2 + dtMin / (evOn0 ? 2 : 10);
    const before = all(prev, prevWare), after = all(sv, ware || prevWare);
    let blessUsed = cnt(before, 'bless') - cnt(after, 'bless'), soulUsed = cnt(before, 'soul') - cnt(after, 'soul');
    const fix = (it, where) => {   // devolve o item (talvez corrigido) ou null para remover
      if (!it || typeof it !== 'object') return it;
      const base = B[it.b]; if (!base) return it;
      if (it.u && seen.has(it.u)) { out.push('dup:' + it.b); return null; }
      if (it.u) seen.add(it.u);
      const old = it.u ? known.get(it.u) : null;
      if (old) {
        if (old.b !== it.b) { out.push('swap:' + it.b); return old.b && B[old.b] ? old : null; }
        if ((it.r | 0) !== (old.r | 0) || optKey(it.o) !== optKey(old.o)) { out.push('reroll:' + it.b); it.r = old.r; if (old.o) it.o = old.o; else delete it.o; }
        const p0 = old.p | 0, p1 = it.p | 0;
        if (p1 > p0) { let ok = true;
          for (let k = p0 + 1; k <= p1; k++) { if (k <= 6) continue; if (k <= 9) { if (blessUsed > 0) blessUsed--; else ok = false; } else { if (soulUsed > 0) soulUsed--; else ok = false; } }
          if (!ok || p1 - p0 > 6) { out.push('plus:' + it.b + '+' + p1); it.p = p0; } }
        return it;
      }
      // item novo
      if (base.stack) return it;   // poções/joias: quantidade conferida abaixo
      // (item novo no baú passa pelas mesmas regras do inventário: o baú agora é juntado com segurança antes daqui)
      if (base.excl === 'event' || base.excl === 'admin' || base.excl === 'rare') { out.push('excl:' + it.b); return null; }   // raríssimo: só o servidor cria (vale dinheiro real no mercado)
      if (base.excl === 'shop') return it;   // o livro-razão do mu.js decide
      if (++fresh > freshMax) { out.push('rate:' + it.b); return null; }
      const shop = SHOPSET.has(it.b) && !(it.r | 0) && !(it.p | 0) && !it.o;
      if (shop) return it;
      if (base.excl === 'drop') { if (!DROPX.has(it.b) || ++freshX > freshXMax || (it.p | 0) > 0) { out.push('dropx:' + it.b); return null; } }
      else if ((base.lvl | 0) > top + 6) { out.push('lvl:' + it.b); return null; }
      if ((it.p | 0) > 4) { out.push('plus_new:' + it.b + '+' + it.p); return null; }
      if (!optsOk(it, base)) { out.push('opts:' + it.b); return null; }
      return it;
    };
    if (Array.isArray(sv.inv)) for (let i = 0; i < sv.inv.length; i++) sv.inv[i] = fix(sv.inv[i], 'inv');
    if (sv.equip && typeof sv.equip === 'object') for (const k of Object.keys(sv.equip)) { const r = fix(sv.equip[k], 'equip'); if (r) sv.equip[k] = r; else delete sv.equip[k]; }
    if (ware) for (let i = 0; i < ware.length; i++) ware[i] = fix(ware[i], 'ware');
    // joias e itens empilháveis novos (que não existiam): limite por tempo
    for (const id of JEWELS) {
      const evOn = !!(MU.evActive && MU.evActive()), had = cnt(before, id), now = cnt(all(sv, ware || prevWare), id), lim = had + 2 + dtMin * (evOn ? 4 : 1.5) + (evOn ? 2 : 0);   // joias escassas: poucas novas por salvamento   // nos eventos caem muito mais joias
      if (now > lim) { let extra = Math.ceil(now - lim); out.push('jewels:' + id + '+' + extra);
        for (const arr of [sv.inv, ware || []]) for (let i = arr.length - 1; i >= 0 && extra > 0; i--) { const it = arr[i]; if (it && it.b === id) { const k = Math.min(extra, Math.max(1, it.q | 0)); it.q = Math.max(1, it.q | 0) - k; extra -= k; if (it.q <= 0) arr[i] = null; } } }
    }
    return out;
  }
  const orig = API['POST /api/mu/save'];
  API['POST /api/mu/save'] = async (b, req) => {
    let flagged = null, charId = 0, acc = 0;
    try {
      const t = verify(b && b.token); const row = t && await DB.charById(+b.char);
      if (row && row.account_id === t.a && b.sv && typeof b.sv === 'object') {
        charId = row.id; acc = row.account_id;
        const prev = await DB.kvGet('mu:' + row.id);
        if (prev) { const prevWare = (await DB.kvGet('muware:' + acc)) || []; const bad = check(b, prev, prevWare); if (bad.length) flagged = bad; }
      }
    } catch (e) { console.error('[antihack]', e.message); }
    const r = await orig(b, req);
    if (flagged && charId) {
      DB.log('mu_cheat', { char: charId, acc, what: flagged.slice(0, 20) }); log('[antihack] herói', charId, 'conta', acc, flagged.slice(0, 8).join(' '));
      try { const k = 'mucheat:' + acc, c = (await DB.kvGet(k)) || { n: 0, list: [] }; c.n++; c.last = Date.now(); c.list.unshift({ at: Date.now(), char: charId, what: flagged.slice(0, 10) }); c.list = c.list.slice(0, 30); await DB.kvSet(k, c); } catch (e) {}
      const j = Array.isArray(r) ? r[1] : r;
      if (j && typeof j === 'object' && !(Array.isArray(r) && r[0] >= 300)) { j.sv = await DB.kvGet('mu:' + charId); j.ware = await DB.kvGet('muware:' + acc); j.ah = flagged.length; const rk = await DB.kvGet('murank:' + charId); if (j.sv) j.sv.classRank = rk | 0; }
    }
    return r;
  };
  API['POST /api/mu/cheats'] = async (b, req) => {   // painel do dono: últimas tentativas barradas
    const [adm, err] = await admAuth(b, req); if (err) return err;
    const rows = await DB.kvList('mucheat:'); const out = [];
    for (const r of rows) { const acc = +String(r.key).split(':')[1]; const a = await DB.accountById(acc); out.push({ acc, user: a ? a.username : '?', n: r.data.n, last: r.data.last, list: (r.data.list || []).slice(0, 5) }); }
    out.sort((x, y) => (y.last || 0) - (x.last || 0)); return { list: out.slice(0, 50) };
  };
})();
/* ---- itens PREMIUM (asas só com dinheiro real) ----
   - nunca saem por cristais (mesmo chamando a rota direto);
   - no painel de ADM, só o dono (ADMIN_USER + ADMIN_EMAIL) pode dar item premium; GM não pode. */
(() => {
  const isPremium = id => { const b = MUD.BASES[id]; return !!(b && b.premium); };
  const isOwner = async token => { const t = verify(token); if (!t) return false; const a = await DB.accountById(t.a); return !!a && String(a.ulow || a.username || '').toLowerCase() === ADM_USER && String(a.email || '').toLowerCase() === ADM_MAIL; };
  const buy = API['POST /api/mu/buycry'];
  if (buy) API['POST /api/mu/buycry'] = async (b, req) => {
    const p = MUD.MU_SHOP_BY_ID[String((b && b.id) || '')];
    if (p && (p.realOnly || (p.give || []).some(g => isPremium(g.b)))) return [403, { error: 'real_only' }];
    return buy(b, req);
  };
  const adm = API['POST /api/mu/admin'];
  if (adm) API['POST /api/mu/admin'] = async (b, req) => {
    const ids = [b && b.item, b && b.b, b && b.id, b && b.base].filter(x => typeof x === 'string');
    if (ids.some(isPremium) && !(await isOwner(b.token))) { DB.log('mu_premium_denied', { ids }); return [403, { error: 'premium_owner_only' }]; }
    const r = await adm(b, req);
    try {   // item da loja dado pelo dono: entra no livro-razão para não ser apagado no próximo salvamento
      const j = Array.isArray(r) ? (r[0] < 300 ? r[1] : null) : r, t = verify(b.token);
      if (j && j.sv && t) { const row = await DB.charById(+b.char); if (row && row.account_id === t.a) {
        const k = 'muown:' + row.account_id, own = (await DB.kvGet(k)) || {}; let ch = 0;
        for (const it of [...(j.sv.inv || []), ...Object.values(j.sv.equip || {})]) if (it && it.u && MUD.BASES[it.b] && MUD.BASES[it.b].excl === 'shop' && !own[it.u]) { own[it.u] = 'c' + row.id; ch++; }
        if (ch) await DB.kvSet(k, own); } }
    } catch (e) { console.error('[adm ledger]', e.message); }
    return r;
  };
})();
/* ---- skills acima de 10 com a evolução de classe: 10 (classe base) / 20 (2ª classe) / 30 (3ª classe) ----
   O mu.js guarda no máximo 10 por skill; o que passa de 10 fica em kv "muskill:<herói>" e volta em todo load/save. */
(() => {
  const SK = id => 'muskill:' + id, cap = r => [10, 20, 30][Math.max(0, Math.min(2, r | 0))];
  const allowed = (lv, rs) => Math.floor((lv | 0) / 3) + (rs | 0) * MUD.CFG.SKILL_PER_RESET;
  const sum = o => Object.values(o || {}).reduce((a, b) => a + (b | 0), 0);
  const inject = async (charId, j) => {
    if (!charId || !j || typeof j !== 'object' || !j.sv || !j.sv.skills) return j;
    const ex = (await DB.kvGet(SK(charId))) || {}; let used = 0;
    for (const id in ex) if ((j.sv.skills[id] | 0) >= 10) { j.sv.skills[id] = 10 + (ex[id] | 0); used += ex[id] | 0; }
    j.sv.sp = Math.max(0, (j.sv.sp | 0) - used); return j;
  };
  const wrap = (key, before) => { const orig = API[key]; if (!orig) return; API[key] = async (b, req) => {
    const charId = +(b && b.char) || 0; if (before && charId) { try { await before(b); } catch (e) { console.error('[mu skill]', e.message); } }
    const r = await orig(b, req); if (Array.isArray(r)) { if (r[0] < 300) await inject(charId, r[1]); return r; } return inject(charId, r); }; };
  wrap('POST /api/mu/load');
  wrap('POST /api/mu/save', async b => {
    const t = verify(b.token); if (!t || !b.sv || !b.sv.skills || typeof b.sv.skills !== 'object') return;
    const row = await DB.charById(+b.char); if (!row || row.account_id !== t.a) return;
    const prev = await DB.kvGet('mu:' + row.id); if (!prev) return;
    const C = cap(await DB.kvGet('murank:' + row.id)), ex = {};
    for (const id of Object.keys(b.sv.skills)) { const r = Math.max(0, Math.min(C, Math.floor(+b.sv.skills[id] || 0))); if (r > 10) { ex[id] = r - 10; b.sv.skills[id] = 10; } else b.sv.skills[id] = r; }
    const total = sum(b.sv.skills) + sum(ex);
    const ok = total <= allowed(Math.max(prev.level | 0, b.sv.level | 0), Math.max(prev.resets | 0, b.sv.resets | 0));
    const keep = ok ? ex : ((await DB.kvGet(SK(row.id))) || {});
    await DB.kvSet(SK(row.id), keep);
    b.sv.sp = (b.sv.sp | 0) + sum(keep);   // o mu.js só enxerga até 10; os pontos dos ranks extras continuam gastos
  });
})();
(() => { const c = API['GET /api/mu/config']; if (c) API['GET /api/mu/config'] = async (b, req) => { const r = await c(b, req); if (r && typeof r === 'object' && !Array.isArray(r)) { r.fx = SHOP.fx; r.curs = SHOP.curs; } return r; };
  const k = API['GET /api/mu/catalog']; if (k) API['GET /api/mu/catalog'] = async (b, req) => { const r = await k(b, req); if (r && typeof r === 'object' && !Array.isArray(r)) { r.fx = SHOP.fx; r.cur = 'usd'; r.curs = SHOP.curs; if (Array.isArray(r.items)) r.items = r.items.filter(p => !p.noSale); } return r; };
  const l = API['POST /api/mu/load']; if (l) API['POST /api/mu/load'] = async (b, req) => { const r = await l(b, req); const j = Array.isArray(r) ? r[1] : r; if (j && j.cfg) { j.cfg.fx = SHOP.fx; j.cfg.curs = SHOP.curs; } return r; };
})();
/* ---- evolução de classe feita pelo servidor: confere nível e Zen, cobra e grava na hora ---- */
API['POST /api/mu/evolve'] = async (b, req) => {
  if (limited(ipOf(req), 20)) return [429, { error: 'rate' }];
  const t = verify(b.token); if (!t) return [401, { error: 'auth' }];
  const row = await DB.charById(+b.char); if (!row || row.account_id !== t.a) return [400, { error: 'char' }];
  const sv = await DB.kvGet('mu:' + row.id); if (!sv) return [400, { error: 'char' }];
  const cur = (await DB.kvGet('murank:' + row.id)) | 0; if (cur >= 2) return [400, { error: 'max' }];
  const E = MUD.CLASS_EVO[cur + 1];
  if (!((sv.level | 0) >= E.lvl || (sv.resets | 0) > 0)) return [400, { error: 'level', need: E.lvl }];
  if ((+sv.gold || 0) < E.fee) return [400, { error: 'gold', need: E.fee }];
  sv.gold = Math.floor((+sv.gold || 0) - E.fee);
  await DB.kvSet('mu:' + row.id, sv); await DB.kvSet('murank:' + row.id, cur + 1);
  DB.log('mu_evolve', { char: row.id, rank: cur + 1, via: 'npc' });
  return { ok: true, classRank: cur + 1, sv: await muOutSv(row.id, sv) };
};
/* cópia do herói do jeito que o jogo espera (evolução + pontos extras de skill já colocados) */
async function muOutSv(charId, sv) {
  const out = JSON.parse(JSON.stringify(sv)); out.classRank = (await DB.kvGet('murank:' + charId)) | 0;
  const ex = (await DB.kvGet('muskill:' + charId)) || {}; let used = 0; out.skills = out.skills || {};
  for (const id in ex) if ((out.skills[id] | 0) >= 10) { out.skills[id] = 10 + (ex[id] | 0); used += ex[id] | 0; }
  out.sp = Math.max(0, (out.sp | 0) - used);
  const vx = await DB.kvGet('muvx:' + charId); if (vx) muInjectVX(out, vx);
  const sb = await DB.kvGet('musbar:' + charId); if (Array.isArray(sb)) out.sbar = sb;
  return out;
}
/* VIP: pontos extras de reset ficam guardados à parte (o mu.js só conhece 500 por reset) e voltam em todo load/save */
function muInjectVX(sv, vx) { if (!sv || !vx) return sv; let used = 0; for (const k of ['str', 'agi', 'vit', 'ene']) { const a = (vx.st && vx.st[k]) | 0; sv[k] = (sv[k] | 0) + a; used += a; } const P = vx.pool | 0; sv.points = P < 0 ? Math.max(0, (sv.points | 0) + P) : (sv.points | 0) + Math.max(0, P - used); return sv; }   // reserva negativa = pontos tirados pelo Master Reset
/* NPC: "Vender vários itens" — a venda em lote é feita aqui no servidor, com o preço calculado aqui,
   para o Zen não ser cortado pelo limite de ganho por salvamento e ninguém conseguir inventar preço. */
API['POST /api/mu/sell'] = async (b, req) => {
  if (limited(ipOf(req), 40)) return [429, { error: 'rate' }];
  const t = verify(b.token); if (!t) return [401, { error: 'auth' }];
  const row = await DB.charById(+b.char); if (!row || row.account_id !== t.a) return [400, { error: 'char' }];
  const want = Array.isArray(b.uids) ? [...new Set(b.uids.map(String))].slice(0, 200) : []; if (!want.length) return [400, { error: 'empty' }];
  const sv = await DB.kvGet('mu:' + row.id); if (!sv || !Array.isArray(sv.inv)) return [400, { error: 'char' }];
  let zen = 0; const sold = [];
  for (const u of want) {
    const i = sv.inv.findIndex(x => x && String(x.u) === u); if (i < 0) continue;
    const it = sv.inv[i], B = MUD.BASES[it.b]; if (!B || B.cat === 'quest' || B.excl === 'shop') continue;
    const p = Math.max(0, Math.floor(MUD.sellPrice(it) * Math.max(1, it.q | 0))); if (!p) continue;
    zen += p; sold.push({ b: it.b, q: it.q | 0, r: it.r | 0, p: it.p | 0, u: it.u }); sv.inv[i] = null;
  }
  if (!sold.length) return [400, { error: 'nothing' }];
  const before = +sv.gold || 0; sv.gold = Math.min(2e9, before + zen);
  await DB.kvSet('mu:' + row.id, sv);
  DB.log('mu_sell', { char: row.id, n: sold.length, zen, got: sv.gold - before, items: sold.slice(0, 60) });
  return { ok: true, n: sold.length, zen, got: sv.gold - before, sv: await muOutSv(row.id, sv) };
};
/* ===== BOSSES DOS MAPAS (drop excelente) + EVENTOS DE 5 MINUTOS + MERCADO DE JOIAS =====
   - cada mapa com chefe tem 1 chefe "do servidor": quem matar primeiro ganha 1 item excelente (e às vezes um exclusivo) e o nome sai no chat;
     depois ele some da lista até renascer (20 a 60 minutos, conforme o nível);
   - a cada 30 minutos um evento de 5 minutos (Invasão Dourada / Chuva de Joias), avisado no chat;
   - mercado de joias entre jogadores: o vendedor anuncia, o comprador paga em Zen, o vendedor recebe no próximo salvamento. */
(() => {
  const D = MUD, INV = D.CFG.INV || 48;
  const BOSSES = [];
  for (const id of (D.MAP_ORDER || Object.keys(D.MAPS))) { const m = D.MAPS[id]; if (!m) continue; const bs = (m.spawns || []).filter(sp => D.MONS[sp.t] && D.MONS[sp.t].boss && (sp.n | 0) === 1).sort((x, y) => y.lvl - x.lvl)[0]; if (bs) BOSSES.push({ map: id, type: bs.t, lvl: bs.lvl | 0, name: D.MONS[bs.t].name, mapName: m.name }); }
  const respawnMs = b => (20 + Math.min(40, Math.floor(b.lvl / 25))) * 60000;
  let BS = {}, bsLoaded = null;
  const loadBS = () => bsLoaded || (bsLoaded = DB.kvGet('muboss').then(v => { BS = v || {}; }).catch(() => {}));
  const saveBS = () => DB.kvSet('muboss', BS).catch(() => {});
  const bossAlive = (map, t = Date.now()) => !BS[map] || !(BS[map].until > t);
  const wsAll = data => { for (const q of muRTPlayers.values()) if (q.ws && q.ws.open !== false) { try { q.ws.send(data); } catch (_) {} } };
  const announce = (text, k, a) => { const m = { id: ++muMsgId, t: Date.now(), n: '', x: text, gm: 0, sys: 1, k: k || '', a: Array.isArray(a) ? a.map(String) : [] }; muMsgs.push(m); while (muMsgs.length > 80) muMsgs.shift(); };
  MU.announce = announce;
  /* ---- eventos ---- */
  const EV_EVERY = 20 * 60000, EV_LEN = 5 * 60000;
  const EV_TYPES = [{ id: 'golden', name: 'Golden Invasion', desc: 'Golden monsters appear on every map: much more experience, Zen and jewels.' },
                    { id: 'jewel', name: 'Jewel Rain', desc: 'For 5 minutes every monster has a 1% chance to drop an extra jewel.' },
                    { id: 'chaos', name: 'Chaos Invasion', desc: 'Hordes of chaos invaders attack every map: lots of items, Excellent drops and jewels.' }];
  MU.evActive = () => evAt().active;
  const evAt = (t = Date.now()) => { const slot = Math.floor(t / EV_EVERY), start = slot * EV_EVERY, T = EV_TYPES[slot % EV_TYPES.length], N = EV_TYPES[(slot + 1) % EV_TYPES.length];
    return { active: t - start < EV_LEN ? { id: T.id, name: T.name, desc: T.desc, until: start + EV_LEN } : null, next: { id: N.id, name: N.name, at: start + EV_EVERY } }; };
  let evSaid = { warn: 0, start: 0, end: 0 };
  setInterval(() => {
    const t = Date.now(), e = evAt(t), slot = Math.floor(t / EV_EVERY);
    if (e.active && evSaid.start !== slot) { evSaid.start = slot; announce('⏰ EVENT: ' + e.active.name + ' has started! ' + e.active.desc + ' (5 minutes)', '⏰ EVENT: {0} has started! {1} (5 minutes)', [e.active.name, e.active.desc]); wsAll({ t: 'mev', ev: e.active }); }
    if (!e.active && evSaid.end !== slot && t - slot * EV_EVERY < EV_LEN + 20000) { evSaid.end = slot; announce('⏰ The event has ended. Next: ' + e.next.name + ' in 15 minutes.', '⏰ The event has ended. Next: {0} in 15 minutes.', [e.next.name]); wsAll({ t: 'mev', ev: null }); }
    if (!e.active && e.next.at - t < 120000 && evSaid.warn !== slot) { evSaid.warn = slot; announce('⏰ ' + e.next.name + ' starts in 2 minutes!', '⏰ {0} starts in 2 minutes!', [e.next.name]); }
  }, 5000).unref?.();
  const bossView = t => BOSSES.map(b => { const st = BS[b.map]; const alive = bossAlive(b.map, t); return { map: b.map, mapName: b.mapName, name: b.name, lvl: b.lvl, alive, by: alive ? '' : st.by, until: alive ? 0 : st.until }; });
  API['GET /api/mu/bosses'] = async () => { await loadBS(); const t = Date.now(); const e = evAt(t); return { now: t, bosses: bossView(t), ev: e.active, next: e.next }; };
  /* agenda dos próximos eventos (para a aba de eventos) */
  API['GET /api/mu/schedule'] = async () => { const t = Date.now(), slot = Math.floor(t / EV_EVERY), out = [];
    for (let i = 0; i < 9; i++) { const st = (slot + i) * EV_EVERY, T = EV_TYPES[(slot + i) % EV_TYPES.length]; if (st + EV_LEN < t) continue; out.push({ id: T.id, name: T.name, desc: T.desc, start: st, end: st + EV_LEN, on: st <= t && t < st + EV_LEN }); }
    return { now: t, every: EV_EVERY, len: EV_LEN, list: out.slice(0, 8) }; };
  /* ---- inventário no servidor ---- */
  const fits = (inv, b, q) => { const B = D.BASES[b]; let free = 0; for (let i = 0; i < INV; i++) { const x = inv[i]; if (!x) free += B.stack ? 99 : 1; else if (B.stack && x.b === b) free += 99 - (x.q | 0); } return free >= q; };
  const addInv = (sv, it) => { sv.inv = Array.isArray(sv.inv) ? sv.inv : []; while (sv.inv.length < INV) sv.inv.push(null); const B = D.BASES[it.b];
    if (B.stack) { let q = it.q | 0 || 1; for (let i = 0; i < INV && q > 0; i++) { const x = sv.inv[i]; if (x && x.b === it.b && (x.q | 0) < 99) { const n = Math.min(q, 99 - (x.q | 0)); x.q = (x.q | 0) + n; q -= n; } }
      for (let i = 0; i < INV && q > 0; i++) if (!sv.inv[i]) { const n = Math.min(q, 99); sv.inv[i] = D.makeItem(it.b, 0, 0, n); q -= n; } return q <= 0; }
    const i = sv.inv.findIndex((x, k) => k < INV && !x); if (i < 0) return false; sv.inv[i] = it; return true; };
  const countInv = (sv, b) => (sv.inv || []).reduce((a, x) => a + (x && x.b === b ? (x.q | 0) || 1 : 0), 0);
  const takeInv = (sv, b, q) => { for (let i = (sv.inv || []).length - 1; i >= 0 && q > 0; i--) { const x = sv.inv[i]; if (x && x.b === b) { const n = Math.min(q, (x.q | 0) || 1); x.q = ((x.q | 0) || 1) - n; q -= n; if (x.q <= 0) sv.inv[i] = null; } } return q <= 0; };
  const pick = a => a[Math.floor(Math.random() * a.length)];
  function bossItem(lvl, cls) {
    let tier = 0; for (let t = 0; t < D.TIER_LVL.length; t++) if (D.TIER_LVL[t] <= lvl + 4) tier = t;
    let cat = pick(['sword', 'staff', 'bow', 'shield', 'helm', 'armor', 'pants', 'gloves', 'boots', 'helm', 'armor', 'pants', 'gloves', 'boots']);
    if (Math.random() < .4) cat = cls === 'elf' ? 'bow' : cls === 'dw' ? 'staff' : 'sword';
    let id = cat + '_' + tier; if (!D.BASES[id]) id = cat + '_0'; if (!D.BASES[id]) id = 'sword_0';
    const x = Math.random(), r = x < .6 ? 3 : x < .88 ? 4 : x < .98 ? 5 : 6;
    return D.makeItem(id, r, Math.floor(Math.random() * 5));
  }
  const lastKill = new Map();
  API['POST /api/mu/bosskill'] = async (b, req) => {
    if (limited(ipOf(req), 30)) return [429, { error: 'rate' }];
    const t0 = verify(b.token); if (!t0) return [401, { error: 'auth' }];
    const row = await DB.charById(+b.char); if (!row || row.account_id !== t0.a) return [400, { error: 'char' }];
    await loadBS(); const map = String(b.map || ''), boss = BOSSES.find(x => x.map === map); if (!boss) return [400, { error: 'no_boss' }];
    const t = Date.now(); if (t - (lastKill.get(row.id) || 0) < 15000) return [429, { error: 'rate' }];
    if (!bossAlive(map, t)) return [409, { error: 'dead', by: BS[map].by, until: BS[map].until }];
    const sv = await DB.kvGet('mu:' + row.id); if (!sv) return [400, { error: 'char' }];
    const p = muRTPlayers.get(row.id);   // precisa estar no mapa: pela conexão em tempo real OU pelo último salvamento (a conexão pode ter caído por um instante bem na hora da morte do chefe)
    if (!((p && p.map === map) || (sv.map === map && t - (+sv.t || 0) < 3 * 60000))) return [400, { error: 'not_here' }];
    if (!((sv.level | 0) >= boss.lvl - 40 || (sv.resets | 0) > 0)) return [400, { error: 'level' }];
    const free = (sv.inv || []).slice(0, INV).filter(x => !x).length + Math.max(0, INV - (sv.inv || []).length);
    if (free < 2) return [400, { error: 'inv_full' }];
    lastKill.set(row.id, t);
    BS[map] = { deadAt: t, until: t + respawnMs(boss), by: sv.name }; saveBS();
    try { const bk = (await DB.kvGet('mubosskills')) || {}; bk[row.id] = (bk[row.id] | 0) + 1; await DB.kvSet('mubosskills', bk); } catch (_) {}
    const got = [], it = bossItem(boss.lvl, sv.cls); if (addInv(sv, it)) got.push(it);
    if (Math.random() < .2 && D.DROP_EXCL && D.DROP_EXCL.boss) { const xi = D.makeItem(pick(D.DROP_EXCL.boss), Math.random() < .6 ? 4 : 5, 0); if (xi && addInv(sv, xi)) got.push(xi); }
    let vb = 0; try { if (MU.vipOf) { const vt = (await MU.vipOf(row.account_id)).tier; vb = vt ? D.VIP_TIERS[vt].boss : 0; } } catch (_) {}
    if (vb >= 2) { const it2 = bossItem(boss.lvl, sv.cls); if (addInv(sv, it2)) got.push(it2); }   // VIP Gold: um 2º item excelente
    for (const [jb, q] of [['bless', 2 * (1 + vb)], ['soul', 1 + vb]]) if (fits(sv.inv, jb, q) && addInv(sv, { b: jb, q })) got.push({ b: jb, q });
    await DB.kvSet('mu:' + row.id, sv);
    const names = got.map(x => D.itemName ? D.itemName(x) + (x.q > 1 ? ' ×' + x.q : '') : x.b);
    announce('👑 ' + sv.name + ' defeated ' + boss.name + ' (' + boss.mapName + ') and won ' + names[0] + '!', '👑 {0} defeated {1} ({2}) and won {3}!', [sv.name, boss.name, boss.mapName, names[0]]);
    wsAll({ t: 'mboss', map, alive: false, by: sv.name, until: BS[map].until });
    DB.log('mu_boss', { char: row.id, map, items: got.map(x => ({ b: x.b, r: x.r | 0, p: x.p | 0, q: x.q | 0 })) });
    return { ok: true, items: names, until: BS[map].until, sv: await muOutSv(row.id, sv) };
  };
  /* ---- mercado de joias ---- */
  const JEWELS = Object.keys(D.BASES).filter(k => D.BASES[k].cat === 'jewel' && !D.BASES[k].excl);
  let JM = null; const loadJM = async () => { if (!JM) { JM = (await DB.kvGet('mujm').catch(() => null)) || { seq: 1, list: [] }; } return JM; };
  const saveJM = () => DB.kvSet('mujm', JM).catch(() => {});
  const view = l => ({ id: l.id, b: l.b, q: l.q, ppu: l.ppu, sn: l.sn, mine: 0, at: l.at });
  API['POST /api/mu/jm'] = async (b, req) => {
    if (limited(ipOf(req), 60)) return [429, { error: 'rate' }];
    const t0 = verify(b.token); if (!t0) return [401, { error: 'auth' }];
    const row = await DB.charById(+b.char); if (!row || row.account_id !== t0.a) return [400, { error: 'char' }];
    await loadJM(); const act = String(b.action || 'list');
    const out = async extra => { const list = JM.list.slice().sort((a, c) => a.b.localeCompare(c.b) || a.ppu - c.ppu).map(l => Object.assign(view(l), { mine: l.sid === row.id ? 1 : 0 }));
      return Object.assign({ ok: true, jewels: JEWELS, list, pay: (await DB.kvGet('mupay:' + row.id)) | 0 }, extra || {}); };
    if (act === 'list') return out();
    const sv = await DB.kvGet('mu:' + row.id); if (!sv) return [400, { error: 'char' }];
    if (act === 'sell') {
      const jb = String(b.b || ''), q = Math.floor(+b.q || 0), ppu = Math.floor(+b.ppu || 0);
      if (!JEWELS.includes(jb)) return [400, { error: 'jewel' }];
      if (q < 1 || q > 999) return [400, { error: 'qty' }];
      if (ppu < 1 || ppu > 100000000 || q * ppu > 2e9) return [400, { error: 'price' }];
      if (JM.list.filter(l => l.sid === row.id).length >= 10) return [400, { error: 'max_listings' }];
      if (countInv(sv, jb) < q) return [400, { error: 'not_enough' }];
      takeInv(sv, jb, q); await DB.kvSet('mu:' + row.id, sv);
      const l = { id: JM.seq++, sid: row.id, sn: sv.name, b: jb, q, ppu, at: Date.now() }; JM.list.push(l); while (JM.list.length > 600) JM.list.shift(); saveJM();
      DB.log('mu_jm_sell', { char: row.id, b: jb, q, ppu });
      return out({ sv: await muOutSv(row.id, sv), done: 'listed' });
    }
    const l = JM.list.find(x => x.id === +b.id); if (!l) return [404, { error: 'gone' }];
    if (act === 'cancel') {
      if (l.sid !== row.id) return [403, { error: 'owner' }];
      if (!fits(sv.inv, l.b, l.q)) return [400, { error: 'inv_full' }];
      addInv(sv, { b: l.b, q: l.q }); JM.list = JM.list.filter(x => x !== l); saveJM(); await DB.kvSet('mu:' + row.id, sv);
      return out({ sv: await muOutSv(row.id, sv), done: 'canceled' });
    }
    if (act === 'buy') {
      if (l.sid === row.id) return [400, { error: 'own' }];
      const q = Math.max(1, Math.min(l.q, Math.floor(+b.q || l.q))), cost = q * l.ppu;
      if ((+sv.gold || 0) < cost) return [400, { error: 'gold' }];
      if (!fits(sv.inv, l.b, q)) return [400, { error: 'inv_full' }];
      sv.gold = Math.floor((+sv.gold || 0) - cost); addInv(sv, { b: l.b, q }); l.q -= q; if (l.q <= 0) JM.list = JM.list.filter(x => x !== l); saveJM();
      await DB.kvSet('mu:' + row.id, sv);
      const pk = 'mupay:' + l.sid; await DB.kvSet(pk, ((await DB.kvGet(pk)) | 0) + cost);
      DB.log('mu_jm_buy', { buyer: row.id, seller: l.sid, b: l.b, q, cost });
      return out({ sv: await muOutSv(row.id, sv), done: 'bought', q, cost });
    }
    return [400, { error: 'action' }];
  };
  /* o vendedor recebe o Zen das vendas no próximo salvamento */
  const origSave = API['POST /api/mu/save'];
  API['POST /api/mu/save'] = async (b, req) => {
    const r = await origSave(b, req);
    try {
      const ok = !Array.isArray(r) || r[0] < 300, j = Array.isArray(r) ? r[1] : r, id = +(b && b.char) || 0;
      if (ok && j && j.ok !== false && id) { const pay = (await DB.kvGet('mupay:' + id)) | 0;
        if (pay > 0) { const sv = await DB.kvGet('mu:' + id); if (sv) { const before = +sv.gold || 0; sv.gold = Math.min(2e9, before + pay); await DB.kvSet('mu:' + id, sv); await DB.kvSet('mupay:' + id, 0); j.sv = await muOutSv(id, sv); j.paid = pay; DB.log('mu_jm_pay', { char: id, pay }); } } }
    } catch (e) { console.error('[mu pay]', e.message); }
    return r;
  };
})();
/* ===== VIP Platinum / VIP Gold =====
   - comprado com dinheiro real (Stripe) para a CONTA inteira; 15 ou 30 dias, somando se renovar;
   - XP 5x / 12x, reset no nível 550 / 390, 13 mil / 27 mil pontos por reset, set + asa exclusivos (só na 1ª compra de cada plano);
   - selo PLATINUM / GOLD em cima da cabeça que todos veem. */
(() => {
  const D = MUD, V = D.VIP_TIERS, RP = D.CFG.REBIRTH_POINTS, RL = D.CFG.REBIRTH_LVL, K = ['str', 'agi', 'vit', 'ene'];
  const RLIM = 0, RWIN = 8 * 3600e3;   // limite de resets da conta free a cada 8 horas (0 = sem limite; hoje o free reseta quantas vezes quiser, a diferença é o EXP: free 1x, Platinum 3x, Gold 6x)
  const resetLog = async id => { const a = await DB.kvGet('mureset:' + id); return (Array.isArray(a) ? a : []).filter(t => t > Date.now() - RWIN).sort((x, y) => x - y); };
  const vipOf = async acc => { const v = (await DB.kvGet('muvip:' + acc)) || {}, t = Date.now(); return { tier: D.vipTierOf(v, t), gold: v.gold || 0, pm: v.pm || 0, plat: v.plat || 0, free: (v.free || 0) > t ? v.free : 0 }; };
  MU.vipOf = vipOf;
  const getVX = async id => { const v = (await DB.kvGet('muvx:' + id)) || {}; return { pool: v.pool | 0, st: v.st || {}, lg2: v.lg2 | 0 }; };
  const capOf = (cls, l, r) => { const C = D.CLASSES[cls], b = C.base; return b.str + b.agi + b.vit + b.ene + (l - 1) * C.pts + r * RP; };
  /* pontos por reset mudaram (free 800 / Platinum 1.400 / Gold 2.000): quem já tinha mais pontos pela regra antiga não perde nada,
     a diferença vai para a reserva do herói (mesma reserva dos pontos VIP), uma única vez */
  async function legacyRP(id) {
    const vx = await getVX(id); if (vx.lg2) return vx;
    const prev = await DB.kvGet('mu:' + id); if (!prev || !D.CLASSES[prev.cls]) return vx;
    let tot = prev.points | 0; for (const k of K) tot += Math.max(0, +prev[k] || 0);
    const extra = Math.max(0, tot - capOf(prev.cls, Math.max(1, prev.level | 0), prev.resets | 0));
    vx.pool += extra; vx.lg2 = 1;
    let sum = 0; for (const k of K) sum += Math.max(0, +prev[k] || 0);
    const capN = capOf(prev.cls, Math.max(1, prev.level | 0), prev.resets | 0), E = Math.max(0, sum - capN);
    if (E > 0) {   // a parte dos atributos que passa da nova regra fica guardada na reserva (vx.st), igual aos pontos VIP
      const base = D.CLASSES[prev.cls].base, above = K.map(k => Math.max(0, (+prev[k] || 0) - base[k])), ta = above.reduce((x, y) => x + y, 0) || 1, st = {}; let left = E;
      K.forEach((k, i) => { st[k] = Math.min(above[i], Math.floor(E * above[i] / ta)); left -= st[k]; });
      K.forEach((k, i) => { if (left > 0) { const m = Math.min(left, above[i] - st[k]); st[k] += m; left -= m; } });
      vx.st = vx.st || {}; for (const k of K) { prev[k] = (+prev[k] || 0) - st[k]; vx.st[k] = (vx.st[k] | 0) + st[k]; }
      prev.points = Math.max(0, capN - (sum - E)); await DB.kvSet('mu:' + id, prev);
    }
    await DB.kvSet('muvx:' + id, vx); if (extra) DB.log('mu_rp_legacy', { char: id, extra, moved: E });
    return vx;
  }
  const refreshRT = async acc => { const v = await vipOf(acc); for (const q of muRTPlayers.values()) if (q.acc === acc) { q.vip = v.tier || (v.free ? 'free' : ''); muSendMap(muK(q), { t: 'pvp_state', ...muPublic(q) }); } };
  async function vipAdd(charId, pv) {
    const row = await DB.charById(charId); if (!row) return; const acc = row.account_id;
    const k = 'muvip:' + acc, v = (await DB.kvGet(k)) || {}, t = Date.now();
    v[pv.tier] = Math.max(t, v[pv.tier] || 0) + pv.days * 864e5;
    // VIP competitivo: somente benefícios de conta; nunca entrega set, equipamento, asas ou joias de set.
    await DB.kvSet(k, v); DB.log('mu_vip', { acc, char: charId, tier: pv.tier, days: pv.days, until: v[pv.tier], setGranted: false });
    const sv = await DB.kvGet('mu:' + charId); if (MU.announce) MU.announce('🌟 ' + ((sv && sv.name) || 'A hero') + ' is now ' + V[pv.tier].name + '!', '🌟 {0} is now {1}!', [(sv && sv.name) || 'A hero', V[pv.tier].name]);
    await refreshRT(acc);
  }
  const origGrant = MU.grant;
  MU.grant = async (charId, id, src) => { const p = D.MU_SHOP_BY_ID[id]; if (p && p.noSale && src !== 'vip') throw new Error('produto não vendável: ' + id);
    const r = await origGrant(charId, id, src); if (p && p.vip) await vipAdd(charId, p.vip); if (p && p.xring) await xrAdd(charId, p.xring); return r; };
  const origProduct = MU.product; if (origProduct) MU.product = id => { const p = D.MU_SHOP_BY_ID[id]; if (p && p.noSale) return null; return origProduct(id); };
  /* presente diário do VIP: joias + Zen, 1 vez por dia por conta */
  API['POST /api/mu/vipdaily'] = async (b, req) => {
    if (limited(ipOf(req), 20)) return [429, { error: 'rate' }];
    const t = verify(b.token); if (!t) return [401, { error: 'auth' }];
    const row = await DB.charById(+b.char); if (!row || row.account_id !== t.a) return [400, { error: 'char' }];
    const v = await vipOf(row.account_id); if (!v.tier) return [403, { error: 'novip' }];
    const day = new Date(Date.now() - 3 * 3600e3).toISOString().slice(0, 10), dk = 'muvipday:' + row.account_id;
    if ((await DB.kvGet(dk)) === day) return [409, { error: 'done' }];
    const sv = await DB.kvGet('mu:' + row.id); if (!sv) return [400, { error: 'char' }];
    const G = V[v.tier].daily, INV = D.CFG.INV; sv.inv = Array.isArray(sv.inv) ? sv.inv : [];
    const need = ['bless', 'soul', 'chaos'].filter(k => G[k] > 0).length;
    if (sv.inv.slice(0, INV).filter(x => !x).length + Math.max(0, INV - sv.inv.length) < need) return [400, { error: 'inv_full' }];
    for (const k of ['bless', 'soul', 'chaos']) if (G[k] > 0) { const i = sv.inv.findIndex((x, n) => n < INV && !x); const it = D.makeItem(k, 0, 0, G[k]); if (i >= 0) sv.inv[i] = it; else sv.inv.push(it); }
    sv.gold = Math.min(2e9, (+sv.gold || 0) + G.zen);
    await DB.kvSet('mu:' + row.id, sv); await DB.kvSet(dk, day);
    DB.log('mu_vip_daily', { char: row.id, tier: v.tier });
    return { ok: true, gift: G, sv: await muOutSv(row.id, sv) };
  };
  /* ===== MASTER RESET =====
     Requisitos (conferidos aqui no servidor): nível 1000 e Força, Agilidade, Vitalidade e Energia em 65.000.
     Resultado: nível 1, atributos iniciais da classe, 0 pontos livres (reserva negativa = os pontos de reset/VIP somem),
     +1 no contador e 1 item Master (configurável pelo dono). Equipamentos, inventário, skills, Zen e nº de resets ficam. */
  const MRK = id => 'mumr:' + id, mrBusy = new Set();
  async function mrItemFor(cls, n) {
    const cfg = (await DB.kvGet('mumrcfg')) || {}, list = (Array.isArray(cfg.items) ? cfg.items : []).filter(x => D.BASES[x] && D.BASES[x].equip);
    const L = list.length ? list : D.mrRewardsFor(cls); return L[(n - 1) % L.length];
  }
  async function mrDeliver(id, acc, sv, st, ware) {   // coloca as recompensas pendentes no inventário (cada uma tem uid fixo: nunca vira duas)
    if (!st.pend || !st.pend.length) return 0; sv.inv = Array.isArray(sv.inv) ? sv.inv : []; const INV = D.CFG.INV; let own = null, n = 0;
    const has = u => [...sv.inv, ...Object.values(sv.equip || {}), ...(ware || [])].some(x => x && x.u === u);
    while (st.pend.length) {
      const pd = st.pend[0], B = D.BASES[pd.b]; if (!B) { st.pend.shift(); continue; }
      if (has(pd.u)) { st.pend.shift(); continue; }   // já foi entregue
      const i = sv.inv.findIndex((x, j) => j < INV && !x); if (i < 0 && sv.inv.length >= INV) break;
      const it = D.makeItem(pd.b, 6, 15); it.u = pd.u;
      if (B.excl === 'shop') { own = own || (await DB.kvGet('muown:' + acc)) || {}; own[it.u] = 'c' + id; }
      if (i >= 0) sv.inv[i] = it; else sv.inv.push(it); st.pend.shift(); st.got = (st.got | 0) + 1; n++;
    }
    if (own) await DB.kvSet('muown:' + acc, own); return n;
  }
  async function mrAutoDeliver(id, acc) {
    const st = await DB.kvGet(MRK(id)); if (!st || !st.pend || !st.pend.length || mrBusy.has(id)) return 0;
    mrBusy.add(id); try { const sv = await DB.kvGet('mu:' + id); if (!sv) return 0; const n = await mrDeliver(id, acc, sv, st, await DB.kvGet('muware:' + acc));
      if (n) { await DB.kvSet('mu:' + id, sv); await DB.kvSet(MRK(id), st); DB.log('mu_master_reward', { char: id, n }); } return n; } finally { mrBusy.delete(id); }
  }
  MU.mrAutoDeliver = mrAutoDeliver;
  const mrAuth = async b => { const t = verify(b && b.token); if (!t) return [null, [401, { error: 'auth' }]]; const id = +(b && b.char) || 0, row = id ? await DB.charById(id) : null;
    if (!row || row.account_id !== t.a) return [null, [400, { error: 'char' }]]; return [row, null]; };
  API['POST /api/mu/master'] = async (b, req) => {
    if (limited(ipOf(req), 20)) return [429, { error: 'rate' }];
    const [row, err] = await mrAuth(b); if (err) return err; const id = row.id;
    if (mrBusy.has(id)) return [409, { error: 'busy' }]; mrBusy.add(id);   // nunca dois Master Resets ao mesmo tempo
    try {
      const vx = await legacyRP(id), sv = await DB.kvGet('mu:' + id); if (!sv || !D.CLASSES[sv.cls]) return [400, { error: 'char' }];
      const LV = D.CFG.LEVEL_CAP, SM = D.CFG.STAT_MAX || 65000, cur = await muOutSv(id, sv), miss = [];
      if ((cur.level | 0) < LV) miss.push({ k: 'level', have: cur.level | 0, need: LV });
      for (const k of K) if ((cur[k] | 0) < SM) miss.push({ k, have: cur[k] | 0, need: SM });
      const st = (await DB.kvGet(MRK(id))) || {}; st.count = st.count | 0; st.pend = Array.isArray(st.pend) ? st.pend : []; st.log = Array.isArray(st.log) ? st.log : [];
      const cdMs = (D.MR_WAIT_H || 2) * 36e5, last = (st.log[0] && st.log[0].at) || 0;   // no mínimo 2 horas entre dois Master Resets do mesmo herói
      if (Date.now() - last < cdMs) return [400, { error: 'mr_wait', wait: cdMs - (Date.now() - last) }];
      if (miss.length) return [400, { error: 'req', miss }];
      const n = st.count + 1, C = D.CLASSES[sv.cls], R = sv.resets | 0;
      sv.level = 1; sv.exp = 0; Object.assign(sv, C.base); sv.points = R * RP;   // o mu.js conta resets × pontos...
      vx.st = {}; vx.pool = -(R * RP);                                            // ...e a reserva negativa zera os pontos livres
      const rb = await mrItemFor(sv.cls, n);
      st.count = n; st.pend.push({ n, b: rb, u: D.newUid(), at: Date.now() });
      st.log.unshift({ n, at: Date.now(), b: rb, lvl: cur.level | 0, resets: R }); st.log = st.log.slice(0, 50);
      await DB.kvSet('mu:' + id, sv); await DB.kvSet('muvx:' + id, vx); await DB.kvSet(MRK(id), st);
      const got = await mrDeliver(id, row.account_id, sv, st, await DB.kvGet('muware:' + row.account_id));
      if (got) { await DB.kvSet('mu:' + id, sv); await DB.kvSet(MRK(id), st); }
      DB.log('mu_master_reset', { char: id, n, reward: rb, delivered: got, resets: R }); muRankCache.t = 0;
      if (MU.announce) MU.announce('♛ ' + sv.name + ' completed Master Reset #' + n + '!', '♛ {0} completed Master Reset #{1}!', [sv.name, n]);
      const out = await muOutSv(id, sv); const v = await vipOf(row.account_id);
      return { ok: true, count: n, reward: rb, delivered: got, pend: st.pend.length, sv: out, vip: { tier: v.tier, gold: v.gold, pm: v.pm, plat: v.plat, free: v.free, pool: vx.pool } };
    } finally { mrBusy.delete(id); }
  };
  API['POST /api/mu/mrclaim'] = async (b, req) => {   // recompensa que ficou esperando (inventário estava cheio)
    if (limited(ipOf(req), 30)) return [429, { error: 'rate' }];
    const [row, err] = await mrAuth(b); if (err) return err;
    const got = await mrAutoDeliver(row.id, row.account_id), st = (await DB.kvGet(MRK(row.id))) || {};
    return { ok: true, got, pend: (st.pend || []).length, count: st.count | 0, sv: await muOutSv(row.id, await DB.kvGet('mu:' + row.id)) };
  };
  API['POST /api/mu/mrcfg'] = async b => {   // só o dono: escolher o item (ou a lista de itens) da recompensa do Master Reset
    const t = verify(b.token); if (!t) return [401, { error: 'auth' }]; const a = await DB.accountById(t.a);
    if (!a || String(a.ulow || a.username || '').toLowerCase() !== ADM_USER || String(a.email || '').toLowerCase() !== ADM_MAIL) return [403, { error: 'owner' }];
    const cfg = (await DB.kvGet('mumrcfg')) || { items: [] };
    if (b.items !== undefined) { const raw = Array.isArray(b.items) ? b.items : String(b.items || '').split(/[\s,;]+/);
      const ids = raw.map(x => String(x).trim()).filter(Boolean), bad = ids.filter(x => !D.BASES[x] || !D.BASES[x].equip);
      if (bad.length) return [400, { error: 'item', bad }]; cfg.items = ids.slice(0, 30); await DB.kvSet('mumrcfg', cfg); DB.log('mu_mrcfg', { items: cfg.items }); }
    return { ok: true, items: cfg.items || [], dflt: D.mrRewardsFor('dk') };
  };
  API['POST /api/mu/admgrant'] = async b => {   // só o dono: entregar um produto da loja a um herói pelo nome
    const t = verify(b.token); if (!t) return [401, { error: 'auth' }]; const a = await DB.accountById(t.a);
    if (!a || String(a.ulow || a.username || '').toLowerCase() !== ADM_USER || String(a.email || '').toLowerCase() !== ADM_MAIL) return [403, { error: 'owner' }];
    const p = D.MU_SHOP_BY_ID[String(b.id || '')]; if (!p || p.noSale) return [400, { error: 'product' }];
    const all = await DB.allChars(), q = String(b.name || '').toLowerCase(), c = all.find(x => String((x.data && x.data.name) || x.name || '').toLowerCase() === q);
    if (!c) return [404, { error: 'char' }]; await MU.grant(c.id, p.id, 'admin'); DB.log('mu_admgrant', { char: c.id, id: p.id }); return { ok: true };
  };
  API['POST /api/mu/vipgive'] = async b => {   // só o dono: dar VIP (teste / prêmio)
    const t = verify(b.token); if (!t) return [401, { error: 'auth' }]; const a = await DB.accountById(t.a);
    if (!a || String(a.ulow || a.username || '').toLowerCase() !== ADM_USER || String(a.email || '').toLowerCase() !== ADM_MAIL) return [403, { error: 'owner' }];
    const tier = ['gold', 'pm', 'plat'].includes(b.tier) ? b.tier : 'plat', days = Math.max(1, Math.min(365, b.days | 0 || 30));
    const all = await DB.allChars(), q = String(b.name || '').toLowerCase(), c = all.find(x => String((x.data && x.data.name) || x.name || '').toLowerCase() === q);
    if (!c) return [404, { error: 'char' }]; await vipAdd(c.id, { tier, days }); return { ok: true };
  };
  const out = async (id, acc, j, vx) => { if (!j || typeof j !== 'object') return; if (j._inj) delete j._inj; else if (j.sv) { muInjectVX(j.sv, vx); const sb = await DB.kvGet('musbar:' + id); if (Array.isArray(sb)) j.sv.sbar = sb; } const v = await vipOf(acc); j.vip = { tier: v.tier, gold: v.gold, pm: v.pm, plat: v.plat, free: v.free, pool: vx.pool };
    const lg = RLIM ? await resetLog(id) : []; j.rl = { used: lg.length, max: RLIM, wait: RLIM && lg.length >= RLIM ? Math.max(0, lg[lg.length - RLIM] + RWIN - Date.now()) : 0 };
    const xr = await DB.kvGet('muxr:' + acc); j.xr = { until: (xr && xr.until) || 0 };
    const mr = await DB.kvGet('mumr:' + id); j.mr = { count: (mr && mr.count) | 0, pend: (mr && mr.pend && mr.pend.length) | 0 }; };
  /* anel de EXP por tempo (15/30 dias, conta inteira): soma os dias; o anel em si é entregue só na primeira compra */
  async function xrAdd(charId, days) {
    const row = await DB.charById(charId); if (!row) return; const k = 'muxr:' + row.account_id, v = (await DB.kvGet(k)) || {}, t = Date.now();
    v.until = Math.max(t, v.until || 0) + days * 864e5; const first = !v.got; if (first) v.got = charId;
    await DB.kvSet(k, v); DB.log('mu_xring', { acc: row.account_id, char: charId, days, until: v.until });
    if (first) await origGrant(charId, 'mu_xr_ring', 'xring');
  }
  /* aviso único para quem já tinha VIP: os itens do set ficaram mais fortes e são para sempre */
  async function vipPowerNote(acc) { return 0; /* VIP não concede nem melhora sets. */ }
  /* todos os itens comprados (loja paga e VIP) ficam +15, Excelente e com todas as opções no máximo */
  const fullItem = it => { if (!it || typeof it !== 'object') return false; const B = D.BASES[it.b]; if (!B || !B.equip || B.mr || !(B.premium || B.excl === 'shop')) return false;
    const o = D.PREMIUM_OPTS, ok = (it.r | 0) === 6 && (it.p | 0) === 15 && it.o && Object.keys(o).every(k => +it.o[k] === o[k]); if (ok) return false;
    it.r = 6; it.p = 15; it.o = Object.assign({}, o); return true; };
  async function upgradeShopItems(charId, acc) {
    let n = 0; const sv = await DB.kvGet('mu:' + charId);
    if (sv) { let ch = false; for (const it of sv.inv || []) if (fullItem(it)) { ch = true; n++; } for (const k in sv.equip || {}) if (fullItem(sv.equip[k])) { ch = true; n++; } if (ch) await DB.kvSet('mu:' + charId, sv); }
    const w = await DB.kvGet('muware:' + acc); if (Array.isArray(w)) { let ch = false; for (const it of w) if (fullItem(it)) { ch = true; n++; } if (ch) await DB.kvSet('muware:' + acc, w); }
    if (n) DB.log('mu_full_upgrade', { char: charId, n });
    return n;
  }
  /* quem já tinha comprado VIP antes das joias existirem: recebe 1 pingente + 2 anéis do set (+15, full) no herói que ganhou o set */
  async function grantVipJewelry(charId, acc) { return { n: 0 }; /* Sem pingentes, anéis ou escudos de set VIP. */
    const k = 'muvip:' + acc, v = await DB.kvGet(k); if (!v || !v.sets) return { n: 0 };
    let n = 0, need = 0; v.jw = v.jw || {}; v.sh = v.sh || {};
    const PACKS = [['jw', ['_pendant', '_ring', '_ring']], ['sh', ['_shield']]];   // joias do set e escudo do set (+15, full)
    for (const tier of Object.keys(v.sets)) {
      if (v.sets[tier] !== charId || !V[tier]) continue;
      const box = (await DB.kvGet('mumail:' + charId)) || []; const inBox = box.some(m => m && m.id === 'mu_vipset_' + tier);
      for (const [flag, parts] of PACKS) {
        if (v[flag][tier]) continue;
        if (inBox) { v[flag][tier] = 1; await DB.kvSet(k, v); continue; }   // o set ainda vai chegar pela caixa (já completo)
        const sk = 'ps_' + String(V[tier].setN).padStart(2, '0'), ids = parts.map(x => sk + x).filter(id => D.BASES[id]);
        const sv = await DB.kvGet('mu:' + charId); if (!sv) continue; sv.inv = Array.isArray(sv.inv) ? sv.inv : [];
        const INV = D.CFG.INV, free = sv.inv.slice(0, INV).filter(x => !x).length + Math.max(0, INV - sv.inv.length);
        if (free < ids.length) { need += ids.length; continue; }
        const own = (await DB.kvGet('muown:' + acc)) || {};
        for (const b of ids) { const it = D.makeItem(b, 6, 15); const i = sv.inv.findIndex((x, j) => j < INV && !x); if (i >= 0) sv.inv[i] = it; else sv.inv.push(it); own[it.u] = 'c' + charId; n++; }
        await DB.kvSet('muown:' + acc, own); await DB.kvSet('mu:' + charId, sv); v[flag][tier] = 1; await DB.kvSet(k, v);
        DB.log('mu_vip_extra', { char: charId, tier, pack: flag });
      }
    }
    return { n, need };
  }
  const oLoad = API['POST /api/mu/load'];
  if (oLoad) API['POST /api/mu/load'] = async (b, req) => { let up = 0, jw = null, vpw = 0;
    try { const t0 = verify(b && b.token), row0 = t0 && b.char ? await DB.charById(+b.char) : null; if (row0 && row0.account_id === t0.a) { await legacyRP(row0.id); await mrAutoDeliver(row0.id, row0.account_id); up = await upgradeShopItems(row0.id, row0.account_id); jw = await grantVipJewelry(row0.id, row0.account_id); vpw = await vipPowerNote(row0.account_id); } } catch (e) { console.error('[full up]', e.message); }
    const r = await oLoad(b, req);
    { const j = Array.isArray(r) ? r[1] : r; if (j && typeof j === 'object') { if (up) j.fullUp = up; if (jw && jw.n) j.jwUp = jw.n; if (jw && jw.need) j.jwNeed = jw.need; if (vpw) j.vipPw = 1; } }
    try { const id = +(b && b.char) || 0, t = verify(b && b.token); if (id && t) { const ok = !Array.isArray(r) || r[0] < 300, j = Array.isArray(r) ? r[1] : r; if (ok) await out(id, t.a, j, await getVX(id)); } } catch (e) { console.error('[vip load]', e.message); }
    return r; };
  const oSave = API['POST /api/mu/save'];
  API['POST /api/mu/save'] = async (b, req) => {
    const id = +(b && b.char) || 0; let ctx = null;
    try {   // barra de skills escolhida pelo jogador (até 4 skills da classe)
      if (b && b.sv && Array.isArray(b.sv.sbar)) { const t1 = verify(b.token), r1 = t1 && id ? await DB.charById(id) : null, pv = r1 && r1.account_id === t1.a ? await DB.kvGet('mu:' + id) : null;
        if (pv && D.SKILLS[pv.cls]) { const ok = D.SKILLS[pv.cls].map(x => x.id), sb = [...new Set(b.sv.sbar.map(String))].filter(x => ok.includes(x)).slice(0, 4); await DB.kvSet('musbar:' + id, sb); } }
    } catch (e) { console.error('[sbar]', e.message); }
    try {
      const t = verify(b && b.token), row = t && id ? await DB.charById(id) : null;
      if (row && row.account_id === t.a && b.sv && typeof b.sv === 'object') {
        const prev = await DB.kvGet('mu:' + id);
        if (prev && D.CLASSES[prev.cls]) {
          const vip = await vipOf(row.account_id), vx = await legacyRP(id), sv = b.sv, cls = prev.cls;
          ctx = { acc: row.account_id, vx, prevResets: prev.resets | 0, prevLvl: prev.level | 0, save: false };
          const SM = D.CFG.STAT_MAX || 65000; for (const k of K) { const v0 = Math.floor(+sv[k] || 0); if (v0 > SM) { sv.points = (sv.points | 0) + (v0 - SM); sv[k] = SM; ctx.capped = true; } }   // máximo de 65 mil por atributo (o excesso volta como ponto livre)
          if (RLIM && !vip.tier && (sv.resets | 0) === (prev.resets | 0) + 1 && (await resetLog(id)).length >= RLIM) {   // free: limite de resets atingido -> desfaz o reset
            for (const k of ['resets', 'level', 'exp', 'str', 'agi', 'vit', 'ene', 'points', 'skills', 'sp']) if (prev[k] !== undefined) sv[k] = JSON.parse(JSON.stringify(prev[k]));
            ctx.blocked = true;
          }
          if ((sv.resets | 0) === (prev.resets | 0) + 1) {   // reset
            vx.st = {}; ctx.save = true;
            const need = vip.tier ? V[vip.tier].resetLvl : RL, CAP = D.CFG.LEVEL_CAP;
            if ((prev.level | 0) >= need) {
              /* RESET ACUMULATIVO: os atributos distribuídos nunca zeram. O mu.js só aceita base + (nível-1)×pontos + resets×bônus;
                 os pontos ganhos nos níveis desta vida ((nível-1)×pontos da classe) passam para a reserva do herói (muvx.pool),
                 então Força/Agilidade/Vitalidade/Energia ficam exatamente iguais depois do reset e nenhum ponto é duplicado. */
              const bank = Math.max(0, (prev.level | 0) - 1) * D.CLASSES[cls].pts; vx.pool += bank; ctx.bank = bank;
              if (vip.tier) { vx.pool += V[vip.tier].resetPts - RP; ctx.vipReset = vip.tier; }
              if ((prev.level | 0) < CAP) { prev.level = CAP; prev.exp = 0; await DB.kvSet('mu:' + id, prev); ctx.patched = true; }   // garante o reset mesmo se o mu.js exigir nível maior
            }
          } else if (vip.tier) {   // VIP ganha níveis mais rápido: o limite de níveis por salvamento do mu.js acompanha o multiplicador
            const dt = Math.min(600, Math.max(0, (Date.now() - (prev.t || Date.now())) / 60000)), g = 25 + Math.ceil(dt * 40), want = (sv.level | 0) - (prev.level | 0);
            if (want > g && want <= g * V[vip.tier].exp) { prev.t = Date.now() - Math.min(600, (want - 25) / 40) * 60000; await DB.kvSet('mu:' + id, prev); }
          }
          let sum = 0; for (const k of K) sum += Math.max(0, +sv[k] || 0);
          if (vx.pool < 0) { const lim = capOf(cls, Math.max(1, sv.level | 0), sv.resets | 0) + vx.pool;   // depois do Master Reset: não dá para gastar os pontos que foram zerados
            if (sum > lim) { sum = 0; for (const k of K) { sv[k] = prev[k] | 0; sum += sv[k]; } ctx.capped = true; } }
          const cap = capOf(cls, Math.max(1, sv.level | 0), sv.resets | 0), E = Math.max(0, sum - cap);
          if (E > 0 && E <= vx.pool) {   // tira o excedente (pontos VIP) antes do mu.js conferir
            const base = D.CLASSES[cls].base, above = K.map(k => Math.max(0, (+sv[k] || 0) - base[k])), tot = above.reduce((a, c) => a + c, 0) || 1, st = {}; let left = E;
            K.forEach((k, i) => { st[k] = Math.min(above[i], Math.floor(E * above[i] / tot)); left -= st[k]; });
            K.forEach((k, i) => { if (left > 0) { const m = Math.min(left, above[i] - st[k]); st[k] += m; left -= m; } });
            for (const k of K) sv[k] = (+sv[k] || 0) - st[k];
            vx.st = st; ctx.save = true;
            sv.points = Math.max(0, cap - (sum - E));   // assim o mu.js não acha diferença e o jogo não perde o progresso a cada salvamento
          } else if (E === 0 && Object.keys(vx.st).length) { vx.st = {}; ctx.save = true; }
          if (E === 0 && vx.pool > 0) sv.points = Math.max(0, cap - sum);
        }
      }
    } catch (e) { console.error('[vip pre]', e.message); }
    const r = await oSave(b, req);
    try {
      if (ctx) {
        const ok = !Array.isArray(r) || r[0] < 300, j = Array.isArray(r) ? r[1] : r;
        const after = await DB.kvGet('mu:' + id), resetOk = after && (after.resets | 0) === ctx.prevResets + 1;
        if (ctx.patched && !resetOk && after && (after.level | 0) === RL) { after.level = ctx.prevLvl; await DB.kvSet('mu:' + id, after); }
        if (ctx.vipReset && !resetOk) ctx.vx.pool -= V[ctx.vipReset].resetPts - RP;
        if (ctx.bank && !resetOk) ctx.vx.pool -= ctx.bank;   // reset não aconteceu: desfaz a reserva dos pontos de nível
        if (ctx.bank && resetOk) DB.log('mu_reset_keep', { char: id, bank: ctx.bank, pool: ctx.vx.pool });
        if (ok && ctx.save) await DB.kvSet('muvx:' + id, ctx.vx);
        if (ok && resetOk) { const lg = await resetLog(id); lg.push(Date.now()); await DB.kvSet('mureset:' + id, lg.slice(-20)); }
        if (ok && (ctx.capped || ctx.blocked) && j && after) { j.sv = await muOutSv(id, after); j._inj = 1; }
        if (ok && ctx.blocked && j) j.rlBlock = 1;
        if (ok) await out(id, ctx.acc, j, ctx.vx);
        if (ctx.vipReset && resetOk) DB.log('mu_vip_reset', { char: id, tier: ctx.vipReset, pool: ctx.vx.pool });
      }
    } catch (e) { console.error('[vip post]', e.message); }
    return r;
  };
})();
API['GET /api/mu/rooms'] = async () => ({ rooms: muRoomCounts() });
/* nova classe Dark Lord: o mu.js cria o herói como DK e aqui ele vira Dark Lord (atributos e classe próprios) */
(() => { const orig = API['POST /api/mu/create']; if (!orig) return;
  API['POST /api/mu/create'] = async (b, req) => {
    if (!b || b.cls !== 'dl') return orig(b, req);
    const r = await orig(Object.assign({}, b, { cls: 'dk' }), req);
    const j = Array.isArray(r) ? (r[0] < 300 ? r[1] : null) : r;
    if (j && j.id) { const sv = await DB.kvGet('mu:' + j.id); if (sv) { sv.cls = 'dl'; Object.assign(sv, MUD.CLASSES.dl.base); sv.points = 0; sv.skills = {}; await DB.kvSet('mu:' + j.id, sv); DB.log('mu_create_dl', { id: j.id }); } }
    return r;
  };
})();
/* apagar herói: só o dono da conta, confirmando o nome; o baú da conta fica */
API['POST /api/mu/delete'] = async (b, req) => {
  const t = verify(b && b.token); if (!t) return [401, { error: 'auth' }];
  const id = +(b && b.char), row = id ? await DB.charById(id) : null;
  if (!row || row.account_id !== t.a) return [404, { error: 'char' }];
  const sv = await DB.kvGet('mu:' + id), name = String((sv && sv.name) || row.name || '');
  if (String(b.name || '').trim().toLowerCase() !== name.toLowerCase()) return [400, { error: 'confirm' }];
  const live = muRTPlayers.get(id); if (live && live.ws) { try { live.ws.close(4003); } catch (_) {} muRTPlayers.delete(id); }
  await DB.deleteChar(id);
  for (const k of ['mu:', 'wow:', 'muvx:', 'musbar:', 'murank:', 'muskill:']) { try { await DB.kvDel(k + id); } catch (_) {} }
  muRankCache.t = 0; DB.log('mu_delete', { id, acc: t.a, name, lvl: sv && sv.level, resets: sv && sv.resets });
  return { ok: true };
};
/* =============================== MERCADO DOS JOGADORES (dinheiro real, Stripe Connect) ===============================
   Jogadores anunciam itens do próprio inventário e vendem para outros jogadores. O comprador paga no Stripe Checkout
   (cartão, ou Pix quando o anúncio é em reais); o dinheiro vai para a conta Stripe Connect (Express) do vendedor, menos a
   comissão do mercado (application fee). Só o webhook ASSINADO do Stripe confirma o pagamento.
   Segurança dos itens:
     - ao anunciar, o item SAI do inventário do herói e fica guardado no anúncio (custódia); "mkt:locks" (uid -> conta)
       impede que um salvamento antigo do jogo devolva o item ao vendedor;
     - item vendido vai para a caixa de entregas do herói comprador ("mkt:box:<herói>") e entra no inventário no próximo
       load/salvamento (inventário cheio = fica guardado); cancelar devolve o item do mesmo jeito;
     - cada anúncio tem trava (só uma reserva por vez), cada pedido é idempotente (webhook repetido não entrega 2x).
   Variáveis no Render:
     STRIPE_SECRET_KEY / STRIPE_WEBHOOK_SECRET (as mesmas da loja; comece com sk_test_ para testar)
     STRIPE_CONNECT_WEBHOOK_SECRET  (opcional) segredo do webhook de "eventos de contas conectadas" (account.updated, payout.paid)
     MKT_PLATFORM_COUNTRY           país da SUA conta Stripe (padrão FR)
     MKT_SELLER_COUNTRIES           (opcional) países permitidos para vendedores, ex.: "FR,PT,ES,BR"
   As vendas só ligam quando o dono marca "Vendas ligadas" no painel de administração do mercado. */
const MKT = (() => {
  const D = MUD, KEY = process.env.STRIPE_MARKET_KEY || process.env.STRIPE_SECRET_KEY || '', WHSEC = process.env.STRIPE_WEBHOOK_SECRET || '', CWH = process.env.STRIPE_CONNECT_WEBHOOK_SECRET || '';
  const API_BASE = process.env.STRIPE_API || 'https://api.stripe.com', URLBASE = (process.env.PUBLIC_URL || 'https://muonlineclaude.com').replace(/\/+$/, '');
  const TEST = /^(sk|rk)_test_/.test(KEY), PLATFORM = (process.env.MKT_PLATFORM_COUNTRY || 'FR').toUpperCase();
  const EEA = ['AT', 'BE', 'BG', 'HR', 'CY', 'CZ', 'DK', 'EE', 'FI', 'FR', 'DE', 'GR', 'HU', 'IE', 'IT', 'LV', 'LI', 'LT', 'LU', 'MT', 'NL', 'NO', 'PL', 'PT', 'RO', 'SK', 'SI', 'ES', 'SE', 'IS'];
  const XB = [...EEA, 'GB', 'CH', 'US', 'CA'];   // Connect: pagamento para vendedor em outro país só entre US, UK, EEE, CA e CH
  const COUNTRIES = process.env.MKT_SELLER_COUNTRIES ? process.env.MKT_SELLER_COUNTRIES.split(',').map(s => s.trim().toUpperCase()).filter(s => /^[A-Z]{2}$/.test(s)) : ['BR', 'US', 'CA', 'MX', 'GB', 'IE', 'FR', 'DE', 'AT', 'BE', 'NL', 'LU', 'CH', 'LI', 'IT', 'ES', 'PT', 'GR', 'CY', 'MT', 'SI', 'HR', 'SK', 'CZ', 'PL', 'HU', 'RO', 'BG', 'EE', 'LV', 'LT', 'FI', 'SE', 'NO', 'DK', 'IS', 'GI', 'AU', 'NZ', 'JP', 'SG', 'HK', 'MY', 'TH', 'AE', 'IN'];   // todos os países onde o Stripe abre conta de vendedor
  const DEF = { on: true, fee: 10, min: 200, max: 200000, pix: true, hold: 32, maxAct: 20, minLvl: 1, holdOn: true, nofee: true, feeBill: true, oweMax: 340, prepay: true, suspDays: 7 };   // prepay: vendedor sem comissão automática paga a comissão do anúncio antes de ele entrar no ar; suspDays: dias com comissão atrasada até suspender   // feeBill: comissão que o Stripe não deixou descontar vira dívida do vendedor, paga para a conta Stripe do mercado (França); oweMax: com essa dívida (centavos) ele não publica anúncio novo até pagar   // nofee: se o Stripe não deixar cobrar a comissão na conta do vendedor (ex.: plataforma na França e vendedor no Brasil), a venda acontece sem comissão   // holdOn: vendedor de US/UK/EEE/CA/CH pode vender antes de conectar o Stripe
  const CURS = ['brl', 'usd', 'eur'], now = () => Date.now();   // o vendedor escolhe: real, dólar ou euro (Pix só em reais; dólar e euro só cartão)
  void PLATFORM;
  let C = null, loading = null;
  async function load() {
    if (C) return C; if (loading) return loading;
    loading = (async () => {
      const c = { l: new Map(), o: new Map(), s: new Map(), locks: {}, box: new Set(), gn: new Map() };
      for (const r of await DB.kvList('mkt:l:')) if (r.data && r.data.id) c.l.set(r.data.id, r.data);
      for (const r of await DB.kvList('mkt:o:')) if (r.data && r.data.id) c.o.set(r.data.id, r.data);
      for (const r of await DB.kvList('mkt:s:')) if (r.data) c.s.set(+String(r.key).slice(6), r.data);
      for (const r of await DB.kvList('mkt:box:')) if (Array.isArray(r.data) && r.data.length) c.box.add(+String(r.key).slice(8));
      c.locks = (await DB.kvGet('mkt:locks')) || {}; c.cfg = Object.assign({}, DEF, (await DB.kvGet('mkt:cfg')) || {});
      if (!Array.isArray(c.cfg.countries) || !c.cfg.countries.length || !c.cfg.cv2) { c.cfg.countries = COUNTRIES.slice(); c.cfg.cv2 = 1; }
      if (!c.cfg.cv4) { if ((c.cfg.oweMax | 0) === 500) c.cfg.oweMax = 340; c.cfg.cv4 = 1; }   // bloqueio automático no mínimo do Stripe (R$ 3,40)
      if (!c.cfg.cv3) { c.cfg.countries = [...new Set([...(c.cfg.countries || []), ...COUNTRIES])]; c.cfg.minLvl = 1; c.cfg.cv3 = 1; }   // todo mundo vende: todos os países do Stripe e sem nível mínimo
      c.seq = ((await DB.kvGet('mkt:seq')) || {}).n | 0; C = c; return c;
    })();
    try { return await loading; } finally { loading = null; }
  }
  const putL = async l => { l.up = now(); C.l.set(l.id, l); await DB.kvSet('mkt:l:' + l.id, l); };
  const putO = async o => { C.o.set(o.id, o); await DB.kvSet('mkt:o:' + o.id, o); };
  const putS = async (acc, s) => { C.s.set(acc, s); await DB.kvSet('mkt:s:' + acc, s); };
  const putLocks = () => DB.kvSet('mkt:locks', C.locks);
  const nextId = async p => { C.seq++; await DB.kvSet('mkt:seq', { n: C.seq }); return p + C.seq; };
  const chains = new Map();
  function lockK(k, fn) { const run = (chains.get(k) || Promise.resolve()).catch(() => {}).then(fn), tail = run.catch(() => {}); chains.set(k, tail); tail.then(() => { if (chains.get(k) === tail) chains.delete(k); }); return run; }
  const payOn = () => !!(KEY && WHSEC && C && C.cfg.on);
  const isOwner = async acc => { const a = await DB.accountById(acc); return !!(a && String(a.ulow || a.username || '').toLowerCase() === ADM_USER && String(a.email || '').toLowerCase() === ADM_MAIL); };
  const tradeable = it => !!(it && D.BASES[it.b]);   // nenhum item fica preso à conta: todos podem ser vendidos no mercado (itens da loja/VIP/Master Reset passam para o livro-razão do comprador)
  async function ownTo(acc, charId, its) {   // itens da loja entregues pelo mercado: registra no livro-razão da conta que recebe (senão o mu.js apagaria)
    const L = its.filter(it => it && D.BASES[it.b] && D.BASES[it.b].excl === 'shop'); if (!L.length || !acc) return;
    const k = 'muown:' + acc, own = (await DB.kvGet(k)) || {}; for (const it of L) own[it.u] = 'c' + charId; await DB.kvSet(k, own); }
  const catOf = B => ['sword', 'staff', 'bow', 'shield'].includes(B.cat) ? 'weapon' : ['helm', 'armor', 'pants', 'gloves', 'boots'].includes(B.cat) ? 'armor' : B.cat === 'wings' ? 'wings' : B.cat === 'jewel' ? 'jewel' : ['pendant', 'ring'].includes(B.cat) ? 'acc' : 'other';
  const heroActive = (id, sv) => muRTPlayers.has(id) || now() - ((sv && sv.t) || 0) < 120000;
  const clean = s => String(s || '').replace(/[<>]/g, '').replace(/\s+/g, ' ').trim();
  async function note(acc, k, a, mail, extra) {   // aviso para a conta: painel do mercado + jogo (+ e-mail se pedir; extra.url = botão "Pagar agora")
    const key = 'mkt:note:' + acc, L = (await DB.kvGet(key)) || []; L.unshift(Object.assign({ at: now(), k, a: a || [] }, extra || {})); await DB.kvSet(key, L.slice(0, 60));
    const g = C.gn.get(acc) || []; g.push(Object.assign({ k, a: a || [] }, extra || {})); C.gn.set(acc, g.slice(-10));
    if (mail) { try { const ac = await DB.accountById(acc); if (ac && ac.email) await sendMail(ac.email, mail[0], mail[1]); } catch (_) {} }
  }
  async function alog(by, act, data) { const L = (await DB.kvGet('mkt:alog')) || []; L.unshift({ at: now(), by, act, data }); await DB.kvSet('mkt:alog', L.slice(0, 300)); DB.log('mkt_admin', { by, act, data }); }
  async function stripe(method, p, form, acct, idem) {
    if (!KEY) throw new Error('stripe_off');
    const h = { Authorization: 'Bearer ' + KEY }; if (form) h['Content-Type'] = 'application/x-www-form-urlencoded'; if (acct) h['Stripe-Account'] = acct; if (idem) h['Idempotency-Key'] = idem;
    const r = await fetch(API_BASE + p, { method, headers: h, body: form ? new URLSearchParams(form) : undefined }); const j = await r.json().catch(() => ({}));
    if (!r.ok) { const e = new Error((j.error && j.error.message) || ('stripe ' + r.status)); e.status = r.status; e.replay = r.headers.get('idempotent-replayed') === 'true'; if (e.replay) console.error('[mercado stripe] resposta repetida (idempotency) de', p);
      try { const perm = r.status === 403 || /permission/i.test(e.message); C && C.cfg && (C.cfg.lastErr = { at: now(), path: p.split('?')[0].replace(/acct_\w+|cs_\w+/g, '…'), status: r.status, msg: e.message.slice(0, 400), perm }); console.error('[mercado stripe]', r.status, e.message.slice(0, 200)); } catch (_) {}
      throw e; } return j;
  }
  async function stripe2(p, body, idem) {   // API v2 do Stripe (JSON) — plataformas criadas no Connect novo (Accounts v2)
    if (!KEY) throw new Error('stripe_off');
    const h = { Authorization: 'Bearer ' + KEY, 'Content-Type': 'application/json', 'Stripe-Version': process.env.STRIPE_V2_VERSION || '2026-09-30.endive' }; if (idem) h['Idempotency-Key'] = idem;
    const r = await fetch(API_BASE + p, { method: 'POST', headers: h, body: JSON.stringify(body) }); const j = await r.json().catch(() => ({}));
    if (!r.ok) { const er = j.error || {}, e = new Error((er.code ? er.code + ': ' : '') + (er.message || ('stripe ' + r.status))); e.status = r.status;
      try { C && C.cfg && (C.cfg.lastErr = { at: now(), path: p, status: r.status, msg: e.message.slice(0, 400), perm: r.status === 403 }); console.error('[mercado stripe v2]', r.status, e.message.slice(0, 300)); } catch (_) {}
      throw e; } return j;
  }
  /* ---------- caixa de entregas (item comprado ou devolvido) ---------- */
  async function boxPush(charId, entry) {
    const k = 'mkt:box:' + charId, box = (await DB.kvGet(k)) || [];
    if (!box.some(x => x && x.it && x.it.u === entry.it.u)) box.push(entry);
    await DB.kvSet(k, box); C.box.add(charId);
  }
  async function targetChar(acc, pref) {   // herói que recebe (se o escolhido foi apagado, vai para outro herói da conta)
    if (pref) { const r = await DB.charById(pref); if (r && r.account_id === acc) return pref; }
    const rows = await DB.charsOf(acc); return rows.length ? rows[0].id : 0;
  }
  const allItems = (sv, ware) => [...((sv && sv.inv) || []), ...Object.values((sv && sv.equip) || {}), ...(ware || [])].filter(Boolean);
  async function boxToStored(charId, acc) {   // entrega direto no banco (usado no load, quando não há jogo aberto salvando por cima)
    if (!C.box.has(charId)) return 0;
    const k = 'mkt:box:' + charId, box = (await DB.kvGet(k)) || []; if (!box.length) { C.box.delete(charId); return 0; }
    const sv = await DB.kvGet('mu:' + charId); if (!sv) return 0; sv.inv = Array.isArray(sv.inv) ? sv.inv : [];
    const INV = D.CFG.INV, have = new Set(allItems(sv, await DB.kvGet('muware:' + acc)).map(x => x.u)); let n = 0; const left = [];
    for (const e of box) { if (!e || !e.it) continue; if (have.has(e.it.u)) { n++; continue; }
      const i = sv.inv.findIndex((x, j) => j < INV && !x); if (i < 0 && sv.inv.length >= INV) { left.push(e); continue; }
      if (C.locks[e.it.u] === acc) { delete C.locks[e.it.u]; await putLocks(); }
      if (i >= 0) sv.inv[i] = e.it; else sv.inv.push(e.it); have.add(e.it.u); n++; }
    if (n) { await ownTo(acc, charId, box.map(e => e && e.it)); await DB.kvSet('mu:' + charId, sv); DB.log('mkt_box', { char: charId, n, how: 'load' }); }
    await DB.kvSet(k, left); if (!left.length) C.box.delete(charId); return n;
  }
  /* ---------- hooks no salvamento e no load do jogo ---------- */
  const oSave = API['POST /api/mu/save'];
  API['POST /api/mu/save'] = async (b, req) => {
    let acc = 0, id = 0, inj = [];
    try {
      await load(); const t = verify(b && b.token); id = +(b && b.char) || 0; const row = t && id ? await DB.charById(id) : null;
      if (row && row.account_id === t.a && b.sv && typeof b.sv === 'object') {
        acc = t.a;
        const lk = it => it && it.u && C.locks[it.u] === acc;   // item anunciado/vendido por esta conta: não volta
        if (Array.isArray(b.sv.inv)) b.sv.inv = b.sv.inv.map(x => lk(x) ? null : x);
        if (b.sv.equip && typeof b.sv.equip === 'object') for (const s of Object.keys(b.sv.equip)) if (lk(b.sv.equip[s])) delete b.sv.equip[s];
        if (Array.isArray(b.ware)) b.ware = b.ware.map(x => lk(x) ? null : x);
        if (C.box.has(id) && Array.isArray(b.sv.inv)) {   // entrega: o item entra no inventário que o jogo está mandando e no banco (assim o anti-hack o reconhece)
          const box = (await DB.kvGet('mkt:box:' + id)) || [], have = new Set(allItems(b.sv, b.ware).map(x => x.u)), prev = await DB.kvGet('mu:' + id);
          if (prev) { prev.inv = Array.isArray(prev.inv) ? prev.inv : []; const INV = D.CFG.INV;
            for (const e of box) { if (!e || !e.it || have.has(e.it.u)) continue;
              const i = b.sv.inv.findIndex((x, j) => j < INV && !x); if (i < 0) break;
              if (C.locks[e.it.u] === acc) { delete C.locks[e.it.u]; await putLocks(); }
              b.sv.inv[i] = e.it; have.add(e.it.u); inj.push(e.it.u);
              const pi = prev.inv.findIndex((x, j) => j < INV && !x); if (pi >= 0) prev.inv[pi] = e.it; else prev.inv.push(e.it); }
            if (inj.length) { await ownTo(acc, id, box.filter(e => e && e.it && inj.includes(e.it.u)).map(e => e.it)); await DB.kvSet('mu:' + id, prev); } }
        }
      }
    } catch (e) { console.error('[mercado save pre]', e.message); }
    const r = await oSave(b, req);
    try {
      if (acc) { const ok = !Array.isArray(r) || r[0] < 300, j = Array.isArray(r) ? r[1] : r;
        if (ok && j && typeof j === 'object') {
          if (inj.length) { const after = await DB.kvGet('mu:' + id), got = new Set(allItems(after).map(x => x.u)), box = (await DB.kvGet('mkt:box:' + id)) || [];
            const left = box.filter(e => !(e && e.it && got.has(e.it.u))), n = box.length - left.length;
            await DB.kvSet('mkt:box:' + id, left); if (!left.length) C.box.delete(id);
            if (n) { j.sv = await muOutSv(id, after); j._inj = 1; j.mktGot = n; DB.log('mkt_box', { char: id, n, how: 'save' }); } }
          const g = C.gn.get(acc); if (g && g.length) { j.mktNotes = g; C.gn.delete(acc); }
          if (C.box.has(id)) j.mktBox = 1;
        } }
    } catch (e) { console.error('[mercado save pos]', e.message); }
    return r;
  };
  const oLoad = API['POST /api/mu/load'];
  API['POST /api/mu/load'] = async (b, req) => {
    let got = 0;
    try { await load(); const t = verify(b && b.token), row = t && b.char ? await DB.charById(+b.char) : null; if (row && row.account_id === t.a) {
      for (const o of [...C.o.values()]) if (o.buyer === t.a && o.st === 'pending') await lockK('vchk:' + o.id, () => verifyOrder(o, 20000));   // compra paga e ainda sem aviso do Stripe: confere agora
      got = await boxToStored(row.id, t.a); } } catch (e) { console.error('[mercado load]', e.message); }
    const r = await oLoad(b, req); if (got) { const j = Array.isArray(r) ? r[1] : r; if (j && typeof j === 'object') j.mktGot = got; } return r;
  };
  /* ---------- visão pública ---------- */
  /* anúncio por quantidade (itens empilháveis, ex.: joias): preço por unidade, estoque l.left, reservas l.resv = { pedido: { q, until } } */
  const liveResv = l => { let n = 0; for (const [oid, r] of Object.entries(l.resv || {})) { const o = C.o.get(oid); if (o && (o.st === 'paid' || (o.st === 'pending' && r.until > now()))) n += r.q | 0; } return n; };
  const availOf = l => l.unit ? Math.max(0, (l.left | 0) - liveResv(l)) : (l.st === 'active' || (l.st === 'reserved' && l.resUntil < now()) ? 1 : 0);
  const pubL = (l, full) => { const B = D.BASES[l.it.b] || {}, S = C.s.get(l.seller) || {};
    const av = l.unit ? availOf(l) : 0, ust = l.unit && l.st === 'active' ? (av > 0 ? 'active' : (l.left | 0) > 0 ? 'reserved' : 'sold') : null;
    const o = { id: l.id, it: { b: l.it.b, r: l.it.r | 0, p: l.it.p | 0, o: l.it.o, q: l.unit ? (l.left | 0) : l.it.q }, price: l.price, cur: l.cur, unit: l.unit ? 1 : 0, qty: l.unit ? l.qty | 0 : 1, left: l.unit ? l.left | 0 : 1, avail: l.unit ? av : 1, st: ust || (l.st === 'reserved' && l.resUntil > now() ? 'reserved' : l.st === 'reserved' ? 'active' : l.st),
      seller: l.seller, sname: l.sname, at: l.at, imgs: (l.imgs || []).length, cat: catOf(B), lvl: B.lvl | 0, cls: B.cls || [], views: l.views | 0, sales: S.sales | 0 };
    if (full) { o.desc = l.desc || ''; o.imgIds = l.imgs || []; o.soldAt = l.soldAt || 0; } return o; };
  API['GET /api/mkt/cfg'] = async () => { const c = await load(); return { on: payOn(), test: TEST, keys: !!(KEY && WHSEC), fee: c.cfg.fee, min: c.cfg.min, max: c.cfg.max, curs: CURS, pix: !!c.cfg.pix, countries: c.cfg.countries, xb: XB, holdOn: !!c.cfg.holdOn, fx: D.PRICE_FX, minLvl: c.cfg.minLvl }; };
  API['GET /api/mkt/listings'] = async () => {
    const c = await load(), list = [], sold = [];
    for (const l of c.l.values()) { if ((l.st === 'active' || l.st === 'reserved') && !sellerOff(l.seller)) list.push(pubL(l)); else if (l.st === 'sold' && now() - (l.soldAt || 0) < 7 * 864e5) sold.push(pubL(l)); }
    list.sort((a, b) => b.at - a.at); sold.sort((a, b) => b.at - a.at);
    return { list, sold: sold.slice(0, 20), on: payOn(), test: TEST };
  };
  API['POST /api/mkt/view'] = async b => { const c = await load(), l = c.l.get(String(b && b.id || '')); if (!l || ['removed'].includes(l.st)) return [404, { error: 'gone' }];
    l.views = (l.views | 0) + 1; C.l.set(l.id, l); if (l.views % 5 === 1) DB.kvSet('mkt:l:' + l.id, l).catch(() => {});
    const S = c.s.get(l.seller) || {}; return { l: pubL(l, true), seller: { id: l.seller, name: l.sname, sales: S.sales | 0, since: S.at || l.at, ready: !!S.ready } }; };
  API['POST /api/mkt/seller'] = async b => { const c = await load(), acc = +(b && b.id) || 0, S = c.s.get(acc) || {}; const mine = [...c.l.values()].filter(l => l.seller === acc);
    if (!mine.length && !S.acct) return [404, { error: 'seller' }];
    return { id: acc, name: (mine[0] && mine[0].sname) || '?', sales: S.sales | 0, since: S.at || (mine[0] && mine[0].at) || 0, susp: !!S.susp,
      active: mine.filter(l => l.st === 'active' || l.st === 'reserved').map(l => pubL(l)), sold: mine.filter(l => l.st === 'sold').length }; };
  async function img(req, res, url) { const id = url.searchParams.get('id') || ''; const im = /^i\d+$/.test(id) ? await DB.kvGet('mkt:img:' + id) : null;
    if (!im) { sendJson(res, 404, { error: 'img' }); return; } const buf = Buffer.from(im.b64, 'base64'); res.writeHead(200, { 'Content-Type': im.mime, 'Content-Length': buf.length, 'Cache-Control': 'public, max-age=86400' }); res.end(req.method === 'HEAD' ? undefined : buf); }
  async function imgUpload(req, res) {   // imagem do anúncio (o navegador já reduz para no máximo ~480 px)
    try {
      const raw = await new Promise((ok, bad) => { let n = 0; const ch = []; req.on('data', d => { n += d.length; if (n > 600 * 1024) { bad(new Error('grande')); req.destroy(); } else ch.push(d); }); req.on('end', () => ok(Buffer.concat(ch))); req.on('error', bad); });
      if (limited('mktimg:' + ipOf(req), 30)) { sendJson(res, 429, { error: 'rate' }); return; }
      const b = JSON.parse(raw.toString() || '{}'), t = verify(b.token); if (!t) { sendJson(res, 401, { error: 'auth' }); return; }
      const m = /^data:(image\/(?:jpeg|png|webp));base64,([A-Za-z0-9+/=]+)$/.exec(String(b.data || '')); if (!m) { sendJson(res, 400, { error: 'img' }); return; }
      const buf = Buffer.from(m[2], 'base64'); if (buf.length > 300 * 1024 || buf.length < 100) { sendJson(res, 400, { error: 'img_size' }); return; }
      await load(); const id = await nextId('i'); await DB.kvSet('mkt:img:' + id, { acc: t.a, mime: m[1], b64: m[2], at: now() });
      sendJson(res, 200, { id });
    } catch (e) { sendJson(res, 400, { error: 'img' }); }
  }
  /* ---------- vendedor: conta Stripe Connect ---------- */
  async function publishWaiting(acc) {   // anúncios feitos enquanto o cadastro no Stripe não terminava: entram no ar agora
    let n = 0; for (const L of [...C.l.values()]) if (L.seller === acc && L.st === 'wait') { L.st = 'active'; L.at = now(); L.log.push({ at: now(), ev: 'live' }); await putL(L); n++; }
    if (n) { await note(acc, 'Your {0} listing(s) are now live on the market.', [n]); DB.log('mkt_live', { acc, n }); } return n; }
  /* ---------- comissão cobrada à parte (vendedor em país onde o Stripe não deixa a plataforma descontar a comissão, ex.: Brasil) ----------
     A venda vai inteira para a conta Stripe do vendedor; a comissão (o.feeWaived) vira dívida dele (S.owe[moeda]) e ele paga num
     Checkout normal na conta Stripe do MERCADO (França), igual a uma compra da loja. Com dívida >= oweMax, não publica anúncio novo. */
  const mny = (v, cur) => (cur === 'brl' ? 'R$ ' : cur === 'usd' ? 'US$ ' : '€ ') + ((v | 0) / 100).toFixed(2);
  const MINPAY = 50;
  const minPlat = cur => cur === 'eur' ? 50 : Math.ceil(50 * ((D.PRICE_FX || {})[cur] || 1.2) * 1.2 / 10) * 10;   // a conta do mercado é em euro: o Stripe só aceita cobrança de pelo menos € 0,50 (R$ ~3,40 / US$ ~0,70)
  const oweTot = S => Object.values((S && S.owe) || {}).reduce((a, v) => a + (v | 0), 0);
  /* link direto para pagar a comissão: não vence (o pagamento no Stripe é criado na hora do clique) */
  const linkKey = acc => crypto.createHmac('sha256', SECRET).update('mkt-fee:' + acc).digest('hex').slice(0, 24);
  const feeLink = acc => URLBASE + '/pagar-comissao?a=' + acc + '&k=' + linkKey(acc);
  async function feeRemind(acc, why) {   // aviso no jogo + mercado (com botão) + e-mail com o link
    const S = C.s.get(acc) || {}; const L = Object.entries(S.owe || {}).filter(([c, v]) => (v | 0) >= minPlat(c)); if (!L.length) return false;
    const txt = L.map(([c, v]) => mny(v, c)).join(' + '), url = feeLink(acc), g = C.cfg;
    S.remAt = now(); await putS(acc, S); DB.log('mkt_fee_remind', { acc, why, owe: S.owe });
    const lim = g.oweMax > 0 ? mny(g.oweMax, L[0][0]) : '', d = g.suspDays | 0;
    await note(acc, 'Your market fee reached {0}. Pay it now with the button (card).', [txt],
      ['💳 Comissão do Mercado MuOnlineClaude: ' + txt, 'Olá!\n\nA comissão do mercado das suas vendas chegou a ' + txt + '.\n\nNo seu país o Stripe não deixa o mercado descontar a comissão na hora da venda: você recebeu o valor inteiro de cada venda e paga a comissão por este link (cartão):\n\n' + url + '\n\n' +
        (lim ? 'Com ' + lim + ' ou mais de comissão devida, os seus anúncios saem do ar até o pagamento. ' : '') + (d ? 'Com mais de ' + d + ' dias de atraso, a conta no mercado é suspensa. ' : '') + 'Quando você paga, tudo volta sozinho.\n\nObrigado,\nMuOnlineClaude'], { url });
    return true;
  }
  async function payLink(req, res, url) {   // GET /pagar-comissao?a=<conta>&k=<chave> -> página de pagamento do Stripe
    const go = loc => { res.writeHead(302, { Location: loc, 'Cache-Control': 'no-store' }); res.end(); };
    try { await load(); const acc = +url.searchParams.get('a') || 0, k = String(url.searchParams.get('k') || '');
      if (!acc || k.length !== 24 || !crypto.timingSafeEqual(Buffer.from(k), Buffer.from(linkKey(acc)))) return go(URLBASE + '/mercado?aba=sell');
      if (limited('mktlink:' + ipOf(req), 30)) return go(URLBASE + '/mercado?aba=sell');
      const S = C.s.get(acc) || {}, cur = Object.keys(S.owe || {}).find(c => (S.owe[c] | 0) > 0); if (!cur) return go(URLBASE + '/mercado?aba=sell&comissao=nada');
      const ss = await feeSession(acc, cur); return go(ss.url);
    } catch (e) { console.error('[mercado link comissão]', e.message); return go(URLBASE + '/mercado?aba=sell&comissao=erro'); }
  }
  async function billFee(o) {
    if (!o.feeBill || o.billed || !(o.feeWaived > 0)) return; const S = C.s.get(o.seller) || {};
    S.owe = S.owe || {}; const before = S.owe[o.cur] | 0; S.owe[o.cur] = before + o.feeWaived; if (S.owe[o.cur] > 0) S.oweAt = S.oweAt || now(); o.billed = now(); o.feeDue = o.feeWaived;
    o.log.push({ at: now(), ev: 'fee_billed', fee: o.feeWaived }); await putO(o); await putS(o.seller, S);
    DB.log('mkt_fee_owed', { oid: o.id, seller: o.seller, fee: o.feeWaived, cur: o.cur, owe: S.owe[o.cur] });
    await note(o.seller, 'Market fee for this sale: {0}. Stripe does not let the market take it automatically in your country, so it was added to your balance to pay: {1}. Pay it in Sell -> Pay market fee.', [mny(o.feeWaived, o.cur), mny(S.owe[o.cur], o.cur)], null, S.owe[o.cur] > 0 ? { url: feeLink(o.seller) } : null);
    if (before < minPlat(o.cur) && S.owe[o.cur] >= minPlat(o.cur)) await feeRemind(o.seller, 'min');   // chegou ao mínimo (R$ 3,40): link direto no jogo, no mercado e por e-mail
  }
  async function feePaid(s) {   // Checkout da comissão pago (webhook ou volta do Stripe) — idempotente pelo id da sessão
    const md = s.metadata || {}, acc = +md.mkt_fee || 0, cur = String(md.cur || s.currency || '').toLowerCase(), amt = +s.amount_total || 0; if (!acc || !amt || s.payment_status !== 'paid') return 'ignorado';
    return lockK('fee:' + acc, async () => { const S = C.s.get(acc) || {}; S.feeSids = S.feeSids || []; if (S.feeSids.includes(s.id)) return 'repetido';
      S.feeSids = [s.id, ...S.feeSids].slice(0, 50); S.owe = S.owe || {}; S.owe[cur] = (S.owe[cur] | 0) - amt; if (!Object.values(S.owe).some(v => (v | 0) > 0)) S.oweAt = 0;   // negativo = crédito
      S.feePaid = S.feePaid || {}; S.feePaid[cur] = (S.feePaid[cur] | 0) + amt; if (S.feeSid === s.id) S.feeSid = null; if (S.susp && S.suspWhy === 'fee' && !Object.values(S.owe).some(v => (v | 0) > 0)) { S.susp = false; S.suspWhy = ''; DB.log('mkt_fee_unsusp', { acc }); } await putS(acc, S);
      DB.log('mkt_fee_paid', { acc, sid: s.id, amt, cur, left: S.owe[cur] }); await note(acc, 'Market fee paid: {0}. Thank you!', [mny(amt, cur)]); return 'pago'; });
  }
  async function feeSession(acc, cur, force) {   // Checkout da comissão devida na conta do MERCADO (França); force = valor de teste do dono
    const S = C.s.get(acc) || {}, ow = force ? 0 : (S.owe || {})[cur] | 0; if (ow <= 0 && !force) throw new Error('nada a pagar'); const amt = force ? force : Math.max(ow, minPlat(cur));
    const a = await DB.accountById(acc), base = URLBASE + '/mercado?aba=sell&comissao=';
    const f = { mode: 'payment', success_url: base + 'ok', cancel_url: base + 'cancelado', customer_email: a && a.email, client_reference_id: 'fee-' + acc,
      'line_items[0][quantity]': '1', 'line_items[0][price_data][currency]': cur, 'line_items[0][price_data][unit_amount]': String(amt),
      'line_items[0][price_data][product_data][name]': 'Comissão do Mercado MuOnlineClaude', 'line_items[0][price_data][product_data][description]': 'Comissão de ' + C.cfg.fee + '% das vendas no mercado de jogadores' + (amt > ow ? ' (mínimo do Stripe: a diferença fica de crédito)' : ''),
      'metadata[mkt_fee]': String(acc), 'metadata[cur]': cur, 'payment_intent_data[metadata][mkt_fee]': String(acc), 'payment_method_types[0]': 'card' };
    const ss = await stripe('POST', '/v1/checkout/sessions', f, null, 'mkt-fee-' + acc + '-' + cur + '-' + amt + '-' + Math.floor(now() / 600000));
    S.feeSid = ss.id; await putS(acc, S); DB.log('mkt_fee_checkout', { acc, amt, cur, sid: ss.id }); return ss;
  }
  API['POST /api/mkt/payfee'] = async (b, req) => {   // o vendedor paga a comissão devida (vai para a conta Stripe do mercado)
    if (limited('mktfee:' + ipOf(req), 20)) return [429, { error: 'rate' }];
    const c = await load(), t = verify(b.token); if (!t) return [401, { error: 'auth' }]; if (!KEY) return [503, { error: 'stripe_off' }];
    const S = c.s.get(t.a) || {}, cur = CURS.includes(String(b.cur || '')) ? String(b.cur) : Object.keys(S.owe || {}).find(k => (S.owe[k] | 0) > 0);
    const ow = cur ? (S.owe || {})[cur] | 0 : 0; if (ow <= 0) return [400, { error: 'nothing' }];
    try { const ss = await feeSession(t.a, cur); return { url: ss.url }; }
    catch (e) { console.error('[mercado comissão]', e.message); return [502, { error: 'stripe' }]; }
  };
  async function feeCheck(acc) {   // volta da página de pagamento: confere a sessão no Stripe (caso o webhook demore)
    const S = C.s.get(acc); if (!S || !S.feeSid || !KEY) return; try { const ss = await stripe('GET', '/v1/checkout/sessions/' + S.feeSid); if (ss.payment_status === 'paid') await feePaid(ss); else if (ss.status === 'expired') { S.feeSid = null; await putS(acc, S); } } catch (e) { console.error('[mercado comissão]', e.message); }
  }
  /* (A) vendedor devendo comissão >= oweMax: TODOS os anúncios dele saem do ar até pagar (voltam sozinhos) */
  const owing = S => { const g = C && C.cfg; if (!g || g.feeBill === false || !(g.oweMax > 0)) return false; return Object.entries((S && S.owe) || {}).some(([c, v]) => (v | 0) >= Math.max(g.oweMax, minPlat(c))); };
  const sellerOff = acc => { const S = C.s.get(acc); return !!(S && (S.susp || owing(S))); };
  /* (B) comissão paga antes: vendedor em país onde o Stripe não deixa descontar a comissão (ex.: Brasil) paga a comissão do anúncio
     para a conta do mercado (França) e só então o anúncio entra no ar. Cancelou: o Stripe devolve a parte não vendida. */
  const feeRefused = S => !!(S && S.nofee && (!S.feeOk || S.nofee > S.feeOk));   // o Stripe recusou descontar a comissão na conta deste vendedor (e não aceitou depois)
  const needPre = S => !!(C.cfg.prepay !== false && S && !S.hold && feeRefused(S));   // só paga antes quem o Stripe não deixa descontar a comissão
  const preFee = L => Math.round(L.price * (L.unit ? (L.qty | 0) : 1) * C.cfg.fee / 100);
  async function preCheckout(L) {
    const a = await DB.accountById(L.seller), base = URLBASE + '/mercado?aba=mine&comissao=', n = (L.pre.n | 0) + 1; L.pre.n = n;
    const f = { mode: 'payment', success_url: base + 'ok&anuncio=' + L.id, cancel_url: base + 'cancelado&anuncio=' + L.id, customer_email: a && a.email, client_reference_id: 'pre-' + L.id,
      'line_items[0][quantity]': '1', 'line_items[0][price_data][currency]': L.cur, 'line_items[0][price_data][unit_amount]': String(L.pre.amt),
      'line_items[0][price_data][product_data][name]': 'Comissão do anúncio ' + L.id + ' — Mercado MuOnlineClaude', 'line_items[0][price_data][product_data][description]': C.cfg.fee + '% de ' + (L.snap && L.snap.name || L.it.b) + (L.unit ? ' ×' + L.qty : '') + '. Se cancelar o anúncio, a parte não vendida é devolvida.',
      'metadata[mkt_pre]': L.id, 'metadata[acc]': String(L.seller), 'payment_intent_data[metadata][mkt_pre]': L.id, 'payment_method_types[0]': 'card', expires_at: String(Math.floor((now() + 23.5 * 3600e3) / 1000)) };
    const ss = await stripe('POST', '/v1/checkout/sessions', f, null, 'mkt-pre-' + L.id + '-' + n); L.pre.sid = ss.id; await putL(L); return ss.url;
  }
  async function prePaid(ss) {   // comissão do anúncio paga (webhook ou volta da página) — idempotente
    const id = String((ss.metadata || {}).mkt_pre || ''); if (!id || ss.payment_status !== 'paid') return 'ignorado';
    return lockK('l:' + id, async () => { const L = C.l.get(id); if (!L || !L.pre) return 'sem anúncio'; if (L.pre.paid) return 'repetido';
      L.pre.paid = +ss.amount_total || L.pre.amt; L.pre.pi = typeof ss.payment_intent === 'string' ? ss.payment_intent : (ss.payment_intent && ss.payment_intent.id) || ''; L.pre.at = now();
      if (L.st === 'prepay') { const S = C.s.get(L.seller) || {}; L.st = S.ready ? 'active' : 'wait'; L.at = now(); }
      L.log.push({ at: now(), ev: 'prepaid', amt: L.pre.paid }); await putL(L); DB.log('mkt_prepaid', { lid: L.id, seller: L.seller, amt: L.pre.paid, cur: L.cur });
      const S2 = C.s.get(L.seller) || {}; S2.feePaid = S2.feePaid || {}; S2.feePaid[L.cur] = (S2.feePaid[L.cur] | 0) + L.pre.paid; await putS(L.seller, S2);
      await note(L.seller, 'Listing fee paid: {0}. Your listing is live.', [mny(L.pre.paid, L.cur)]); return 'pago'; });
  }
  async function preRefund(L, why) {   // devolve a comissão da parte que não foi vendida
    const P = L.pre; if (!P || !P.paid || P.refunded || !P.pi) return 0;
    const part = L.unit ? Math.max(0, Math.min(1, (L.left | 0) / Math.max(1, L.qty | 0))) : 1, amt = Math.floor(P.paid * part); if (amt < 1) { P.refunded = -1; return 0; }
    try { const r = await stripe('POST', '/v1/refunds', { payment_intent: P.pi, amount: String(amt), 'metadata[mkt_pre]': L.id, reason: 'requested_by_customer' }, null, 'mkt-pre-rf-' + L.id);
      P.refunded = amt; P.rf = r.id; L.log.push({ at: now(), ev: 'pre_refund', amt, why }); DB.log('mkt_pre_refund', { lid: L.id, amt, why });
      const S = C.s.get(L.seller) || {}; S.feePaid = S.feePaid || {}; S.feePaid[L.cur] = Math.max(0, (S.feePaid[L.cur] | 0) - amt); await putS(L.seller, S);
      await note(L.seller, 'Listing fee refunded: {0} (unsold part).', [mny(amt, L.cur)]); return amt; }
    catch (e) { P.rfErr = e.message; L.log.push({ at: now(), ev: 'pre_refund_error', msg: e.message }); await alog(0, 'pre_refund_error', { lid: L.id, amt, msg: e.message }); return 0; }
  }
  API['POST /api/mkt/prepay'] = async (b, req) => {   // (re)abre o pagamento da comissão de um anúncio
    if (limited('mktfee:' + ipOf(req), 20)) return [429, { error: 'rate' }];
    await load(); const t = verify(b.token); if (!t) return [401, { error: 'auth' }];
    return lockK('l:' + b.id, async () => { const L = C.l.get(String(b.id || '')); if (!L || L.seller !== t.a || L.st !== 'prepay' || !L.pre) return [404, { error: 'gone' }];
      if (await preTooSmall(L)) return { paid: true };
      if (L.pre.sid) { try { const ss = await stripe('GET', '/v1/checkout/sessions/' + L.pre.sid); if (ss.payment_status === 'paid') { await prePaid(ss); return { paid: true }; } if (ss.status === 'open' && ss.url) return { url: ss.url }; } catch (_) {} }
      try { return { url: await preCheckout(L) }; } catch (e) { console.error('[mercado comissão anúncio]', e.message); return [502, { error: 'stripe' }]; } });
  };
  async function preTooSmall(L) {   // comissão abaixo do mínimo do Stripe: o anúncio entra no ar sem pagar antes (a comissão é cobrada depois da venda)
    if (!L.pre || L.pre.paid || L.pre.amt >= minPlat(L.cur)) return false; const S = C.s.get(L.seller) || {};
    delete L.pre; L.st = S.ready ? 'active' : 'wait'; L.at = now(); L.log.push({ at: now(), ev: 'pre_small' }); await putL(L); return true; }
  async function preCheck(acc) {   // volta da página de pagamento: confere as sessões abertas
    for (const L of [...C.l.values()]) if (L.seller === acc && L.st === 'prepay' && L.pre && L.pre.sid) { try { const ss = await stripe('GET', '/v1/checkout/sessions/' + L.pre.sid); if (ss.payment_status === 'paid') await prePaid(ss); } catch (_) {} }
  }
  /* (C) comissão atrasada há mais de suspDays dias: suspende do mercado (não compra nem vende); pagou -> volta sozinho */
  async function feeSuspend() {
    if (C.cfg.feeBill === false) return;
    for (const [acc, S] of [...C.s.entries()]) if (Object.entries(S.owe || {}).some(([c, v]) => (v | 0) >= minPlat(c)) && now() - (S.remAt || S.oweAt || 0) > 24 * 3600e3) await feeRemind(acc, 'daily');   // lembrete 1 vez por dia
    const days = C.cfg.suspDays | 0; if (!days) return;
    for (const [acc, S] of [...C.s.entries()]) { const ow = Object.values(S.owe || {}).some(v => (v | 0) > 0);
      if (ow && !S.susp && S.oweAt && now() - S.oweAt > days * 864e5) { S.susp = true; S.suspWhy = 'fee'; S.suspAt = now(); await putS(acc, S); DB.log('mkt_fee_susp', { acc, owe: S.owe });
        await note(acc, 'Your market account was suspended because the market fee is more than {0} days late. Pay it in Sell -> Pay market fee and it is reactivated automatically.', [days], ['MuOnlineClaude: conta do mercado suspensa', 'A sua conta no mercado de jogadores foi suspensa porque a comissão está atrasada há mais de ' + days + ' dias.\n\nPague por este link e ela volta na hora:\n' + feeLink(acc) + '\n\nMuOnlineClaude'], { url: feeLink(acc) }); }
      else if (!ow && S.susp && S.suspWhy === 'fee') { S.susp = false; S.suspWhy = ''; await putS(acc, S); DB.log('mkt_fee_unsusp', { acc }); await note(acc, 'Market fee paid: your market account is active again.'); } }
  }
  async function refreshSeller(acc, force) {
    const S = C.s.get(acc); if (!S || !S.acct || !KEY) return S || {};
    if (!force && S.chk && now() - S.chk < 30000) return S;
    try { const a = await stripe('GET', '/v1/accounts/' + S.acct);
      const was = !!S.ready; S.ready = !!a.charges_enabled; S.pay = !!a.payouts_enabled;   // já pode vender quando o Stripe libera cobranças; o dinheiro fica no saldo Stripe dele até o banco ser liberado
      S.det = !!a.details_submitted; S.due = ((a.requirements && a.requirements.currently_due) || []).length; S.chk = now();
      await putS(acc, S); if (S.ready && !was) { await note(acc, 'Your Stripe account is verified. You can sell on the market now.'); await publishWaiting(acc); payHeld(acc).catch(e => console.error('[mercado repasse]', e.message)); } } catch (e) { console.error('[mercado stripe conta]', e.message); }
    return S;
  }
  API['POST /api/mkt/connect'] = async (b, req) => {
    if (limited('mktcon:' + ipOf(req), 20)) return [429, { error: 'rate' }];
    const c = await load(), t = verify(b.token); if (!t) return [401, { error: 'auth' }]; if (!KEY) return [503, { error: 'stripe_off' }];
    const S = c.s.get(t.a) || { at: now() }; if (S.susp) return [403, { error: 'susp' }];
    try {
      if (!S.acct) { const country = String(b.country || '').toUpperCase(); if (!c.cfg.countries.includes(country) && !XB.includes(country)) return [400, { error: 'country' }];
        if (S.hold && !XB.includes(country)) return [400, { error: 'country_hold' }];   // dinheiro guardado só pode ir para conta em US/UK/EEE/CA/CH
        const a = await DB.accountById(t.a);
        // chave de repetição muda a cada 2 minutos: evita conta duplicada num clique duplo, mas não fica preso num erro antigo (o Stripe guarda a resposta por 24 h)
        const idem = 'mkt-acct-' + t.a + '-' + Math.floor(now() / 120000); let ac = null, v1err = null;
        try { ac = await stripe('POST', '/v1/accounts', { type: 'standard', country, email: a.email,   // conta Standard: a conta Stripe é do próprio vendedor (é o tipo que o Stripe aceita no Brasil)
          'metadata[acc]': String(t.a), 'business_profile[url]': URLBASE, 'business_profile[product_description]': 'Venda de itens do jogo MuOnlineClaude no mercado de jogadores' }, null, idem); }
        catch (e) { v1err = e; }
        if (!ac) {   // plano B: plataforma do Connect novo (Accounts v2) — conta com o painel completo do Stripe, igual à Standard
          try { ac = await stripe2('/v2/core/accounts', { contact_email: a.email || undefined, display_name: String(a.username || ('Jogador ' + t.a)).slice(0, 80), dashboard: 'full',
              identity: { country: country.toLowerCase() }, configuration: { merchant: { capabilities: { card_payments: { requested: true } } } },
              defaults: { currency: 'brl', responsibilities: { fees_collector: 'stripe', losses_collector: 'stripe' } }, metadata: { acc: String(t.a) } }, idem + '-v2');
            S.v2 = 1; console.error('[mercado connect] conta criada pela API v2 (v1 recusou: ' + (v1err && v1err.message || '').slice(0, 120) + ')'); }
          catch (e2) { console.error('[mercado connect] v1:', v1err && v1err.message, '| v2:', e2.message); throw e2; } }
        S.acct = ac.id; S.country = country; S.at = S.at || now(); await putS(t.a, S); DB.log('mkt_connect', { acc: t.a, acct: ac.id, country, v2: S.v2 | 0 }); }
      const ret = { refresh_url: URLBASE + '/mercado?conectar=renovar', return_url: URLBASE + '/mercado?conectar=ok' };
      const link = S.v2 ? await stripe2('/v2/core/account_links', { account: S.acct, use_case: { type: 'account_onboarding', account_onboarding: Object.assign({ configurations: ['merchant'] }, ret) } })
        : await stripe('POST', '/v1/account_links', Object.assign({ account: S.acct, type: 'account_onboarding' }, ret));
      return { url: link.url };
    } catch (e) { console.error('[mercado connect]', e.message); return [502, { error: 'stripe' }]; }
  };
  API['POST /api/mkt/dash'] = async b => { const c = await load(), t = verify(b.token); if (!t) return [401, { error: 'auth' }]; const S = c.s.get(t.a); if (!S || !S.acct) return [400, { error: 'connect' }];
    return { url: 'https://dashboard.stripe.com/' }; };   // conta Standard: o vendedor entra no painel do Stripe com o login dele
  /* ---------- vendedor sem Stripe (US/UK/EEE/CA/CH): o dinheiro fica no mercado e vai sozinho quando ele conecta ----------
     O Stripe só deixa uma plataforma da França transferir para contas nesses países (não para o Brasil).
     Repasse = valor que entrou na conta do mercado (já convertido para a moeda da plataforma) menos a comissão do mercado. */
  API['POST /api/mkt/holdopt'] = async (b, req) => {
    if (limited('mktcon:' + ipOf(req), 20)) return [429, { error: 'rate' }];
    const c = await load(), t = verify(b.token); if (!t) return [401, { error: 'auth' }]; if (!c.cfg.holdOn) return [403, { error: 'off' }];
    const S = c.s.get(t.a) || { at: now() }; if (S.susp) return [403, { error: 'susp' }]; if (S.acct && S.ready) return { ok: true, ready: true };
    const country = String(b.country || '').toUpperCase(); if (!XB.includes(country)) return [400, { error: 'country' }];
    S.hold = country; S.at = S.at || now(); await putS(t.a, S); DB.log('mkt_holdopt', { acc: t.a, country }); return { ok: true };
  };
  const payBusy = new Set();
  async function payHeld(acc) {
    if (payBusy.has(acc) || !KEY) return 0; payBusy.add(acc); let n = 0;
    try { const S = C.s.get(acc); if (!S || !S.acct || !S.ready || S.susp) return 0;
      for (const o of [...C.o.values()]) { if (o.seller !== acc || o.mode !== 'hold' || o.st !== 'delivered' || !o.pay || !['held', 'error'].includes(o.pay.st)) continue;
        await lockK('o:' + o.id, async () => { if (!o.pay || !['held', 'error'].includes(o.pay.st) || o.st !== 'delivered') return;
          try { const pi = await stripe('GET', '/v1/payment_intents/' + o.pi + '?expand[]=latest_charge.balance_transaction'), ch = pi.latest_charge || {}, bt = ch.balance_transaction || {};
            if (!ch.id || !bt.amount) throw new Error('cobrança sem saldo');
            const amount = Math.floor((bt.amount | 0) * (100 - (o.feePct === undefined ? 10 : o.feePct)) / 100);
            const tr = await stripe('POST', '/v1/transfers', { amount: String(amount), currency: bt.currency, destination: S.acct, source_transaction: ch.id, transfer_group: o.id, 'metadata[mkt_order]': o.id, description: 'Mercado MuOnlineClaude · ' + o.item }, null, 'mkt-tr-' + o.id);
            o.pay = { st: 'sent', tr: tr.id, amount, cur: bt.currency, at: now() }; o.log.push({ at: now(), ev: 'transfer', tr: tr.id, amount, cur: bt.currency }); await putO(o); n++;
            await note(acc, 'Your share of {0} was sent to your Stripe account: {1}.', [o.item, (amount / 100).toFixed(2) + ' ' + String(bt.currency).toUpperCase()], ['🏦 Sua parte da venda foi enviada', 'A sua parte da venda de "' + o.item + '" foi enviada para a sua conta Stripe: ' + (amount / 100).toFixed(2) + ' ' + String(bt.currency).toUpperCase() + '.\nPedido: ' + o.id]);
            DB.log('mkt_transfer', { oid: o.id, acc, tr: tr.id, amount, cur: bt.currency });
          } catch (e) { o.pay = Object.assign({}, o.pay, { st: 'error', msg: String(e.message).slice(0, 200), tries: ((o.pay && o.pay.tries) | 0) + 1, last: now() }); await putO(o); console.error('[mercado repasse]', o.id, e.message); }
        }); }
    } finally { payBusy.delete(acc); } return n;
  }
  /* ---------- inventário para anunciar (só leitura; não abre sessão de jogo) ---------- */
  API['POST /api/mkt/inv'] = async b => {
    await load(); const t = verify(b.token); if (!t) return [401, { error: 'auth' }]; const row = await DB.charById(+b.char); if (!row || row.account_id !== t.a) return [400, { error: 'char' }];
    const sv = await DB.kvGet('mu:' + row.id); if (!sv) return [400, { error: 'char' }];
    return { active: heroActive(row.id, sv), level: sv.level | 0, resets: sv.resets | 0, items: (sv.inv || []).map((it, i) => it && tradeable(it) ? { slot: i, it } : null).filter(Boolean) };
  };
  /* ---------- anunciar / editar / cancelar ---------- */
  const okImgs = async (acc, ids) => { const out = []; for (const id of (Array.isArray(ids) ? ids : []).slice(0, 3)) { if (!/^i\d+$/.test(String(id))) continue; const im = await DB.kvGet('mkt:img:' + id); if (im && im.acc === acc) out.push(String(id)); } return out; };
  const okPrice = (p, cur) => { const v = Math.round(+p); return CURS.includes(cur) && Number.isFinite(v) && v >= C.cfg.min && v <= C.cfg.max ? v : 0; };
  API['POST /api/mkt/list'] = async (b, req) => {
    if (limited('mktlist:' + ipOf(req), 40)) return [429, { error: 'rate' }];
    const c = await load(), t = verify(b.token); if (!t) return [401, { error: 'auth' }];
    const row = await DB.charById(+b.char); if (!row || row.account_id !== t.a) return [400, { error: 'char' }];
    const S = c.s.get(t.a) || {}; if (S.susp) return [403, { error: 'susp' }];
    if (!(S.acct && S.ready) && !(S.hold && c.cfg.holdOn)) { if (S.acct) await refreshSeller(t.a, true); if (!S.acct) return [409, { error: 'connect' }]; }   // cadastro no Stripe ainda não terminou: o anúncio fica guardado e entra no ar sozinho quando o Stripe aprovar
    if (owing(S)) return [402, { error: 'owe', owe: S.owe }];   // comissão atrasada: paga antes de anunciar de novo
    const cur = String(b.cur || '').toLowerCase(), price = okPrice(b.price, cur); if (!price) return [400, { error: 'price', min: c.cfg.min, max: c.cfg.max }];
    if ([...c.l.values()].filter(l => l.seller === t.a && (l.st === 'active' || l.st === 'reserved' || l.st === 'wait')).length >= c.cfg.maxAct) return [429, { error: 'max_act', max: c.cfg.maxAct }];
    const imgs = await okImgs(t.a, b.imgs), desc = clean(b.desc).slice(0, 500);
    return lockK('c:' + row.id, async () => {
      const sv = await DB.kvGet('mu:' + row.id); if (!sv) return [400, { error: 'char' }];
      if ((sv.level | 0) < c.cfg.minLvl && !(sv.resets | 0)) return [403, { error: 'newbie', need: c.cfg.minLvl }];
      if (!b.game && heroActive(row.id, sv)) return [409, { error: 'online' }];
      const i = (sv.inv || []).findIndex(x => x && x.u === String(b.uid || '')); if (i < 0) return [404, { error: 'item' }];
      const it = sv.inv[i]; if (!tradeable(it)) return [400, { error: 'bound' }];
      sv.inv[i] = null; await DB.kvSet('mu:' + row.id, sv);
      C.locks[it.u] = t.a; await putLocks();
      const id = await nextId('L'), B = D.BASES[it.b], snap = { at: now(), name: D.itemName(it), stats: B && B.equip ? D.itemStats(it, 2000) : null };   // fotografia dos atributos no momento do anúncio
      const live = !!((c.s.get(t.a) || {}).ready) || !!(S.hold && c.cfg.holdOn), pre0 = needPre(c.s.get(t.a) || S);
      const L = { id, seller: t.a, schar: row.id, sname: sv.name, it: JSON.parse(JSON.stringify(it)), snap, price, cur, desc, imgs, st: live ? 'active' : 'wait', at: now(), views: 0, log: [{ at: now(), ev: 'list', price, cur }] };
      if (B && B.stack) { L.unit = 1; L.qty = L.left = Math.max(1, it.q | 0); L.resv = {}; L.done = {}; }   // por quantidade: preço por unidade, sai do mercado quando acabar o estoque
      let preUrl = null; if (pre0 && preFee(L) >= minPlat(L.cur)) { L.pre = { amt: preFee(L), at0: now() }; L.st = 'prepay'; }   // (B) comissão paga antes do anúncio entrar no ar
      await putL(L);
      if (L.pre) { try { preUrl = await preCheckout(L); } catch (e) { console.error('[mercado comissão anúncio]', e.message); } } DB.log('mkt_list', { id, acc: t.a, char: row.id, b: it.b, u: it.u, price, cur });
      return { ok: true, id, wait: !live, prepay: L.pre ? { amt: L.pre.amt, cur: L.cur, url: preUrl } : undefined, sv: b.game ? await muOutSv(row.id, sv) : undefined };
    });
  };
  API['POST /api/mkt/edit'] = async b => {
    const c = await load(), t = verify(b.token); if (!t) return [401, { error: 'auth' }];
    return lockK('l:' + b.id, async () => {
      const L = c.l.get(String(b.id || '')); if (!L || L.seller !== t.a) return [404, { error: 'gone' }]; if ((L.st !== 'active' && L.st !== 'wait') || (L.unit && liveResv(L) > 0)) return [409, { error: 'locked' }];
      if (b.price !== undefined || b.cur !== undefined) { const cur = String(b.cur || L.cur).toLowerCase(), price = okPrice(b.price !== undefined ? b.price : L.price, cur); if (!price) return [400, { error: 'price', min: c.cfg.min, max: c.cfg.max }];
        if (L.pre && (cur !== L.cur || price > L.price)) return [409, { error: 'prepaid_price' }];   // comissão já paga sobre o preço: só dá para baixar
        L.price = price; L.cur = cur; }
      if (b.desc !== undefined) L.desc = clean(b.desc).slice(0, 500);
      if (b.imgs !== undefined) L.imgs = await okImgs(t.a, b.imgs);
      L.log.push({ at: now(), ev: 'edit', price: L.price, cur: L.cur }); await putL(L); return { ok: true, l: pubL(L, true) };
    });
  };
  async function giveBack(L, why) {   // devolve o item ao vendedor (cancelado, removido pelo admin, vendedor suspenso)
    if (C.locks[L.it.u] === L.seller) { delete C.locks[L.it.u]; await putLocks(); }
    const it = L.unit ? Object.assign(JSON.parse(JSON.stringify(L.it)), { q: L.left | 0 }) : L.it;   // por quantidade: volta só o que não foi vendido
    const ch = (!L.unit || (L.left | 0) > 0) ? await targetChar(L.seller, L.schar) : 0; if (ch) await boxPush(ch, { it, src: 'return', ref: L.id, at: now() });
    L.log.push({ at: now(), ev: 'return', why, char: ch });
    if (L.pre) await preRefund(L, why);   // (B) devolve a comissão paga da parte não vendida
  }
  API['POST /api/mkt/cancel'] = async b => {
    const c = await load(), t = verify(b.token); if (!t) return [401, { error: 'auth' }];
    return lockK('l:' + b.id, async () => {
      const L = c.l.get(String(b.id || '')); if (!L || L.seller !== t.a) return [404, { error: 'gone' }];
      if (L.st === 'reserved' && L.resUntil > now()) return [409, { error: 'reserved' }]; if (L.st !== 'active' && L.st !== 'reserved' && L.st !== 'wait' && L.st !== 'prepay') return [409, { error: 'locked' }];
      if (L.unit && liveResv(L) > 0) return [409, { error: 'reserved' }];
      L.st = 'cancelled'; L.res = null; await giveBack(L, 'cancel'); await putL(L); DB.log('mkt_cancel', { id: L.id, acc: t.a }); return { ok: true };
    });
  };
  /* ---------- comprar ---------- */
  async function release(o, why) {   // pagamento não aconteceu: o anúncio volta a ficar disponível
    return lockK('o:' + o.id, async () => {
      const cur = C.o.get(o.id); if (!cur || cur.st !== 'pending') return 'nada';
      cur.st = why; cur.log.push({ at: now(), ev: why }); await putO(cur);
      await lockK('l:' + cur.lid, async () => { const L = C.l.get(cur.lid); if (L && L.unit && L.resv && L.resv[cur.id]) { delete L.resv[cur.id]; L.log.push({ at: now(), ev: 'released', oid: cur.id, why }); await putL(L); }
        else if (L && L.st === 'reserved' && L.res === cur.id) { L.st = 'active'; L.res = null; L.resUntil = 0; L.log.push({ at: now(), ev: 'released', why }); await putL(L); } });
      return why;
    });
  }
  API['POST /api/mkt/buy'] = async (b, req) => {
    if (limited('mktbuy:' + ipOf(req), 20)) return [429, { error: 'rate' }];
    const c = await load(); if (!payOn()) return [503, { error: 'off' }];
    const t = verify(b.token); if (!t) return [401, { error: 'auth' }];
    const brow = await DB.charById(+b.char); if (!brow || brow.account_id !== t.a) return [400, { error: 'char' }];
    const me = c.s.get(t.a) || {}; if (me.susp) return [403, { error: 'susp' }];
    if ([...c.o.values()].filter(o => o.buyer === t.a && o.st === 'pending').length >= 3) return [429, { error: 'open' }];
    const acc = await DB.accountById(t.a), bsv = await DB.kvGet('mu:' + brow.id);
    return lockK('l:' + b.id, async () => {
      const L = c.l.get(String(b.id || '')); if (!L) return [404, { error: 'gone' }];
      if (L.unit) for (const [oid, r] of Object.entries(L.resv || {})) { const po = c.o.get(oid);   // reservas vencidas do anúncio por quantidade
        if (!po || ((po.st === 'pending' && r.until < now()) || ['expired', 'cancelled', 'failed', 'mismatch', 'conflict'].includes(po.st))) { if (po && po.st === 'pending') { po.st = 'expired'; po.log.push({ at: now(), ev: 'expired' }); await putO(po); } delete L.resv[oid]; } }
      if (!L.unit && L.st === 'reserved' && L.resUntil < now()) {   // reserva vencida: libera aqui mesmo (já estamos com a trava do anúncio)
        const po = c.o.get(L.res); if (po && ['paid', 'delivered', 'paid_nochar'].includes(po.st)) return [409, { error: 'reserved' }];   // pagamento já entrou: o item é desse comprador
        if (po && po.st === 'pending') { po.st = 'expired'; po.log.push({ at: now(), ev: 'expired' }); await putO(po); } L.st = 'active'; L.res = null; L.resUntil = 0; }
      if (L.st !== 'active') return [409, { error: L.st === 'reserved' ? 'reserved' : 'gone' }];
      const av = availOf(L), qn = L.unit ? Math.max(1, Math.min(av, Math.floor(+b.q || 1))) : 1;
      if (L.unit && av < 1) return [409, { error: (L.left | 0) > 0 ? 'reserved' : 'gone' }];
      if (L.seller === t.a) return [400, { error: 'own' }];
      if (!tradeable(L.it) || C.locks[L.it.u] !== L.seller) return [409, { error: 'gone' }];   // confere de novo o item real guardado pelo mercado
      const S = c.s.get(L.seller); if (!S || S.susp) return [409, { error: 'seller' }]; if (owing(S)) return [409, { error: 'seller_owe' }];
      const direct = !!(S.acct && S.ready), held = !direct && !!(S.hold && c.cfg.holdOn); if (!direct && !held) return [409, { error: 'seller' }];
      let feePct = c.cfg.fee; try { if (MU && MU.vipOf) { const vt = (await MU.vipOf(L.seller)).tier, T = vt && D.VIP_TIERS[vt]; if (T && T.mktFee != null) feePct = Math.min(feePct, T.mktFee); } } catch (_) {}   // vendedor VIP paga comissão menor
      const amount = L.price * qn, fee = Math.round(amount * feePct / 100), oid = await nextId('o'), exp = now() + c.cfg.hold * 60000, B = D.BASES[L.it.b] || {};
      const o = { id: oid, lid: L.id, buyer: t.a, bchar: brow.id, bname: (bsv && bsv.name) || brow.name || (brow.data && brow.data.name) || '?', seller: L.seller, schar: L.schar, sname: L.sname, amount, cur: L.cur, fee, net: amount - fee, q: qn,
        st: 'pending', at: now(), exp, item: (D.itemName ? D.itemName(Object.assign({}, L.it, { q: qn })) : (B.name || L.it.b)) + (L.unit && qn > 1 ? ' ×' + qn : ''), log: [{ at: now(), ev: 'reserved' }], mode: held ? 'hold' : 'direct', feePct };
      if (L.unit) { L.resv = L.resv || {}; L.resv[oid] = { q: qn, until: exp }; } else { L.st = 'reserved'; L.res = oid; L.resUntil = exp; }
      L.log.push({ at: now(), ev: 'reserved', oid, q: qn }); await putL(L); await putO(o);
      const f = { mode: 'payment', success_url: URLBASE + '/mercado?pedido=' + oid + '&pago=ok', cancel_url: URLBASE + '/mercado?pedido=' + oid + '&pago=cancelado', client_reference_id: oid,
        customer_email: acc.email, expires_at: String(Math.floor(exp / 1000)), 'line_items[0][quantity]': String(qn), 'line_items[0][price_data][currency]': L.cur, 'line_items[0][price_data][unit_amount]': String(L.price),
        'line_items[0][price_data][product_data][name]': o.item + ' — Mercado MuOnlineClaude', 'line_items[0][price_data][product_data][description]': 'Vendedor: ' + L.sname + ' · anúncio ' + L.id + ' · entregue no herói ' + o.bname,
        'metadata[mkt_order]': oid, 'metadata[lid]': L.id, 'payment_intent_data[metadata][mkt_order]': oid,
        'payment_method_types[0]': 'card' };
      if (L.cur === 'brl' && c.cfg.pix && direct && !(S.nopix && now() - S.nopix < 864e5)) f['payment_method_types[1]'] = 'pix';   // vendedor sem Pix ativo no Stripe: vai direto só com cartão
      const noFee = () => { delete f['payment_intent_data[application_fee_amount]']; o.feeWaived = o.fee; o.fee = 0; o.net = o.amount; if (c.cfg.feeBill !== false) o.feeBill = 1; o.log.push({ at: now(), ev: 'no_fee' }); };   // a comissão vira cobrança separada para a conta do mercado (feeBill)
      if (direct) { f['payment_intent_data[application_fee_amount]'] = String(fee); o.acct = S.acct;
        if (L.pre && L.pre.paid) { delete f['payment_intent_data[application_fee_amount]']; o.feePre = 1; o.log.push({ at: now(), ev: 'fee_prepaid' }); }   // comissão já paga no anúncio
        else if (S.nofee && c.cfg.nofee !== false && fee > 0) noFee(); }   // cobrança direta na conta Stripe do vendedor; o mercado fica com a comissão (application fee)
      else { o.acct = null; f['payment_intent_data[transfer_group]'] = oid; }   // vendedor ainda sem Stripe: a cobrança fica na conta do mercado e a parte dele vai quando ele conectar
      try { let s = null;
        for (let tr = 0; !s; tr++) {   // tenta de novo sem o que o Stripe recusou: Pix não ativo na conta do vendedor / comissão não permitida para o país do vendedor
          try { s = await stripe('POST', '/v1/checkout/sessions', f, o.acct, 'mkt-' + oid + (tr ? '-' + tr : '')); }
          catch (e1) { const m = String(e1.message || '');
            if (tr < 3 && f['payment_method_types[1]'] && (/pix/i.test(m) || !/application.?fee/i.test(m))) { delete f['payment_method_types[1]']; if (/pix/i.test(m)) { S.nopix = now(); await putS(L.seller, S); if (C.cfg.lastErr && /pix/i.test(C.cfg.lastErr.msg)) C.cfg.lastErr = null; } o.log.push({ at: now(), ev: 'no_pix', msg: m }); continue; }
            if (tr < 3 && f['payment_intent_data[application_fee_amount]'] && /application.?fee/i.test(m) && c.cfg.nofee !== false) { noFee(); S.nofee = now(); await putS(L.seller, S); DB.log('mkt_nofee', { oid, seller: L.seller, country: S.country || '', fee: o.feeWaived, msg: m.slice(0, 160) }); continue; }
            throw e1; } }
        if (f['payment_intent_data[application_fee_amount]'] && o.acct && (!S.feeOk || now() - S.feeOk > 3600e3)) { S.feeOk = now(); await putS(L.seller, S); }   // o Stripe aceitou descontar a comissão nesta conta
        o.sid = s.id; o.log.push({ at: now(), ev: 'checkout', sid: s.id }); await putO(o); DB.log('mkt_checkout', { oid, lid: L.id, buyer: t.a, amount: L.price, cur: L.cur }); return { url: s.url, order: oid }; }
      catch (e) { o.st = 'failed'; o.err = e.message; o.log.push({ at: now(), ev: 'stripe_error', msg: e.message }); await putO(o); if (L.unit) { delete L.resv[oid]; } else { L.st = 'active'; L.res = null; L.resUntil = 0; } await putL(L); console.error('[mercado checkout]', e.message); return [502, { error: 'stripe' }]; }
    });
  };
  API['POST /api/mkt/abandon'] = async b => {   // comprador voltou sem pagar: encerra a sessão no Stripe e libera o anúncio
    const c = await load(), t = verify(b.token); if (!t) return [401, { error: 'auth' }]; const o = c.o.get(String(b.order || '')); if (!o || o.buyer !== t.a) return [404, { error: 'order' }];
    if (o.st !== 'pending') return { st: o.st };
    if (o.sid) { try { const s = await stripe('POST', '/v1/checkout/sessions/' + o.sid + '/expire', {}, o.acct); if (s && s.status === 'complete') return { st: 'paying' }; } catch (e) { return { st: 'pending' }; } }
    return { st: await release(o, 'cancelled') };
  };
  API['POST /api/mkt/order'] = async b => { const c = await load(), t = verify(b.token); if (!t) return [401, { error: 'auth' }]; const o = c.o.get(String(b.order || '')); if (!o || (o.buyer !== t.a && o.seller !== t.a)) return [404, { error: 'order' }];
    if (o.st === 'pending') await verifyOrder(o);   // a página de volta do pagamento pergunta aqui: confere no Stripe e entrega na hora
    const cur = C.o.get(o.id) || o; return { id: cur.id, st: cur.st, item: cur.item, amount: cur.amount, cur: cur.cur, bname: cur.bname }; };
  /* ---------- pagamento confirmado (webhook) -> transfere o item ---------- */
  async function finish(o) {   // idempotente: dá para chamar de novo depois de uma queda do servidor
    const L = C.l.get(o.lid); if (!L) return 'sem anúncio';
    const ch = await targetChar(o.buyer, o.bchar); if (!ch) { o.st = 'paid_nochar'; o.log.push({ at: now(), ev: 'no_char' }); await putO(o); return 'sem herói'; }
    C.locks[L.it.u] = o.seller; await putLocks();
    if (L.unit) {   // por quantidade: o comprador recebe uma pilha nova com a quantidade comprada; o anúncio só sai quando o estoque acaba
      if (!o.du) { o.du = D.newUid(); await putO(o); }
      const it = Object.assign(JSON.parse(JSON.stringify(L.it)), { u: o.du, q: o.q | 0 || 1 });
      await boxPush(ch, { it, src: 'buy', ref: o.id, at: now() });
      await lockK('l:' + L.id, async () => { L.done = L.done || {}; if (!L.done[o.id]) { L.done[o.id] = 1; L.left = Math.max(0, (L.left | 0) - (o.q | 0 || 1)); }
        if (L.resv) delete L.resv[o.id]; L.log.push({ at: now(), ev: 'sold', oid: o.id, q: o.q, left: L.left });
        if ((L.left | 0) <= 0 && L.st === 'active') { L.st = 'sold'; L.soldAt = now(); L.buyer = o.buyer; L.oid = o.id; } await putL(L); });
    } else {
    await boxPush(ch, { it: L.it, src: 'buy', ref: o.id, at: now() });
    await lockK('l:' + L.id, async () => { L.st = 'sold'; L.res = null; L.soldAt = now(); L.buyer = o.buyer; L.oid = o.id; L.log.push({ at: now(), ev: 'sold', oid: o.id }); await putL(L); });
    }
    o.st = 'delivered'; o.delAt = now(); o.dchar = ch; o.log.push({ at: now(), ev: 'delivered', char: ch }); await putO(o);
    await billFee(o);
    if (o.mode === 'hold' && !o.pay) { o.pay = { st: 'held', at: now() }; o.log.push({ at: now(), ev: 'held' }); await putO(o); }
    const S = C.s.get(o.seller) || {}; S.sales = (S.sales | 0) + 1; S.gross = S.gross || {}; S.gross[o.cur] = (S.gross[o.cur] | 0) + o.amount; S.net = S.net || {}; S.net[o.cur] = (S.net[o.cur] | 0) + o.net; await putS(o.seller, S);
    const money = (v, cur) => (cur === 'brl' ? 'R$ ' : cur === 'usd' ? 'US$ ' : '€ ') + (v / 100).toFixed(2);
    if (o.mode === 'hold') { await note(o.seller, 'Sold: {0} for {1}. Your share ({2}) is waiting for you: connect your Stripe account and it is sent automatically.', [o.item, money(o.amount, o.cur), money(o.net, o.cur)],
      ['💰 Você vendeu ' + o.item + ' no Mercado', 'Seu item "' + o.item + '" foi vendido por ' + money(o.amount, o.cur) + '.\nComissão do mercado: ' + money(o.fee, o.cur) + '\nSua parte: ' + money(o.net, o.cur) + ' (aproximado; o Stripe converte a moeda).\nO dinheiro está guardado para você. Conecte a sua conta Stripe no Mercado (aba Vender) e a sua parte é enviada automaticamente.\nPedido: ' + o.id]);
      if ((C.s.get(o.seller) || {}).ready) payHeld(o.seller).catch(e => console.error('[mercado repasse]', e.message)); }
    else await note(o.seller, 'Sold: {0} for {1}. You receive {2} (fee {3}) through Stripe.', [o.item, money(o.amount, o.cur), money(o.net, o.cur), money(o.fee, o.cur)],
      ['💰 Você vendeu ' + o.item + ' no Mercado', 'Seu item "' + o.item + '" foi vendido por ' + money(o.amount, o.cur) + '.\nComissão do mercado: ' + money(o.fee, o.cur) + '\nVocê recebe: ' + money(o.net, o.cur) + ' pelo Stripe (repasse automático para a sua conta bancária).\nPedido: ' + o.id]);
    await note(o.buyer, 'Payment confirmed: {0} will arrive in the inventory of {1}.', [o.item, o.bname], ['🛒 Compra confirmada: ' + o.item, 'Pagamento confirmado. O item "' + o.item + '" vai entrar no inventário do herói ' + o.bname + ' assim que você entrar no jogo (se o inventário estiver cheio, ele fica guardado até liberar espaço).\nPedido: ' + o.id]);
    DB.log('mkt_sold', { oid: o.id, lid: L.id, seller: o.seller, buyer: o.buyer, char: ch, amount: o.amount, cur: o.cur, fee: o.fee, u: L.it.u });
    return 'entregue';
  }
  async function paid(s) {
    const oid = (s.metadata || {}).mkt_order;
    return lockK('o:' + oid, async () => {
      const o = C.o.get(oid); if (!o) return 'sem pedido';
      if (o.st === 'delivered' || o.st === 'refunded' || o.st === 'disputed') return 'já entregue';
      if (s.amount_total !== o.amount || String(s.currency || '').toLowerCase() !== o.cur) { o.st = 'mismatch'; o.review = true; o.log.push({ at: now(), ev: 'mismatch', total: s.amount_total, cur: s.currency }); await putO(o); await alog(0, 'mismatch', { oid });
        await lockK('l:' + o.lid, async () => { const L = C.l.get(o.lid); if (L && L.unit && L.resv && L.resv[o.id]) { delete L.resv[o.id]; await putL(L); } else if (L && L.st === 'reserved' && L.res === o.id) { L.st = 'active'; L.res = null; L.resUntil = 0; L.log.push({ at: now(), ev: 'released', why: 'mismatch' }); await putL(L); } });
        return 'valor diferente'; }
      if (o.st !== 'paid') {
        const L = C.l.get(o.lid);
        if (L && L.unit) {   // por quantidade: se a reserva venceu, só segue se ainda houver estoque livre
          const mine = L.resv && L.resv[o.id]; if (!mine) { if (L.st === 'active' && availOf(L) >= (o.q | 0 || 1)) { L.resv = L.resv || {}; L.resv[o.id] = { q: o.q | 0 || 1, until: now() + 3600e3 }; await putL(L); }
            else { o.st = 'conflict'; o.pi = s.payment_intent; o.log.push({ at: now(), ev: 'conflict' }); await putO(o); await alog(0, 'conflict', { oid }); await note(o.buyer, 'There was a problem with your purchase of {0}. The team will refund you.', [o.item]); return 'conflito'; } }
        }
        else if (o.st !== 'pending' && !(L && (L.st === 'active' || (L.st === 'reserved' && L.res === o.id)))) {   // pagou depois de expirar e o item já foi para outro: o admin reembolsa
          o.st = 'conflict'; o.pi = s.payment_intent; o.log.push({ at: now(), ev: 'conflict' }); await putO(o); await alog(0, 'conflict', { oid }); await note(o.buyer, 'There was a problem with your purchase of {0}. The team will refund you.', [o.item]); return 'conflito'; }
        o.st = 'paid'; o.pi = s.payment_intent; o.paidAt = now(); o.log.push({ at: now(), ev: 'paid', sid: s.id }); await putO(o);
      }
      return finish(o);
    });
  }
  /* confere direto no Stripe se o pedido foi pago (o item é entregue mesmo se o webhook não chegar) */
  const VCHK = new Map();
  async function verifyOrder(o, gap) {
    if (!o || o.st !== 'pending' || !o.sid || !KEY) return o && o.st; if (now() - (VCHK.get(o.id) || 0) < (gap || 8000)) return o.st; VCHK.set(o.id, now());
    try { const s = await stripe('GET', '/v1/checkout/sessions/' + o.sid, null, o.acct);
      if (s.status === 'complete' && s.payment_status === 'paid') { const r = await paid(s); log('[mercado] pago (conferido no Stripe)', o.id, r); } } catch (e) { console.error('[mercado conferir]', o.id, e.message); }
    return (C.o.get(o.id) || o).st;
  }
  const orderByPi = pi => { let best = null; if (pi) for (const o of C.o.values()) if (o.pi === pi && (!best || o.at > best.at)) best = o; return best; };
  async function onEvent(ev) {
    await load(); const o = (ev.data && ev.data.object) || {}, md = o.metadata || {};
    if ((ev.type === 'checkout.session.completed' || ev.type === 'checkout.session.async_payment_succeeded') && md.mkt_order) {
      if (o.payment_status === 'paid') return paid(o);
      return lockK('o:' + md.mkt_order, async () => {   // Pix: o comprador gerou o código e o pagamento ainda vai cair -> segura a reserva por até 24 h
        const od = C.o.get(md.mkt_order); if (!od || od.st !== 'pending') return 'nada';
        od.async = 1; od.exp = now() + 3 * 24 * 3600e3; od.log.push({ at: now(), ev: 'awaiting_async' }); await putO(od);
        await lockK('l:' + od.lid, async () => { const L = C.l.get(od.lid); if (L && L.st === 'reserved' && L.res === od.id) { L.resUntil = od.exp; await putL(L); } });
        return 'aguardando Pix'; });
    }
    if ((ev.type === 'checkout.session.expired' || ev.type === 'checkout.session.async_payment_failed') && md.mkt_order) { const od = C.o.get(md.mkt_order); return od ? release(od, ev.type.endsWith('failed') ? 'failed' : 'expired') : 'sem pedido'; }
    if (ev.type === 'charge.refunded' || ev.type === 'charge.dispute.created' || ev.type === 'charge.dispute.closed') {
      const od = orderByPi(o.payment_intent); if (!od) return 'não é do mercado';
      return lockK('o:' + od.id, async () => {
        if (ev.type === 'charge.refunded') { if (o.amount_refunded >= od.amount) od.st = 'refunded'; od.refunded = o.amount_refunded; od.log.push({ at: now(), ev: 'refunded', amount: o.amount_refunded }); if (od.pay && od.pay.st !== 'sent') od.pay.st = 'cancelled'; }
        else if (ev.type === 'charge.dispute.created' && od.pay && od.pay.st !== 'sent') { od.pay.st = 'frozen'; }
        else if (ev.type === 'charge.dispute.created') { od.st = 'disputed'; od.log.push({ at: now(), ev: 'dispute', reason: o.reason }); const S = C.s.get(od.seller) || {}; S.disputes = (S.disputes | 0) + 1; await putS(od.seller, S); }
        else od.log.push({ at: now(), ev: 'dispute_closed', status: o.status });
        od.review = true; await putO(od); await alog(0, ev.type, { oid: od.id });   // o item NÃO é tirado do comprador automaticamente: o admin confere o estado do item
        if (ev.type !== 'charge.dispute.closed') await note(od.seller, ev.type === 'charge.refunded' ? 'The sale of {0} was refunded to the buyer.' : 'The buyer opened a dispute for {0}.', [od.item]);
        return od.st; });
    }
    if (ev.type === 'account.updated') { for (const [acc, S] of C.s) if (S.acct === o.id) { S.chk = 0; await refreshSeller(acc, true); return 'conta atualizada'; } return 'conta desconhecida'; }
    if (ev.type === 'payout.paid' && ev.account) { for (const [acc, S] of C.s) if (S.acct === ev.account) { await note(acc, 'Stripe sent {0} to your bank account.', [((o.amount | 0) / 100).toFixed(2) + ' ' + String(o.currency || '').toUpperCase()], ['🏦 Repasse do Mercado MuOnlineClaude', 'O Stripe enviou ' + ((o.amount | 0) / 100).toFixed(2) + ' ' + String(o.currency || '').toUpperCase() + ' para a sua conta bancária.']); return 'repasse'; } }
    return 'ignorado';
  }
  function sigOk(secret, raw, header) {
    if (!secret || typeof header !== 'string') return false;
    const parts = header.split(',').map(x => x.trim().split('=')), t = (parts.find(p => p[0] === 't') || [])[1], v1 = parts.filter(p => p[0] === 'v1').map(p => p[1]);
    if (!t || !v1.length || Math.abs(Date.now() / 1000 - +t) > 300) return false;
    const exp = crypto.createHmac('sha256', secret).update(Buffer.concat([Buffer.from(t + '.'), raw])).digest('hex');
    return v1.some(x => x.length === exp.length && crypto.timingSafeEqual(Buffer.from(x), Buffer.from(exp)));
  }
  async function webhook(req, res) {   // um só endereço para a loja e o mercado (+ os eventos de contas conectadas)
    try {
      const raw = await new Promise((ok, bad) => { let n = 0; const ch = []; req.on('data', d => { n += d.length; if (n > 256 * 1024) { bad(new Error('grande')); req.destroy(); } else ch.push(d); }); req.on('end', () => ok(Buffer.concat(ch))); req.on('error', bad); });
      const sig = req.headers['stripe-signature'];
      if (!sigOk(WHSEC, raw, sig) && !sigOk(CWH, raw, sig)) { sendJson(res, 400, { error: 'assinatura' }); return; }
      const ev = JSON.parse(raw.toString()), o = (ev.data && ev.data.object) || {}, md = o.metadata || {}, ty = String(ev.type || '');
      if (md.mkt_pre && (ty === 'checkout.session.completed' || ty === 'checkout.session.async_payment_succeeded')) { await load(); const r = await prePaid(o); log('[mercado comissão anúncio]', ty, o.id, r); }
      else if (md.mkt_pre) { /* outros eventos da comissão do anúncio */ }
      else if (md.mkt_fee && (ty === 'checkout.session.completed' || ty === 'checkout.session.async_payment_succeeded')) { await load(); const r = await feePaid(o); log('[mercado comissão]', ty, o.id, r); }
      else if (md.mkt_fee) { /* outros eventos da cobrança de comissão: nada a fazer */ }
      else if (md.mkt_order || ty.startsWith('charge.') || ty === 'account.updated' || ty === 'payout.paid') { const r = await onEvent(ev); log('[mercado]', ty, o.id, r); }
      else if ((ty === 'checkout.session.completed' || ty === 'checkout.session.async_payment_succeeded') && o.payment_status === 'paid') { const r = await SHOP.deliver(o); log('[loja]', ty, o.id, r); }
      sendJson(res, 200, { received: true });
    } catch (e) { console.error('[webhook]', e.message); sendJson(res, 500, { error: 'server' }); }   // 500 = o Stripe tenta de novo
  }
  /* ---------- painel do vendedor / comprador ---------- */
  API['POST /api/mkt/me'] = async b => {
    const c = await load(), t = verify(b.token); if (!t) return [401, { error: 'auth' }]; const a = await DB.accountById(t.a); if (!a) return [401, { error: 'auth' }];
    await feeCheck(t.a); await preCheck(t.a); const S = await refreshSeller(t.a), mine = [...c.l.values()].filter(l => l.seller === t.a).sort((x, y) => y.at - x.at);
    const sales = [...c.o.values()].filter(o => o.seller === t.a && o.st !== 'cancelled' && o.st !== 'expired' && o.st !== 'failed').sort((x, y) => y.at - x.at);
    const buys = [...c.o.values()].filter(o => o.buyer === t.a).sort((x, y) => y.at - x.at).slice(0, 50);
    const ov = o => ({ id: o.id, lid: o.lid, item: o.item, amount: o.amount, cur: o.cur, fee: o.fee, net: o.net, feeDue: o.billed ? o.feeDue | 0 : 0, feePre: o.feePre ? 1 : 0, st: o.st, at: o.at, paidAt: o.paidAt || 0, bname: o.bname, sname: o.sname, pay: o.pay ? o.pay.st : '' });
    const tot = {}; for (const o of sales) if (['delivered', 'paid'].includes(o.st)) { const T = tot[o.cur] = tot[o.cur] || { gross: 0, fee: 0, net: 0, n: 0 }; T.gross += o.amount; T.fee += o.fee; T.net += o.net; T.n++; }
    let payouts = null; if (S.acct && S.ready && KEY) { try { if (!S.po || now() - S.po.t > 60000) { const p = await stripe('GET', '/v1/payouts?limit=20', null, S.acct); S.po = { t: now(), list: (p.data || []).map(x => ({ amount: x.amount, cur: x.currency, st: x.status, at: (x.arrival_date || 0) * 1000 })) }; C.s.set(t.a, S); } payouts = S.po.list; } catch (e) { payouts = null; } }
    const notes = (await DB.kvGet('mkt:note:' + t.a)) || []; C.gn.delete(t.a);
    const boxes = []; for (const r of await DB.charsOf(t.a)) if (c.box.has(r.id)) boxes.push(r.id);
    const held = {}, sent = []; for (const o of sales) if (o.mode === 'hold' && o.pay) { if (['held', 'error'].includes(o.pay.st)) held[o.cur] = (held[o.cur] | 0) + o.net; else if (o.pay.st === 'sent') sent.push({ id: o.id, item: o.item, amount: o.pay.amount, cur: o.pay.cur, at: o.pay.at }); }
    return { user: a.username, owner: await isOwner(t.a), seller: { acct: !!S.acct, ready: !!S.ready, pay: S.pay !== false, wait: [...c.l.values()].filter(l => l.seller === t.a && l.st === 'wait').length, det: !!S.det, owe: S.owe || {}, feePaid: S.feePaid || {}, pre: needPre(S), nofee: feeRefused(S), minPay: Object.fromEntries(CURS.map(k => [k, minPlat(k)])), off: owing(S), suspWhy: S.suspWhy || '', oweMax: c.cfg.feeBill !== false && c.cfg.oweMax > 0 ? Math.max(c.cfg.oweMax | 0, minPlat('brl')) : 0, oweLim: c.cfg.feeBill !== false && c.cfg.oweMax > 0 ? Object.fromEntries(CURS.map(k => [k, Math.max(c.cfg.oweMax | 0, minPlat(k))])) : {}, suspDays: c.cfg.suspDays | 0, oweAt: S.oweAt || 0, due: S.due | 0, country: S.country || '', susp: !!S.susp, sales: S.sales | 0, hold: S.hold || '', held, sent },
      listings: mine.map(l => Object.assign(pubL(l, true), { reservedUntil: l.st === 'reserved' ? l.resUntil : 0 })), sales: sales.map(ov), buys: buys.map(ov), tot, payouts, notes: notes.slice(0, 30), boxes };
  };
  /* ---------- denúncias ---------- */
  API['POST /api/mkt/report'] = async (b, req) => {
    if (limited('mktrep:' + ipOf(req), 20)) return [429, { error: 'rate' }];
    const c = await load(), t = verify(b.token); if (!t) return [401, { error: 'auth' }];
    const L = b.id ? c.l.get(String(b.id)) : null, seller = L ? L.seller : +b.seller || 0; if (!seller) return [400, { error: 'target' }];
    const reason = clean(b.reason).slice(0, 400); if (reason.length < 5) return [400, { error: 'reason' }];
    const rid = await nextId('r'); await DB.kvSet('mkt:rep:' + rid, { id: rid, by: t.a, lid: L ? L.id : '', seller, reason, at: now(), st: 'open' }); DB.log('mkt_report', { rid, by: t.a, seller });
    return { ok: true };
  };
  /* ---------- painel do administrador (só o dono; tudo fica registrado) ---------- */
  API['POST /api/mkt/admin'] = async b => {
    const c = await load(), t = verify(b.token); if (!t) return [401, { error: 'auth' }]; if (!(await isOwner(t.a))) return [403, { error: 'owner' }];
    const act = String(b.act || 'state');
    if (act === 'cfg') { const g = c.cfg; if (b.on !== undefined) g.on = !!b.on; if (b.fee !== undefined) g.fee = Math.max(0, Math.min(50, +b.fee || 0)); if (b.min !== undefined) g.min = Math.max(100, Math.round(+b.min) || 200);
      if (b.max !== undefined) g.max = Math.max(g.min, Math.round(+b.max) || 200000); if (b.pix !== undefined) g.pix = !!b.pix; if (b.minLvl !== undefined) g.minLvl = Math.max(1, Math.min(1000, b.minLvl | 0)); if (b.holdOn !== undefined) g.holdOn = !!b.holdOn; if (b.nofee !== undefined) g.nofee = !!b.nofee; if (b.feeBill !== undefined) g.feeBill = !!b.feeBill; if (b.prepay !== undefined) g.prepay = !!b.prepay; if (b.suspDays !== undefined) g.suspDays = Math.max(0, Math.min(90, b.suspDays | 0)); if (b.oweMax !== undefined) g.oweMax = Math.max(0, Math.round(+b.oweMax) || 0);
      if (Array.isArray(b.countries)) { g.countries = b.countries.map(x => String(x).toUpperCase()).filter(x => /^[A-Z]{2}$/.test(x)); g.cv2 = 1; }
      await DB.kvSet('mkt:cfg', g); await alog(t.a, 'cfg', g); }
    else if (act === 'feetest') {   // teste do dono: pagamento real de comissão no valor mínimo (R$ 3,40) para a própria conta; vira crédito de comissão
      try { const ss = await feeSession(t.a, 'brl', minPlat('brl')); await alog(t.a, 'feetest', { sid: ss.id, amt: minPlat('brl') }); return { url: ss.url, amt: minPlat('brl') }; } catch (e) { console.error('[mercado teste comissão]', e.message); return [502, { error: 'stripe', msg: e.message.slice(0, 200) }]; } }
    else if (act === 'remove') { const r = await lockK('l:' + b.id, async () => { const L = c.l.get(String(b.id || '')); if (!L || !['active', 'reserved'].includes(L.st)) return false; if ((L.st === 'reserved' && L.resUntil > now()) || (L.unit && liveResv(L) > 0)) return 'reserved'; L.st = 'removed'; L.res = null; await giveBack(L, 'admin'); await putL(L); return true; });
      if (r === 'reserved') return [409, { error: 'reserved' }]; if (!r) return [404, { error: 'gone' }]; await alog(t.a, 'remove', { id: b.id, reason: clean(b.reason).slice(0, 200) }); }
    else if (act === 'suspend') { const acc = +b.acc || 0; if (!acc) return [400, { error: 'acc' }]; const S = c.s.get(acc) || {}; S.susp = !!b.on; S.suspWhy = clean(b.reason).slice(0, 200); await putS(acc, S);
      if (S.susp) for (const L of c.l.values()) if (L.seller === acc && L.st === 'active') await lockK('l:' + L.id, async () => { if (L.st !== 'active') return; L.st = 'removed'; await giveBack(L, 'suspended'); await putL(L); });
      await alog(t.a, S.susp ? 'suspend' : 'unsuspend', { acc, reason: S.suspWhy }); }
    else if (act === 'report') { const R = await DB.kvGet('mkt:rep:' + String(b.rid || '')); if (!R) return [404, { error: 'report' }]; R.st = b.st === 'open' ? 'open' : 'closed'; R.note = clean(b.note).slice(0, 300); R.by2 = t.a; await DB.kvSet('mkt:rep:' + R.id, R); await alog(t.a, 'report', { rid: R.id, st: R.st, note: R.note }); }
    else if (act === 'order') { const o = c.o.get(String(b.oid || '')); if (!o) return [404, { error: 'order' }]; o.review = !!b.review; o.log.push({ at: now(), ev: 'admin_note', note: clean(b.note).slice(0, 300), by: t.a }); await putO(o); await alog(t.a, 'order', { oid: o.id, note: clean(b.note).slice(0, 300) }); }
    else if (act === 'payheld') { const acc = +b.acc || 0; const n = acc ? await payHeld(acc) : 0; await alog(t.a, 'payheld', { acc, n }); }
    else if (act === 'retry') { const o = c.o.get(String(b.oid || '')); if (!o) return [404, { error: 'order' }]; if (o.st !== 'paid' && o.st !== 'paid_nochar') return [409, { error: 'state' }]; o.st = 'paid'; const r = await lockK('o:' + o.id, () => finish(o)); await alog(t.a, 'retry', { oid: o.id, r }); }
    const reps = (await DB.kvList('mkt:rep:')).map(r => r.data).filter(Boolean).sort((x, y) => y.at - x.at).slice(0, 100);
    const orders = [...c.o.values()].sort((x, y) => y.at - x.at);
    const st = {}; for (const o of orders) st[o.st] = (st[o.st] | 0) + 1;
    const fees = {}; for (const o of orders) if (o.st === 'delivered') fees[o.cur] = (fees[o.cur] | 0) + o.fee;
    const held = {}; let heldN = 0; for (const o of orders) if (o.mode === 'hold' && o.pay && ['held', 'error', 'frozen'].includes(o.pay.st)) { held[o.cur] = (held[o.cur] | 0) + o.net; heldN++; }
    return { cfg: c.cfg, test: TEST, keys: !!(KEY && WHSEC), keyType: KEY.slice(0, 8), marketKey: !!process.env.STRIPE_MARKET_KEY, lastErr: c.cfg.lastErr || null, connectHook: !!CWH, stats: { listings: c.l.size, active: [...c.l.values()].filter(l => l.st === 'active').length, orders: st, fees, held, heldN },
      orders: orders.slice(0, 100).map(o => ({ id: o.id, lid: o.lid, item: o.item, amount: o.amount, cur: o.cur, fee: o.fee, st: o.st, mode: o.mode || 'direct', pay: o.pay ? o.pay.st : '', at: o.at, buyer: o.buyer, bname: o.bname, seller: o.seller, sname: o.sname, review: !!o.review, log: o.log.slice(-6) })),
      listings: [...c.l.values()].filter(l => l.st === 'active' || l.st === 'reserved').sort((x, y) => y.at - x.at).slice(0, 200).map(l => pubL(l)),
      sellers: [...c.s.entries()].map(([acc, S]) => ({ acc, acct: S.acct ? S.acct.slice(0, 8) + '…' : '', ready: !!S.ready, susp: !!S.susp, sales: S.sales | 0, disputes: S.disputes | 0, country: S.country || S.hold || '', hold: S.hold || '', owe: S.owe || {}, feePaid: S.feePaid || {}, link: Object.values(S.owe || {}).some(v => (v | 0) > 0) ? feeLink(acc) : '' })),
      reports: reps, alog: ((await DB.kvGet('mkt:alog')) || []).slice(0, 60) };
  };
  /* ---------- manutenção: reservas vencidas e entregas interrompidas (também depois de reiniciar) ---------- */
  async function sweep() {
    try { await load(); await feeSuspend();
      for (const o of [...C.o.values()]) if (o.st === 'delivered' && o.feeWaived > 0 && !o.billed && !o.feePre && C.cfg.feeBill !== false) { o.feeBill = 1; await billFee(o); DB.log('mkt_fee_reconcile', { oid: o.id, seller: o.seller, fee: o.feeWaived }); }   // conferência automática: toda venda entregue sem comissão descontada vira comissão a pagar
      for (const L of [...C.l.values()]) if (L.st === 'prepay' && L.pre && !L.pre.paid && L.pre.amt < minPlat(L.cur)) await lockK('l:' + L.id, () => preTooSmall(L));
      for (const L of [...C.l.values()]) if (L.st === 'prepay' && L.pre && !L.pre.paid && now() - (L.pre.at0 || L.at) > 24 * 3600e3) await lockK('l:' + L.id, async () => { if (L.st !== 'prepay' || L.pre.paid) return; L.st = 'cancelled'; await giveBack(L, 'prepay_timeout'); await putL(L); await note(L.seller, 'Listing cancelled: the listing fee was not paid within 24 hours. The item went back to your hero.'); });
      for (const [acc, S] of [...C.s.entries()]) if (S.acct && !S.ready && !S.susp && now() - (S.chk || 0) > 10 * 60000) { await refreshSeller(acc, true); if ((C.s.get(acc) || {}).ready) continue; }   // cadastro no Stripe terminou sem o vendedor voltar à página: libera e publica os anúncios
      for (const o of [...C.o.values()]) {
        if (o.st === 'pending' && o.sid && now() - o.at > 45000 && now() < o.exp + 5 * 60000) { if ((await verifyOrder(o, 90000)) !== 'pending') continue; }
        if (o.st === 'paid') { await lockK('o:' + o.id, () => C.o.get(o.id).st === 'paid' ? finish(o) : null); continue; }
        if (o.st !== 'pending' || now() < o.exp + 5 * 60000) continue;
        if (o.sid && KEY) { try { const s = await stripe('GET', '/v1/checkout/sessions/' + o.sid, null, o.acct); if (s.status === 'complete' && s.payment_status === 'paid') { await paid(s); continue; }
          if (s.status === 'open' && now() < o.exp + 30 * 60000) continue; if (s.status === 'complete' && now() < o.exp + 3 * 24 * 3600e3) continue; } catch (e) { if (now() < o.exp + 30 * 60000) continue; } }
        await release(o, 'expired');
      }
      const due = new Set(); for (const o of C.o.values()) if (o.mode === 'hold' && o.st === 'delivered' && o.pay && (o.pay.st === 'held' || (o.pay.st === 'error' && now() - (o.pay.last || 0) > 10 * 60000 && (o.pay.tries | 0) < 50))) due.add(o.seller);
      for (const acc of due) { const S = C.s.get(acc); if (S && S.acct) { if (!S.ready && now() - (S.chk || 0) > 600000) await refreshSeller(acc, true); if ((C.s.get(acc) || {}).ready) await payHeld(acc); } }
    } catch (e) { console.error('[mercado sweep]', e.message); }
  }
  setTimeout(() => { sweep(); setInterval(sweep, 60000); }, 15000);
  return { webhook, imgUpload, img, sweep, load, payLink };
})();

/* ---- drop RARÍSSIMO (itens rr_* de mu-data.js) ----
   Quem sorteia é o SERVIDOR, nunca o navegador: esses itens valem dinheiro real no Mercado dos Jogadores.
   - Só sorteia enquanto o herói está caçando (ganhou EXP/nível desde o último salvamento), no máximo 2 minutos por salvamento.
   - Chance por hora de caça: conta free 1%, VIP Platinum 2%, VIP Gold 3% (mu-data.js; dá para mudar com RARE_PCT_FREE / RARE_PCT_PLAT / RARE_PCT_GOLD).
   - No máximo RARE_DROP_DAY itens por herói a cada 24 horas (padrão 1).
   - O item entra no inventário que o jogo está mandando E na cópia do banco antes do anti-hack olhar (por isso é "conhecido");
     qualquer item raríssimo que apareça de outro jeito é apagado pelo anti-hack.
   - Inventário cheio: o item fica guardado (kv "murare:<herói>") e entra quando abrir espaço. */
(() => {
  const D = MUD, INV = D.CFG.INV;
  const DAYCAP = () => Math.max(1, Math.min(1, +process.env.RARE_DROP_DAY || 1)); // HARD: no máximo 1 item raríssimo por herói/24h
  const PCT = tier => { const caps = { gold: .22, pm: .20, plat: .18, free: .15 }; const e = tier === 'gold' ? process.env.RARE_PCT_GOLD : tier === 'pm' ? process.env.RARE_PCT_PM : tier === 'plat' ? process.env.RARE_PCT_PLAT : process.env.RARE_PCT_FREE; // % máximo por hora de caça, inclusive se houver variável antiga no Render
    const d = tier && D.VIP_TIERS[tier] ? D.VIP_TIERS[tier].rarePct : D.CFG.RARE_PCT_FREE; const requested = e !== undefined && e !== '' ? +e : +d || 0; return Math.max(0, Math.min(caps[tier] ?? caps.free, requested)); };
  const prog = (a, b) => (b.resets | 0) > (a.resets | 0) || ((b.resets | 0) === (a.resets | 0) && ((b.level | 0) > (a.level | 0) || ((b.level | 0) === (a.level | 0) && (+b.exp || 0) > (+a.exp || 0))));
  const slot = inv => { let i = inv.findIndex((x, j) => j < INV && !x); if (i < 0 && inv.length < INV) i = inv.length; return i; };
  const oSave = API['POST /api/mu/save'];
  API['POST /api/mu/save'] = async (b, req) => {
    let got = null, id = 0;
    try {
      const t = verify(b && b.token); id = +(b && b.char) || 0; const row = t && id ? await DB.charById(id) : null;
      if (row && row.account_id === t.a && b.sv && typeof b.sv === 'object' && Array.isArray(b.sv.inv)) {
        const prev = await DB.kvGet('mu:' + id);
        if (prev && D.CLASSES[prev.cls]) {
          const k = 'murare:' + id, st = (await DB.kvGet(k)) || {}; let dirty = false;
          st.pend = Array.isArray(st.pend) ? st.pend : []; st.log = (Array.isArray(st.log) ? st.log : []).filter(x => x > Date.now() - 864e5);
          const dt = Math.min(2, Math.max(0, (Date.now() - (+prev.t || Date.now())) / 60000));
          if (dt > 0 && prog(prev, b.sv) && st.log.length < DAYCAP()) {
            const v = MU.vipOf ? await MU.vipOf(row.account_id) : { tier: '' }, q = PCT(v.tier) / 100;   // free 1% / Platinum 2% / Gold 3% por hora de caça
            const p = q >= 1 ? 1 : 1 - Math.pow(1 - q, dt / 60);
            if (Math.random() < p) { const it = D.rareRoll(prev.cls);
              if (it) { st.pend.push(it); st.log.push(Date.now()); dirty = true; DB.log('mu_rare', { char: id, acc: row.account_id, b: it.b, r: it.r });
                const nm = D.BASES[it.b].name; if (MU.announce) MU.announce('💎 ' + (prev.name || '?') + ' found an ultra-rare item: ' + nm + '!', '💎 {0} found an ultra-rare item: {1}!', [prev.name || '?', nm]); } }
          }
          if (st.pend.length) {
            prev.inv = Array.isArray(prev.inv) ? prev.inv : []; const left = [];
            for (const it of st.pend) { const i = slot(b.sv.inv), pi = slot(prev.inv); if (i < 0 || pi < 0) { left.push(it); continue; }
              b.sv.inv[i] = it; prev.inv[pi] = it; (got = got || []).push(it); }
            if (got) await DB.kvSet('mu:' + id, prev);
            if (left.length !== st.pend.length) dirty = true; st.pend = left;
          }
          if (dirty) await DB.kvSet(k, st);
        }
      }
    } catch (e) { console.error('[raro]', e.message); got = null; }
    const r = await oSave(b, req);
    if (got) { try { const ok = !Array.isArray(r) || r[0] < 300, j = Array.isArray(r) ? r[1] : r;
      if (!ok) {   // salvamento recusado (ex.: herói aberto em outra aba): o item volta para a fila e sai da cópia do banco
        const U = new Set(got.map(x => x.u)), cur = await DB.kvGet('mu:' + id);
        if (cur && Array.isArray(cur.inv)) { cur.inv = cur.inv.map(x => x && U.has(x.u) ? null : x); await DB.kvSet('mu:' + id, cur); }
        const k = 'murare:' + id, st = (await DB.kvGet(k)) || {}; st.pend = (Array.isArray(st.pend) ? st.pend : []).filter(x => !U.has(x.u)).concat(got); await DB.kvSet(k, st); got = null; }
      if (ok && j && typeof j === 'object') { const after = await DB.kvGet('mu:' + id); if (after) { j.sv = await muOutSv(id, after); j._inj = 1; } j.rareGot = got.map(x => ({ b: x.b, r: x.r | 0, p: x.p | 0, o: x.o })); } } catch (e) { console.error('[raro pos]', e.message); } }
    return r;
  };
  API['POST /api/mu/rarestats'] = async (b, req) => {   // painel do dono: quantos raríssimos já caíram
    const [adm, err] = await admAuth(b, req); if (err) return err;
    const rows = await DB.kvList('murare:'); let n = 0, pend = 0; for (const r of rows) { n += ((r.data && r.data.log) || []).length; pend += ((r.data && r.data.pend) || []).length; }
    return { pctPerHour: { free: PCT(''), plat: PCT('plat'), gold: PCT('gold') }, perDay: DAYCAP(), last24h: n, waiting: pend, items: D.RARE_IDS.length };
  };
})();
/* ===================== BAÚ (armazém da conta): proteção + recuperação =====================
   O que sumia: o baú é da CONTA, mas cada aba/herói mandava a SUA cópia inteira e ela substituía a do servidor.
   Uma cópia velha (outra aba, outro herói da conta, jogo aberto durante uma atualização, resposta atrasada)
   apagava o que tinha sido guardado depois. E o anti-hack apagava item "novo" que aparecia direto no baú.
   Agora:
   - o jogo manda junto a lista do que ele achava que tinha no baú (wb). Se o baú do servidor mudou nesse meio
     tempo, o servidor JUNTA as duas versões (só sai do baú o que esta aba tirou; só entra o que esta aba colocou);
   - todo item que sai do baú sem ir para o herói fica registrado (log mu_ware_out) e há cópias do baú (muwarebak:<conta>);
   - itens que não cabem esperam numa fila (murestore:<conta>) e entram sozinhos quando abrir espaço;
   - recuperação automática (uma vez por conta): itens apagados pelo anti-hack, peças do set VIP que sumiram
     e os itens das versões antigas do jogo (2D e 3D) que nunca tinham passado para o MuOnlineClaude. */
(() => {
  const D = MUD, WAREN = D.CFG.WARE, INV = D.CFG.INV, B = D.BASES;
  const RV = 1;   // versão da recuperação automática
  const oSave = API['POST /api/mu/save'], oLoad = API['POST /api/mu/load'];
  const uids = w => (Array.isArray(w) ? w : []).filter(x => x && x.u).map(x => String(x.u));
  const slotSig = w => (Array.isArray(w) ? w : []).slice(0, WAREN).map(x => (x && x.u ? x.u + ':' + (x.q | 0) : '')).join(',');
  const pad = w => { const o = (Array.isArray(w) ? w : []).slice(0, WAREN); while (o.length < WAREN) o.push(null); return o; };
  const uidOk = u => /^[a-z0-9]{1,24}$/i.test(String(u || ''));

  /* junção de 3 versões: S = servidor, base = o que a aba tinha na última sincronização, C = o que a aba manda agora */
  function merge(S, base, C) {
    const out = Array(WAREN).fill(null), cU = new Set(uids(C)), over = [];
    const removed = new Set([...base].filter(u => !cU.has(u)));            // esta aba tirou do baú
    pad(S).forEach((x, i) => { if (x && x.u && !removed.has(String(x.u))) out[i] = x; });
    const pos = new Map(); out.forEach((x, i) => { if (x) pos.set(String(x.u), i); });
    pad(C).forEach((x, i) => { if (!x || !x.u) return; const u = String(x.u);
      if (pos.has(u)) { out[pos.get(u)] = x; return; }                       // mesmo item: vale a versão da aba (quantidade)
      if (base.has(u)) return;                                               // outra aba/herói já tirou este item: não volta (sem duplicar)
      if (!out[i]) { out[i] = x; pos.set(u, i); return; }                    // item novo colocado por esta aba
      const k = out.indexOf(null); if (k >= 0) { out[k] = x; pos.set(u, k); } else over.push(x); });
    return { out, over };
  }

  /* ---------- fila de itens a entregar no baú ---------- */
  const RK = a => 'murestore:' + a;
  async function accHolds(acc) {   // todos os uids que a conta tem (heróis, baú, fila)
    const have = new Set(uids(await DB.kvGet('muware:' + acc)));
    for (const c of await DB.charsOf(acc)) { const sv = await DB.kvGet('mu:' + c.id); if (!sv) continue;
      for (const x of [...(sv.inv || []), ...Object.values(sv.equip || {})]) if (x && x.u) have.add(String(x.u)); }
    return have;
  }
  const busy = new Set();
  async function deliver(acc) {   // põe na conta o que estiver na fila (até encher o baú); devolve quantos entraram
    if (busy.has(acc)) return 0; busy.add(acc);
    try {
      const st = await DB.kvGet(RK(acc)); if (!st || !Array.isArray(st.pend) || !st.pend.length) return 0;
      const ware = pad(await DB.kvGet('muware:' + acc)); if (ware.indexOf(null) < 0) return 0;   // baú cheio: espera abrir espaço
      const have = await accHolds(acc); let n = 0, own = null; const left = [];
      for (const it of st.pend) {
        if (!it || !B[it.b] || (it.u && have.has(String(it.u)))) continue;   // já está com a conta: não duplica
        const k = ware.indexOf(null); if (k < 0) { left.push(it); continue; }
        ware[k] = it; have.add(String(it.u)); n++;
        if (B[it.b].excl === 'shop') { own = own || (await DB.kvGet('muown:' + acc)) || {}; own[it.u] = 'ware'; }
      }
      if (n) { if (own) await DB.kvSet('muown:' + acc, own); await DB.kvSet('muware:' + acc, ware); }
      st.pend = left; st.got = (st.got | 0) + n; st.at = Date.now(); await DB.kvSet(RK(acc), st);
      if (n) DB.log('mu_restore_in', { acc, n, left: left.length });
      return n;
    } finally { busy.delete(acc); }
  }
  async function queue(acc, items, src) {
    if (!items.length) return 0;
    const st = (await DB.kvGet(RK(acc))) || { v: 0, pend: [], got: 0 }; st.pend = (st.pend || []).concat(items); st.src = Object.assign(st.src || {}, src || {});
    await DB.kvSet(RK(acc), st); return items.length;
  }
  const backup = async (acc, ware, why, ch) => { const k = 'muwarebak:' + acc, L = (await DB.kvGet(k)) || [];
    L.unshift({ at: Date.now(), why, ch, w: (ware || []).filter(Boolean) }); while (L.length > 40) L.pop(); await DB.kvSet(k, L); };

  /* ---------- salvar ---------- */
  API['POST /api/mu/save'] = async (b, req) => {
    let acc = 0, id = 0, before = null, merged = false;
    try {
      const t = verify(b && b.token), row = t && b && b.char ? await DB.charById(+b.char) : null;
      if (row && row.account_id === t.a && Array.isArray(b.ware)) {
        acc = row.account_id; id = row.id; before = pad(await DB.kvGet('muware:' + acc));
        if (Array.isArray(b.wb)) {
          const base = new Set(b.wb.filter(uidOk).map(String)), sU = uids(before);
          const same = sU.length === base.size && sU.every(u => base.has(u));
          if (!same) { const m = merge(before, base, b.ware); b.ware = m.out; merged = true; if (m.over.length) await queue(acc, m.over, { over: 1 }); }
        }
      }
    } catch (e) { console.error('[baú save pre]', e.message); }
    const r = await oSave(b, req);
    try {
      if (acc && before) {
        const ok = !Array.isArray(r) || r[0] < 300, j = Array.isArray(r) ? r[1] : r;
        if (ok) await deliver(acc).catch(() => 0);
        const after = pad(await DB.kvGet('muware:' + acc)), aU = new Set(uids(after));
        const lost = before.filter(x => x && x.u && !aU.has(String(x.u)));
        if (lost.length) {   // saiu do baú: foi para este herói? se não, registra (dá para devolver depois)
          const sv = (await DB.kvGet('mu:' + id)) || {}, hero = new Set(uids([...(sv.inv || []), ...Object.values(sv.equip || {})]));
          const gone = lost.filter(x => !hero.has(String(x.u)));
          if (gone.length) { DB.log('mu_ware_out', { acc, char: id, items: gone.slice(0, 60) }); await backup(acc, before, 'out', id); }
        }
        const bk = await DB.kvGet('muwarebak:' + acc);   // uma cópia por hora, mesmo sem perda
        if (!bk || !bk[0] || Date.now() - bk[0].at > 3600e3) await backup(acc, after, 'hour', id);
        if (ok && j && typeof j === 'object' && (merged || slotSig(b.ware) !== slotSig(after) || (j.ware && slotSig(j.ware) !== slotSig(after)))) j.ware = after;
        if (ok && j && typeof j === 'object') { const st = await DB.kvGet(RK(acc)); if (st && st.pend && st.pend.length) j.restLeft = st.pend.length; }
      }
    } catch (e) { console.error('[baú save pós]', e.message); }
    return r;
  };

  /* ---------- entrar no jogo: entrega o que estiver na fila antes de mandar o baú ---------- */
  API['POST /api/mu/load'] = async (b, req) => {
    let acc = 0, n = 0;
    try { const t = verify(b && b.token), row = t && b && b.char ? await DB.charById(+b.char) : null;
      if (row && row.account_id === t.a) { acc = row.account_id; await ensureScan(acc); n = await deliver(acc); } } catch (e) { console.error('[baú load]', e.message); }
    const r = await oLoad(b, req);
    try { const j = Array.isArray(r) ? r[1] : r;
      if (acc && j && typeof j === 'object' && !(Array.isArray(r) && r[0] >= 300)) {
        const st = await DB.kvGet(RK(acc)); if (n) j.restored = n; if (st && st.pend && st.pend.length) j.restLeft = st.pend.length;
        j.ware = pad(await DB.kvGet('muware:' + acc)); } } catch (e) {}
    return r;
  };

  /* ---------- recuperação automática (uma vez por conta) ---------- */
  const T2 = t => Math.max(0, Math.min(7, (t | 0) - 1));
  const capT = (cat, t) => { const L = D.CATS[cat] && D.CATS[cat].lvls; return L ? Math.min(t, L.length - 1) : Math.min(t, 7); };
  const lvlT = l => { let t = 0; D.TIER_LVL.forEach((v, i) => { if (v <= l) t = i; }); return t; };
  const WEAP = { dk: 'sword', mg: 'sword', dl: 'sword', dw: 'staff', elf: 'bow' };
  const SLOT2 = { arma: 'W', escudo: 'shield', elmo: 'helm', armadura: 'armor', calca: 'pants', luvas: 'gloves', botas: 'boots', anel: 'ring', colar: 'pendant', asas: 'wings', capa: 'cape' };
  const SLOT3 = { arma: 'W', escudo: 'shield', cabeca: 'helm', elmo: 'helm', peito: 'armor', armadura: 'armor', pernas: 'pants', calca: 'pants', maos: 'gloves', luvas: 'gloves', pes: 'boots', botas: 'boots', anel: 'ring', colar: 'pendant', amuleto: 'pendant', asas: 'wings', capa: 'cape' };
  function oldItem(kind, tier, cls, r, p) {
    let id = null;
    if (kind === 'W') { const c = WEAP[cls] || 'sword'; id = c + '_' + capT(c, tier); }
    else if (kind === 'wings') id = 'wings_' + (tier >= 4 ? 2 : tier >= 2 ? 1 : 0);
    else if (kind === 'cape') id = 'dlcape_' + (tier >= 4 ? 2 : tier >= 2 ? 1 : 0);
    else if (kind) id = kind + '_' + capT(kind, tier);
    if (!id || !B[id]) return null;
    const it = D.makeItem(id, Math.max(0, Math.min(6, r | 0)), Math.max(0, Math.min(15, p | 0))); return it;
  }
  let uidN = 0; const rid = (acc, tag) => ('rs' + Number(acc).toString(36) + tag + (++uidN).toString(36)).slice(0, 24);
  async function scanAccount(acc) {
    const items = [], src = { old2d: 0, old3d: 0, antihack: 0, vip: 0 }, add = (it, tag, k) => { if (!it) return; it.u = rid(acc, tag); items.push(it); src[k]++; };
    const chars = await DB.charsOf(acc), present = await accHolds(acc);
    // 1) versões antigas (2D e 3D): itens que nunca passaram para o jogo novo
    for (const c of chars) {
      const sv = await DB.kvGet('mu:' + c.id), cls = (sv && sv.cls) || 'dk', d = c.data || {};
      for (const x of [...(Array.isArray(d.inv) ? d.inv : []), ...Object.values(d.equip || {})]) {
        if (!x || typeof x !== 'object') continue; const kind = SLOT2[x.slot]; if (!kind) continue;
        const tier = T2(x.tier), plus = x.plus | 0, rare = !!x.rare;
        if (tier === 0 && !plus && !rare) continue;                          // equipamento inicial (não tinha valor)
        add(oldItem(kind, tier, cls, rare ? 2 : 0, plus), 'a', 'old2d');
      }
      const w = await DB.kvGet('wow:' + c.id);
      if (w) for (const x of [...(Array.isArray(w.inv) ? w.inv : []), ...Object.values(w.eq || {})]) {
        if (!x || typeof x !== 'object' || !x.slot) continue; const kind = SLOT3[x.slot]; if (!kind) continue;
        const lv = x.lvl | 0, rar = x.rar | 0; if (lv <= 1 && !rar) continue;
        add(oldItem(kind, lvlT(lv), cls, rar, 0), 'b', 'old3d');
      }
    }
    // 2) itens que o anti-hack apagou sem necessidade (baú, eventos, drops)
    for (const L of await cheatLogs()) {
      const d = L.data || {}; if (+d.acc !== +acc) continue;
      for (const w of d.what || []) { const s = String(w); let m;
        if ((m = s.match(/^(ware_new|excl|dropx|lvl|rate|opts):([a-z0-9_]+)$/))) { const b0 = B[m[2]]; if (!b0 || !b0.equip) continue; add(D.makeItem(m[2], b0.excl ? 4 : 2, 0), 'c', 'antihack'); }
        else if ((m = s.match(/^plus_new:([a-z0-9_]+)\+(\d+)$/))) { if (B[m[1]]) add(D.makeItem(m[1], 2, Math.min(15, +m[2])), 'c', 'antihack'); }
        else if ((m = s.match(/^jewels:([a-z]+)\+(\d+)$/))) { let q = +m[2]; while (q > 0 && B[m[1]]) { const n = Math.min(99, q); add(D.makeItem(m[1], 0, 0, n), 'c', 'antihack'); q -= n; } }
      }
    }
    // 3) peças do set VIP que sumiram (cada conta guarda quais sets ganhou)
    const vip = await DB.kvGet('muvip:' + acc);
    if (vip && vip.sets) {
      const counts = {}; for (const c of chars) { const sv = await DB.kvGet('mu:' + c.id); for (const x of [...((sv && sv.inv) || []), ...Object.values((sv && sv.equip) || {})]) if (x && x.b) counts[x.b] = (counts[x.b] | 0) + 1; }
      for (const x of (await DB.kvGet('muware:' + acc)) || []) if (x && x.b) counts[x.b] = (counts[x.b] | 0) + 1;
      for (const tier of Object.keys(vip.sets)) {
        const p = D.MU_SHOP.find(x => x.id === 'mu_vipset_' + tier); if (!p) continue; const need = {};
        for (const g of p.give) need[g.b] = (need[g.b] | 0) + 1;
        for (const bid in need) { let miss = need[bid] - (counts[bid] | 0); while (miss-- > 0) add(D.makeItem(bid, 6, 15), 'v', 'vip'); }
      }
    }
    return { items: items.filter(it => it && !present.has(String(it.u))), src };
  }
  const scanBusy = new Map();
  let cheatC = null, cheatAt = 0;   // registros do anti-hack: lidos uma vez por minuto (a varredura de todas as contas não relê tudo a cada conta)
  async function cheatLogs() { if (!cheatC || Date.now() - cheatAt > 60000) { cheatC = await DB.logsOf('mu_cheat'); cheatAt = Date.now(); } return cheatC; }
  async function ensureScan(acc) {
    const st = await DB.kvGet(RK(acc)); if (st && (st.v | 0) >= RV) return;
    if (scanBusy.has(acc)) return scanBusy.get(acc);
    const p = (async () => {
      const { items, src } = await scanAccount(acc);
      const cur = (await DB.kvGet(RK(acc))) || { pend: [], got: 0 }; if ((cur.v | 0) >= RV) return;
      cur.v = RV; cur.pend = (cur.pend || []).concat(items); cur.src = src; cur.scan = Date.now(); await DB.kvSet(RK(acc), cur);
      if (items.length) DB.log('mu_restore_scan', { acc, n: items.length, src });
    })().finally(() => scanBusy.delete(acc));
    scanBusy.set(acc, p); return p;
  }
  // varre todas as contas logo depois de ligar (em segundo plano, devagar)
  setTimeout(async () => { try { for (const a of await DB.allAccounts()) { await ensureScan(a.id).catch(e => console.error('[baú scan]', a.id, e.message)); await new Promise(r => setTimeout(r, 150)); } log('[baú] recuperação conferida em todas as contas'); } catch (e) { console.error('[baú scan]', e.message); } }, 20000);

  /* ---------- painel do dono ---------- */
  API['POST /api/mu/admware'] = async (b, req) => {   // {acc} -> cópias do baú, fila e itens que saíram
    const [adm, err] = await admAuth(b, req); if (err) return err; const acc = +b.acc || 0; if (!acc) return [400, { error: 'acc' }];
    const bak = (await DB.kvGet('muwarebak:' + acc)) || [], st = (await DB.kvGet(RK(acc))) || {};
    return { ware: pad(await DB.kvGet('muware:' + acc)).filter(Boolean).length, backups: bak.map((x, i) => ({ i, at: x.at, why: x.why, ch: x.ch, n: x.w.length })), pend: (st.pend || []).length, got: st.got | 0, src: st.src || {} };
  };
  API['POST /api/mu/admwarerestore'] = async (b, req) => {   // {acc, i} -> devolve os itens da cópia i que a conta não tem mais
    const [adm, err] = await admAuth(b, req); if (err) return err; const acc = +b.acc || 0, i = b.i | 0; if (!acc) return [400, { error: 'acc' }];
    const bak = (await DB.kvGet('muwarebak:' + acc)) || [], snap = bak[i]; if (!snap) return [404, { error: 'backup' }];
    const have = await accHolds(acc), st = (await DB.kvGet(RK(acc))) || { pend: [] }, inQ = new Set(uids(st.pend));
    const back = snap.w.filter(x => x && x.u && B[x.b] && !have.has(String(x.u)) && !inQ.has(String(x.u)));
    await queue(acc, back, { manual: 1 }); const n = await deliver(acc); DB.log('mu_admin_ware_restore', { acc, i, queued: back.length, now: n });
    return { ok: true, queued: back.length, delivered: n };
  };
})();
/* ===================== AMIZADE entre heróis (pedido, aceitar, recusar, remover) =====================
   kv "mufr:<heroi>" = { f:[ids], inc:[{id,at}], out:[{id,at}] }. Aviso em tempo real pelo WebSocket do jogo (/wsmu). */
(() => {
  const FK = id => 'mufr:' + id, MAXF = 100, MAXQ = 40;
  let chain = Promise.resolve(); const serial = fn => (chain = chain.then(fn, fn));   // um pedido de amizade de cada vez (sem corrida entre os dois lados)
  const get = async id => { const v = (await DB.kvGet(FK(id))) || {}; return { f: Array.isArray(v.f) ? v.f : [], inc: Array.isArray(v.inc) ? v.inc : [], out: Array.isArray(v.out) ? v.out : [] }; };
  const nameOf = async id => { const sv = await DB.kvGet('mu:' + id); return sv && sv.name ? String(sv.name) : null; };
  const push = (id, msg) => { const q = muRTPlayers.get(+id); if (q && q.ws) try { q.ws.send(msg); } catch (_) {} };
  const view = async A => { const one = async id => { const q = muRTPlayers.get(+id), sv = q ? null : await DB.kvGet('mu:' + id);
      return { id: +id, n: q ? q.name : (sv && sv.name) || '?', on: q ? 1 : 0, m: q ? q.map : '', l: q ? q.level : (sv && sv.level) | 0, c: q ? q.cls : (sv && sv.cls) || '' }; };
    return { friends: await Promise.all(A.f.map(one)), inc: await Promise.all(A.inc.map(x => one(x.id))), out: await Promise.all(A.out.map(x => one(x.id))) }; };
  const drop = (L, id) => L.filter(x => (typeof x === 'object' ? +x.id : +x) !== +id);
  API['POST /api/mu/friends'] = async (b, req) => {
    if (limited(ipOf(req), 60)) return [429, { error: 'rate' }];
    const t = verify(b && b.token); if (!t) return [401, { error: 'auth' }];
    const row = await DB.charById(+b.char); if (!row || row.account_id !== t.a) return [400, { error: 'char' }];
    const me = row.id, act = String(b.action || 'list'), tg = +b.target || 0;
    if (act === 'list') return { ok: true, ...(await view(await get(me))) };
    if (act === 'trade_note') { if (tg && tg !== me) push(tg, { t: 'tr_note', id: me, n: (await nameOf(me)) || '' }); return { ok: true }; }
    if (!tg || tg === me) return [400, { error: 'target' }];
    const tRow = await DB.charById(tg), tName = tRow ? await nameOf(tg) : null; if (!tName) return [404, { error: 'target' }];
    const myName = (await nameOf(me)) || '';
    return serial(async () => {
      const A = await get(me), T = await get(tg); let msg = 'ok';
      if (act === 'request') {
        if (A.f.includes(tg)) return [409, { error: 'already' }];
        if (A.inc.some(x => +x.id === tg)) {   // a outra pessoa já tinha pedido: vira amizade direto
          A.inc = drop(A.inc, tg); T.out = drop(T.out, me); A.f.push(tg); if (!T.f.includes(me)) T.f.push(me); msg = 'accepted'; push(tg, { t: 'fr_ok', id: me, n: myName });
        } else {
          if (A.out.some(x => +x.id === tg)) return [409, { error: 'pending' }];
          if (A.f.length >= MAXF) return [400, { error: 'full' }];
          A.out.push({ id: tg, at: Date.now() }); if (A.out.length > MAXQ) A.out = A.out.slice(-MAXQ);
          T.inc = drop(T.inc, me); T.inc.push({ id: me, at: Date.now() }); if (T.inc.length > MAXQ) T.inc = T.inc.slice(-MAXQ);
          push(tg, { t: 'fr_req', id: me, n: myName }); msg = 'sent';
        }
      } else if (act === 'accept') {
        if (!A.inc.some(x => +x.id === tg)) return [404, { error: 'no_request' }];
        A.inc = drop(A.inc, tg); T.out = drop(T.out, me); if (!A.f.includes(tg)) A.f.push(tg); if (!T.f.includes(me)) T.f.push(me);
        push(tg, { t: 'fr_ok', id: me, n: myName }); msg = 'accepted';
      } else if (act === 'decline') { A.inc = drop(A.inc, tg); T.out = drop(T.out, me); push(tg, { t: 'fr_no', id: me, n: myName }); msg = 'declined'; }
      else if (act === 'cancel') { A.out = drop(A.out, tg); T.inc = drop(T.inc, me); msg = 'cancelled'; }
      else if (act === 'remove') { A.f = A.f.filter(x => +x !== tg); T.f = T.f.filter(x => +x !== me); msg = 'removed'; }
      else return [400, { error: 'action' }];
      await DB.kvSet(FK(me), A); await DB.kvSet(FK(tg), T); DB.log('mu_friend', { me, tg, act });
      return { ok: true, msg, name: tName, ...(await view(A)) };
    });
  };
})();
/* ---------- nível: o limite por salvamento segue a EXP que dá para ganhar de verdade ----------
   O mu.js aceita no máximo +25 níveis (+40 por minuto) entre dois salvamentos. Depois dos resets, caçando monstros de nível
   800-975, cada morte dá dezenas de milhões de EXP e o herói sobe centenas de níveis em segundos: o servidor cortava o nível,
   devolvia o nível antigo para o jogo e o jogador via o nível subir e voltar (ex.: 199 -> 610 -> 227 -> 313 -> 255) e perdia a EXP.
   Aqui o servidor calcula quanta EXP o herói poderia ganhar nesse tempo (monstro mais forte que ele pode caçar x taxa do servidor
   x VIP x selo/anel/eventos x golpes em área x party) e, se o nível pedido cabe nessa conta, ajusta o ponto de partida antes
   do mu.js conferir. Nível acima do possível continua sendo cortado como antes. */
(() => {
  const D = MUD, CAP = D.CFG.LEVEL_CAP, RL = D.CFG.REBIRTH_LVL, RATE = Math.max(1, +process.env.MU_EXP_RATE || 5);
  const MP = []; let GTOP = 1;
  for (const id in D.MAPS) { const M = D.MAPS[id], top = Math.max(1, ...(M.spawns || []).map(s => s.lvl | 0)); MP.push([M.lvl || 1, top]); GTOP = Math.max(GTOP, top); }
  const monTop = (lvl, resets) => { if (resets > 0) return GTOP + 10; let t = 1; for (const [ml, top] of MP) if (ml <= lvl) t = Math.max(t, top); return t + 10; };
  const monExp = l => (l * l * .9 + l * 8 + 10);
  // EXP máxima possível em dtSec segundos: 8 mortes por segundo, cada uma com o monstro mais forte, x2 (anel/eventos), x1,5 selo, x1,5 party
  const budget = (dtSec, lvl, resets, vipMul) => monExp(monTop(lvl, resets)) * RATE * vipMul * 1.5 * 2 * 1.5 * 8 * (dtSec + 20);
  function reach(level, exp, E) { let l = Math.max(1, level | 0), e = Math.max(0, +exp || 0) + E; while (l < CAP && e >= D.expNeed(l)) { e -= D.expNeed(l); l++; } return l; }
  const oSave = API['POST /api/mu/save'];
  API['POST /api/mu/save'] = async (b, req) => {
    let id = 0, orig = null, wrote = null;
    try {
      const t = verify(b && b.token); id = +(b && b.char) || 0; const row = t && id ? await DB.charById(id) : null;
      const sv = b && b.sv;
      if (row && row.account_id === t.a && sv && typeof sv === 'object') {
        const prev = await DB.kvGet('mu:' + id);
        if (prev && D.CLASSES[prev.cls]) {
          const pl = prev.level | 0, pr = prev.resets | 0, now = Date.now();
          const dtMin = Math.min(600, Math.max(0, (now - (prev.t || now)) / 60000)), g = 25 + Math.ceil(dtMin * 40);
          let tier = ''; try { if (MU && MU.vipOf) tier = (await MU.vipOf(row.account_id)).tier; } catch (_) {}
          const vipMul = tier && D.VIP_TIERS[tier] ? D.VIP_TIERS[tier].exp : 1;
          const want = Math.min(CAP, Math.max(1, sv.level | 0)), wr = sv.resets | 0;
          let to = 0;
          if (pr > 0 && wr === pr && want > pl + g) {   // depois do 1º reset (caça em qualquer mapa): subiu mais do que o mu.js aceita, confere com a EXP possível
            const maxL = reach(pl, prev.exp, budget(dtMin * 60, pl + g, pr, vipMul));
            const ok = Math.min(want, maxL); if (ok - 25 > pl) to = ok - 25;
          } else if (pr > 0 && wr === pr + 1) {   // reset: precisa ter chegado ao nível de reset (o jogo reseta assim que chega)
            const need = Math.min(CAP, tier && D.VIP_TIERS[tier] ? D.VIP_TIERS[tier].resetLvl : RL);
            if (pl < need && reach(pl, prev.exp, budget(dtMin * 60, pl + g, pr, vipMul)) >= need) to = need;
          }
          if (to > pl) {
            orig = { level: prev.level, exp: prev.exp }; prev.level = to; prev.exp = 0; wrote = to;
            await DB.kvSet('mu:' + id, prev);
            const k = 'lvlfast:' + id, l0 = DB._lvlLog || (DB._lvlLog = new Map());
            if (now - (l0.get(k) || 0) > 3600e3) { l0.set(k, now); DB.log('mu_level_fast', { char: id, from: pl, to: want, resets: wr, sec: Math.round(dtMin * 60) }); }
          }
        }
      }
    } catch (e) { console.error('[nível]', e.message); }
    const r = await oSave(b, req);
    try {   // o salvamento não passou (outra aba, erro): volta o ponto de partida como estava
      const bad = Array.isArray(r) && r[0] >= 300;
      if (bad && orig && id) { const cur = await DB.kvGet('mu:' + id); if (cur && (cur.level | 0) === wrote) { cur.level = orig.level; cur.exp = orig.exp; await DB.kvSet('mu:' + id, cur); } }
    } catch (e) { console.error('[nível]', e.message); }
    return r;
  };
})();

/* ---------- painel do dono: DAR ITEM PARA UM JOGADOR (pelo nome do herói ou da conta) ----------
   POST /api/mu/admfind {token, q}  -> heróis cujo nome ou nome da conta contém q
   POST /api/mu/admgive {token, char, item, plus, rarity, qty, maxopt} -> item vai para a fila do herói (kv "muadmq:<herói>")
   POST /api/mu/admqueue {token, char[, cancel]} -> o que ainda está esperando (e cancelar)
   O item entra no INVENTÁRIO do herói no próximo salvamento (online: na hora, o jogo salva sozinho ao receber o aviso;
   offline: quando ele entrar). Entra na cópia do servidor junto, então o anti-hack já conhece o item; itens da loja
   ganham o registro no livro-razão. Inventário cheio: espera na fila e entra quando abrir espaço. Só o dono usa. */
(() => {
  const D = MUD, B = D.BASES, INV = D.CFG.INV, Q = id => 'muadmq:' + id;
  const slot = inv => { let i = inv.findIndex((x, j) => j < INV && !x); if (i < 0 && inv.length < INV) i = inv.length; return i; };
  const ping = id => { try { const p = muRTPlayers.get(id); if (p && p.ws) p.ws.send({ t: 'adm_give' }); } catch (_) {} };
  const view = it => ({ u: it.u, b: it.b, n: (B[it.b] || {}).name || it.b, r: it.r | 0, p: it.p | 0, q: it.q | 0, o: it.o ? 1 : 0 });
  API['POST /api/mu/admfind'] = async (b, req) => {
    const [adm, err] = await admAuth(b, req); if (err) return err;
    const q = String(b.q || '').trim().toLowerCase().slice(0, 30); if (q.length < 2) return [400, { error: 'q' }];
    const accs = new Map(); for (const a of await DB.allAccounts()) accs.set(+a.id, a);
    const hits = [];
    for (const c of await DB.allChars()) {
      const nm = String((c.data && c.data.name) || c.name || ''), a = accs.get(+c.account_id), un = a ? String(a.username || '') : '';
      if (!nm.toLowerCase().includes(q) && !un.toLowerCase().includes(q)) continue;
      const sv = await DB.kvGet('mu:' + c.id); if (!sv || !D.CLASSES[sv.cls]) continue;   // só heróis do MuOnlineClaude
      const exact = nm.toLowerCase() === q || un.toLowerCase() === q;
      hits.push({ id: c.id, name: sv.name || nm, user: un, acc: +c.account_id, cls: sv.cls, level: sv.level | 0, resets: sv.resets | 0, online: muRTPlayers.has(c.id), free: (sv.inv || []).slice(0, INV).filter(x => !x).length + Math.max(0, INV - (sv.inv || []).length), exact, t: +sv.t || 0 });
      if (hits.length >= 200) break;
    }
    hits.sort((x, y) => (y.exact - x.exact) || (y.online - x.online) || (y.t - x.t));
    return { list: hits.slice(0, 25).map(({ exact, t, ...h }) => h) };
  };
  API['POST /api/mu/admgive'] = async (b, req) => {
    const [adm, err] = await admAuth(b, req); if (err) return err;
    const id = +b.char || 0, sv = id ? await DB.kvGet('mu:' + id) : null; if (!sv) return [404, { error: 'char' }];
    const base = B[String(b.item || '')]; if (!base) return [400, { error: 'item' }];
    const r = Math.max(0, Math.min(6, b.rarity | 0)), p = Math.max(0, Math.min(15, b.plus | 0)), q = Math.max(1, Math.min(base.stack ? 99 : 1, b.qty | 0 || 1));
    const n = base.stack ? 1 : Math.max(1, Math.min(10, b.copies | 0 || 1));
    const box = (await DB.kvGet(Q(id))) || []; if (box.length + n > 60) return [400, { error: 'queue_full' }];
    const made = [];
    for (let k = 0; k < n; k++) { const it = D.makeItem(base.id, r, p, q); if (!it) return [400, { error: 'item' }];
      if (base.equip && b.maxopt) it.o = Object.assign({}, D.PREMIUM_OPTS);
      it.u = 'ad' + crypto.randomBytes(6).toString('hex'); box.push({ it, at: Date.now() }); made.push(it); }
    await DB.kvSet(Q(id), box);
    DB.log('mu_admgive', { by: adm.username, char: id, name: sv.name, items: made.map(view) }); ping(id);
    return { ok: true, name: sv.name, online: muRTPlayers.has(id), waiting: box.length, items: made.map(view) };
  };
  API['POST /api/mu/admqueue'] = async (b, req) => {
    const [adm, err] = await admAuth(b, req); if (err) return err;
    const id = +b.char || 0; let box = (await DB.kvGet(Q(id))) || [];
    if (b.cancel) { const n0 = box.length; box = box.filter(x => x.it.u !== String(b.cancel)); if (box.length !== n0) { await DB.kvSet(Q(id), box); DB.log('mu_admgive_cancel', { char: id, u: String(b.cancel) }); } }
    return { list: box.map(x => ({ ...view(x.it), at: x.at })) };
  };
  const oSave = API['POST /api/mu/save'];
  API['POST /api/mu/save'] = async (b, req) => {
    let got = null, id = 0, acc = 0;
    try {
      const t = verify(b && b.token); id = +(b && b.char) || 0; const row = t && id ? await DB.charById(id) : null;
      if (row && row.account_id === t.a && b.sv && typeof b.sv === 'object' && Array.isArray(b.sv.inv)) {
        const box = (await DB.kvGet(Q(id))) || [];
        if (box.length) { const prev = await DB.kvGet('mu:' + id);
          if (prev && D.CLASSES[prev.cls]) { acc = row.account_id; prev.inv = Array.isArray(prev.inv) ? prev.inv : []; const left = [], have = new Set();
            for (const it of [...b.sv.inv, ...prev.inv, ...Object.values(b.sv.equip || {})]) if (it && it.u) have.add(it.u);
            for (const x of box) { if (have.has(x.it.u)) continue;   // já entregue
              const i = slot(b.sv.inv), pi = slot(prev.inv); if (i < 0 || pi < 0) { left.push(x); continue; }
              b.sv.inv[i] = x.it; prev.inv[pi] = JSON.parse(JSON.stringify(x.it)); (got = got || []).push(x.it); }
            if (got) { await DB.kvSet('mu:' + id, prev);
              if (got.some(it => B[it.b] && B[it.b].excl === 'shop')) { const k = 'muown:' + acc, own = (await DB.kvGet(k)) || {}; for (const it of got) if (B[it.b].excl === 'shop') own[it.u] = 'c' + id; await DB.kvSet(k, own); } }
            if (left.length !== box.length) await DB.kvSet(Q(id), left);
          } }
      }
    } catch (e) { console.error('[adm item]', e.message); got = null; }
    const r = await oSave(b, req);
    if (got) { try { const ok = !Array.isArray(r) || r[0] < 300, j = Array.isArray(r) ? r[1] : r;
      if (!ok) {   // salvamento recusado: o item volta para a fila e sai da cópia do servidor
        const U = new Set(got.map(x => x.u)), cur = await DB.kvGet('mu:' + id);
        if (cur && Array.isArray(cur.inv)) { cur.inv = cur.inv.map(x => x && U.has(x.u) ? null : x); await DB.kvSet('mu:' + id, cur); }
        const box = (await DB.kvGet(Q(id))) || []; await DB.kvSet(Q(id), got.map(it => ({ it, at: Date.now() })).concat(box.filter(x => !U.has(x.it.u)))); got = null; }
      if (ok && j && typeof j === 'object') { const after = await DB.kvGet('mu:' + id); if (after) { j.sv = await muOutSv(id, after); j._inj = 1; } j.admGot = got.map(x => ({ b: x.b, r: x.r | 0, p: x.p | 0, q: x.q | 0, o: x.o })); DB.log('mu_admgive_done', { char: id, items: got.map(view) }); } } catch (e) { console.error('[adm item pos]', e.message); } }
    return r;
  };
})();

/* ===== CUPONS (API + painel do dono + aviso no chat) e VIP FREE de 3 dias ===== */
(() => {
  const D = MUD, INV = D.CFG.INV;
  const isOwnerTok = async token => { const t = verify(token); if (!t) return null; const a = await DB.accountById(t.a); return a && String(a.ulow || a.username || '').toLowerCase() === ADM_USER && String(a.email || '').toLowerCase() === ADM_MAIL ? a : null; };
  API['POST /api/coupon'] = async (b, req) => {   // o jogador digita o cupom e toca em Aplicar
    if (limited('cp:' + ipOf(req), 30)) return [429, { error: 'rate' }];
    const c = await couponGet(b && b.code); if (!c) return [404, { error: 'coupon' }]; return { ok: true, code: c.code, pct: c.pct };
  };
  API['POST /api/mu/coupons'] = async (b) => {   // painel do dono (murilonv)
    const a = await isOwnerTok(b && b.token); if (!a) return [403, { error: 'owner' }];
    const all = await couponAll(), act = String(b.act || 'list'), code = String(b.code || '').trim().toUpperCase().replace(/[^A-Z0-9_-]/g, '').slice(0, 24);
    if (act === 'save') { if (code.length < 3) return [400, { error: 'code' }]; const pct = Math.max(1, Math.min(90, b.pct | 0)); const old = all[code] || { used: 0, opened: 0, at: Date.now() };
      all[code] = Object.assign(old, { pct, on: b.on !== false, until: (+b.days || 0) > 0 ? Date.now() + Math.min(3650, +b.days) * 864e5 : 0, max: Math.max(0, b.max | 0), ann: b.ann !== false, by: a.username });
      await DB.kvSet('mucoupons', all); DB.log('mu_coupon', { act, code, pct, by: a.username }); if (all[code].ann && all[code].on) annOne(code, all[code]); }
    else if (act === 'toggle' && all[code]) { all[code].on = !all[code].on; await DB.kvSet('mucoupons', all); DB.log('mu_coupon', { act, code, on: all[code].on }); }
    else if (act === 'del' && all[code]) { delete all[code]; await DB.kvSet('mucoupons', all); DB.log('mu_coupon', { act, code }); }
    else if (act === 'announce' && all[code]) annOne(code, all[code]);
    const t = Date.now(); return { list: Object.entries(all).map(([k, c]) => ({ code: k, pct: c.pct | 0, on: c.on !== false, until: c.until || 0, max: c.max | 0, used: c.used | 0, opened: c.opened | 0, ann: c.ann !== false, live: c.on !== false && (!c.until || c.until > t) && (!c.max || (c.used | 0) < c.max) })) };
  };
  function annOne(code, c) { if (!MU || !MU.announce) return; MU.announce('🎟 Cupom ' + code + ': ' + c.pct + '% de desconto na Loja Premium e nos VIPs! Digite o cupom na loja antes de pagar.', '🎟 Coupon {0}: {1}% off in the Premium Shop and on every VIP! Type the coupon in the shop before paying.', [code, String(c.pct)]); }
  async function annAll() { try { const all = await couponAll(), t = Date.now(); for (const [k, c] of Object.entries(all)) if (c.ann !== false && c.on !== false && (!c.until || c.until > t) && (!c.max || (c.used | 0) < c.max)) annOne(k, c); } catch (_) {} }
  setTimeout(() => { annAll(); setInterval(annAll, 30 * 60000); }, 60000);   // aviso no chat do servidor a cada 30 minutos

  /* VIP FREE: toda conta ganha 3 dias (uma vez). O herói novo NÃO ganha mais kit Mítico nem asa: tudo se conquista no jogo (out/2026). */
  const FD = (D.FREE_VIP && D.FREE_VIP.days) || 3;
  const WEAP = { dk: 'sword_1', dw: 'staff_1', elf: 'bow_1', mg: 'sword_1', dl: 'dlsc_1' };
  function starter(cls) {
    return [];   // sem kit inicial: começa só com o equipamento básico da classe
    const L = [['weapon', WEAP[cls] || 'sword_1'], ['armor', 'armor_1'], ['pants', 'pants_1'], ['gloves', 'gloves_1'], ['boots', 'boots_1'], ['pendant', 'pendant_1']];
    if (cls !== 'mg') L.push(['helm', 'helm_1']); L.push(['wings', cls === 'dl' ? 'dlcape_0' : 'wings_0']);
    return L.filter(([sl, b]) => D.BASES[b]).map(([sl, b]) => [sl, D.makeItem(b, 6, sl === 'wings' ? 0 : 3)]);
  }
  async function freeVip(acc, charId) {
    let gave = 0, v = (await DB.kvGet('muvip:' + acc)) || {};
    if (!v.freeGot) { v.freeGot = Date.now(); v.free = Date.now() + FD * 864e5; await DB.kvSet('muvip:' + acc, v); gave = 1; DB.log('mu_free_vip', { acc, until: v.free }); }
    const k = 'mustart:' + charId; if (await DB.kvGet(k)) return { gave };
    const sv = await DB.kvGet('mu:' + charId); if (!sv || !D.CLASSES[sv.cls]) return { gave };
    if ((sv.level | 0) > 10 || (sv.resets | 0) > 0) { await DB.kvSet(k, { at: Date.now(), skip: 1 }); return { gave }; }   // herói antigo: só o VIP Free
    sv.equip = sv.equip && typeof sv.equip === 'object' ? sv.equip : {}; sv.inv = Array.isArray(sv.inv) ? sv.inv : []; let n = 0;
    for (const [sl, it] of starter(sv.cls)) { const old = sv.equip[sl];
      if (old) { const ob = D.BASES[old.b]; if (ob && (ob.tier | 0) >= 1) continue;   // já tem algo melhor que o inicial: não troca
        const i = sv.inv.findIndex((x, j) => j < INV && !x); if (i >= 0) sv.inv[i] = old; }
      sv.equip[sl] = it; n++; }
    await DB.kvSet('mu:' + charId, sv); await DB.kvSet(k, { at: Date.now(), n }); DB.log('mu_free_gear', { char: charId, n });
    return { gave, gear: n };
  }
  const oLoad = API['POST /api/mu/load'];
  API['POST /api/mu/load'] = async (b, req) => {
    let fv = null;
    try { const t = verify(b && b.token), row = t && b && b.char ? await DB.charById(+b.char) : null;
      if (row && row.account_id === t.a) fv = { row, ...(await freeVip(row.account_id, row.id)) }; } catch (e) { console.error('[vip free]', e.message); }
    const r = await oLoad(b, req);
    try { const j = Array.isArray(r) ? r[1] : r;
      if (fv && j && typeof j === 'object' && j.sv) {
        if (!fv.gear && !(await DB.kvGet('mustart:' + fv.row.id))) { const g = await freeVip(fv.row.account_id, fv.row.id); if (g.gear) { fv.gear = g.gear; const after = await DB.kvGet('mu:' + fv.row.id); if (after) { j.sv = await muOutSv(fv.row.id, after); j._inj = 1; } } }   // herói novo: o salvamento só existe depois do 1º load
        if (fv.gave) j.freeNew = FD; if (fv.gear) j.freeGear = fv.gear;
        if (fv.gave || fv.gear) { const v = (await DB.kvGet('muvip:' + fv.row.account_id)) || {}; j.vip = Object.assign(j.vip || {}, { free: (v.free || 0) > Date.now() ? v.free : 0 }); } } } catch (e) { console.error('[vip free pos]', e.message); }
    return r;
  };
})();

/* ===================== EVENTO DE NATAL (automático, a cada 2h30, dura 30 minutos) =====================
   - Começa sozinho (XMAS_EVERY / XMAS_LEN em mu-data.js), com aviso no chat 2 minutos antes, no início e no fim.
   - No jogo: monstros de Natal (com gorro do Papai Noel) aparecem em todos os mapas.
   - Quem está CAÇANDO durante o evento recebe presentes sorteados pelo SERVIDOR (o navegador nunca cria esses itens):
       • itens de Natal (100 itens xm_*; 25% saem da lista rara);
       • itens aleatórios do jogo (qualquer equipamento que NÃO é vendido na loja premium, nem VIP, Master Reset ou raríssimo);
       • muito raramente, um item raríssimo (rr_*).
   - Limite por herói em cada evento: 12 itens de Natal e 8 aleatórios. Inventário cheio: espera em "muxmas:<herói>". */
(() => {
  const D = MUD, INV = D.CFG.INV, EVERY = D.XMAS_EVERY || 150 * 60000, LEN = D.XMAS_LEN || 30 * 60000;
  const P_XMAS = +process.env.XMAS_PCT_ITEM || 30, P_RAND = +process.env.XMAS_PCT_RANDOM || 20, P_RARE = +process.env.XMAS_PCT_ULTRA || .2;   // % por minuto de caça
  const CAP_X = 12, CAP_R = 8;
  const RAND = D.xmasRandomPool();
  const at = (t = Date.now()) => { const slot = Math.floor(t / EVERY), start = slot * EVERY, on = t - start < LEN || process.env.XMAS_FORCE_ON === '1';
    return { slot, on, active: on ? { id: 'xmas', name: 'Christmas Event', until: t - start < LEN ? start + LEN : t + LEN } : null, next: on ? start + EVERY : start + EVERY }; };
  MU.xmasAt = at;
  const wsAll = data => { for (const q of muRTPlayers.values()) if (q.ws && q.ws.open !== false) { try { q.ws.send(data); } catch (_) {} } };
  const say = (text, k, a) => { if (MU.announce) MU.announce(text, k, a); };
  let said = { warn: -1, start: -1, end: -1 };
  setInterval(() => {
    const t = Date.now(), e = at(t);
    if (e.on && said.start !== e.slot) { said.start = e.slot;
      say('🎄 CHRISTMAS EVENT has started! Christmas monsters are on every map and every hunt can bring Christmas presents: Christmas items, random items and rare drops. (30 minutes)', '🎄 CHRISTMAS EVENT has started! Christmas monsters are on every map and every hunt can bring Christmas presents: Christmas items, random items and rare drops. (30 minutes)', []);
      wsAll({ t: 'mxmas', ev: e.active }); DB.log('mu_xmas_start', { slot: e.slot }); }
    if (!e.on && said.end !== e.slot && t - e.slot * EVERY < LEN + 20000) { said.end = e.slot;
      say('🎄 The Christmas Event has ended. Next one in 2 hours.', '🎄 The Christmas Event has ended. Next one in 2 hours.', []); wsAll({ t: 'mxmas', ev: null }); }
    if (!e.on && e.next - t < 120000 && e.next - t > 0 && said.warn !== e.slot) { said.warn = e.slot; say('🎄 The Christmas Event starts in 2 minutes!', '🎄 The Christmas Event starts in 2 minutes!', []); }
  }, 5000).unref?.();
  const oBoss = API['GET /api/mu/bosses'];
  if (oBoss) API['GET /api/mu/bosses'] = async (b, req) => { const r = await oBoss(b, req); try { const e = at(); if (r && typeof r === 'object' && !Array.isArray(r)) { r.xmas = e.active; r.xmasNext = e.next; } } catch (_) {} return r; };
  API['GET /api/mu/xmas'] = async () => { const e = at(); return { now: Date.now(), active: e.active, next: e.next, every: EVERY, len: LEN, items: D.XMAS_EVENT_IDS.length }; };
  const prog = (a, b) => (b.resets | 0) > (a.resets | 0) || ((b.resets | 0) === (a.resets | 0) && ((b.level | 0) > (a.level | 0) || ((b.level | 0) === (a.level | 0) && (+b.exp || 0) > (+a.exp || 0))));
  const slot = inv => { let i = inv.findIndex((x, j) => j < INV && !x); if (i < 0 && inv.length < INV) i = inv.length; return i; };
  const chance = (pctMin, dt) => 1 - Math.pow(1 - Math.min(.99, pctMin / 100), dt);
  function randItem(lvl, rs) {   // item aleatório do evento (nunca da loja premium)
    const top = rs > 0 ? 1e9 : lvl + 15, L = RAND.filter(id => (D.BASES[id].lvl | 0) <= top); const id = (L.length ? L : RAND)[Math.floor(Math.random() * (L.length || RAND.length))];
    const x = Math.random(), r = x < .45 ? 3 : x < .8 ? 4 : x < .96 ? 5 : 6; return D.makeItem(id, r, Math.floor(Math.random() * 4));
  }
  const oSave = API['POST /api/mu/save'];
  API['POST /api/mu/save'] = async (b, req) => {
    let got = null, id = 0;
    try {
      const e = at(), t = verify(b && b.token); id = +(b && b.char) || 0;
      const row = t && id ? await DB.charById(id) : null;
      if (row && row.account_id === t.a && b.sv && typeof b.sv === 'object' && Array.isArray(b.sv.inv)) {
        const k = 'muxmas:' + id; let st = null;
        const load = async () => { if (!st) { st = (await DB.kvGet(k)) || {}; st.pend = Array.isArray(st.pend) ? st.pend : []; } return st; };
        const prev = await DB.kvGet('mu:' + id);
        if (prev && D.CLASSES[prev.cls]) {
          let dirty = false;
          if (e.on) {
            await load(); if (st.slot !== e.slot) { st.slot = e.slot; st.nx = 0; st.nr = 0; dirty = true; }
            const dt = +process.env.XMAS_TEST_DT || Math.min(2, Math.max(0, (Date.now() - (+prev.t || Date.now())) / 60000));   // XMAS_TEST_DT: só para teste
            if (dt > 0 && prog(prev, b.sv)) {
              const add = (it, kind) => { if (!it) return; st.pend.push(it); dirty = true; const B = D.BASES[it.b];
                DB.log('mu_xmas_drop', { char: id, kind, b: it.b, r: it.r | 0 });
                if (kind === 'ultra' || B.xmas === 3 || (it.r | 0) >= 6) say('🎄 ' + (prev.name || '?') + ' got a Christmas present: ' + B.name + '!', '🎄 {0} got a Christmas present: {1}!', [prev.name || '?', B.name]); };
              if ((st.nx | 0) < CAP_X && Math.random() < chance(P_XMAS, dt)) { st.nx = (st.nx | 0) + 1; add(D.xmasRoll(prev.cls), 'xmas'); }
              if ((st.nr | 0) < CAP_R && Math.random() < chance(P_RAND, dt)) { st.nr = (st.nr | 0) + 1; add(randItem(prev.level | 0, prev.resets | 0), 'random'); }
              if (Math.random() < chance(P_RARE, dt)) add(D.rareRoll(prev.cls), 'ultra');
            }
          } else { const s0 = await DB.kvGet(k); if (s0 && Array.isArray(s0.pend) && s0.pend.length) { st = s0; } }
          if (st && st.pend.length) {
            prev.inv = Array.isArray(prev.inv) ? prev.inv : []; const left = [];
            for (const it of st.pend) { const i = slot(b.sv.inv), pi = slot(prev.inv); if (i < 0 || pi < 0) { left.push(it); continue; } b.sv.inv[i] = it; prev.inv[pi] = it; (got = got || []).push(it); }
            if (got) await DB.kvSet('mu:' + id, prev);
            if (left.length !== st.pend.length) dirty = true; st.pend = left;
          }
          if (dirty && st) await DB.kvSet(k, st);
        }
      }
    } catch (err) { console.error('[natal]', err.message); got = null; }
    const r = await oSave(b, req);
    if (got) { try { const ok = !Array.isArray(r) || r[0] < 300, j = Array.isArray(r) ? r[1] : r;
      if (!ok) {   // salvamento recusado: os presentes voltam para a fila e saem da cópia do banco
        const U = new Set(got.map(x => x.u)), cur = await DB.kvGet('mu:' + id);
        if (cur && Array.isArray(cur.inv)) { cur.inv = cur.inv.map(x => x && U.has(x.u) ? null : x); await DB.kvSet('mu:' + id, cur); }
        const k = 'muxmas:' + id, st = (await DB.kvGet(k)) || {}; st.pend = (Array.isArray(st.pend) ? st.pend : []).filter(x => !U.has(x.u)).concat(got); await DB.kvSet(k, st); got = null; }
      if (ok && j && typeof j === 'object') { const after = await DB.kvGet('mu:' + id); if (after) { j.sv = await muOutSv(id, after); j._inj = 1; } j.xmasGot = got.map(x => ({ b: x.b, r: x.r | 0, p: x.p | 0, o: x.o, q: x.q })); } } catch (err) { console.error('[natal pos]', err.message); } }
    return r;
  };
  console.log('[NATAL] evento a cada', EVERY / 60000, 'min, dura', LEN / 60000, 'min ·', D.XMAS_EVENT_IDS.length, 'itens de Natal ·', RAND.length, 'itens aleatórios permitidos');
})();
/* ===================== GUILDS (MuOnlineClaude) =====================
   - Criar guild: nível 100 ou 1 reset, 500.000 Zen (descontados no servidor), nome de 3 a 12 letras/números, emblema (símbolo + 2 cores).
   - Cargos: Mestre (1), Assistentes e Membros. Até 50 membros.
   - Mestre/assistente convida (pelo nome ou tocando no jogador); o convidado aceita ou recusa. Sair, expulsar, promover, passar a liderança, desfazer.
   - Chat da guild e aviso do mestre. Tag «Guild» em cima da cabeça de todo mundo. Membros da mesma guild não se atacam no PvP.
   - Ranking de guilds (soma de resets e níveis dos membros).
   Dados (tabela kv): mugl:<nome minúsculo> = guild · mugof:<herói> = nome da guild do herói · mugl:list = lista de nomes. Nada dos heróis/contas é alterado (só o Zen da criação). */
(() => {
  const D = MUD, COST = +process.env.GUILD_COST || 500000, MAXM = +process.env.GUILD_MAX || 50, NEED_LVL = +process.env.GUILD_NEED_LVL || 100;
  const SYMS = ['⚔', '🛡', '🐉', '🦅', '🐺', '🔥', '❄', '⚡', '👑', '💀', '🌙', '☀', '🌹', '🍀', '🏹', '🔱'];
  const GK = n => 'mugl:' + String(n).toLowerCase(), OF = id => 'mugof:' + id;
  let chain = Promise.resolve(); const serial = fn => (chain = chain.then(fn, fn));
  const cache = new Map();   // nome minúsculo -> guild (para tags e PvP rápidos)
  const getG = async n => { if (!n) return null; const k = String(n).toLowerCase(); if (cache.has(k)) return cache.get(k); const g = await DB.kvGet(GK(k)); if (g) cache.set(k, g); return g || null; };
  const putG = async g => { cache.set(g.name.toLowerCase(), g); await DB.kvSet(GK(g.name), g); };
  const listG = async () => (await DB.kvGet('mugl:list')) || [];
  const tagOf = async id => { const n = await DB.kvGet(OF(id)); if (!n) return ''; const g = await getG(n); return g && g.members.some(m => m.id === id) ? g.name : ''; };
  MU.guildTag = tagOf;
  MU.guildMark = async n => { const g = await getG(n); return g ? g.mark : null; };
  const push = (id, msg) => { try { const q = muRTPlayers.get(+id); if (q && q.ws) q.ws.send(msg); } catch (_) {} };
  const pushAll = (g, msg) => { for (const m of g.members) push(m.id, msg); };
  const retag = (id, name) => { try { const q = muRTPlayers.get(+id); if (q) { q.guild = name || ''; q.gmark = name ? (cache.get(name.toLowerCase()) || {}).mark || null : null; muSendMap(muK(q), { t: 'pvp_state', ...muPublic(q) }); } } catch (_) {} };
  const view = async (g, me) => ({ name: g.name, mark: g.mark, notice: g.notice || '', created: g.created, master: g.master, me: (g.members.find(m => m.id === me) || {}).rank || '',
    members: g.members.map(m => { const q = muRTPlayers.get(m.id); return { id: m.id, name: m.name, cls: m.cls, rank: m.rank, lvl: q ? q.level : m.lvl | 0, rs: q ? q.resets : m.rs | 0, on: !!q, map: q ? q.map : '' }; }),
    chat: (g.chat || []).slice(-60), max: MAXM });
  const power = g => g.members.reduce((s, m) => s + (m.rs | 0) * 1000 + (m.lvl | 0), 0);
  async function ranking() { const out = []; for (const n of await listG()) { const g = await getG(n); if (g) out.push({ name: g.name, mark: g.mark, members: g.members.length, master: (g.members.find(m => m.rank === 'master') || {}).name || '', power: power(g) }); } return out.sort((a, b) => b.power - a.power).slice(0, 30); }
  async function findChar(name) { const low = String(name || '').trim().toLowerCase(); if (!low) return null;
    for (const q of muRTPlayers.values()) if (String(q.name).toLowerCase() === low) return { id: q.id, name: q.name, cls: q.cls, lvl: q.level, rs: q.resets };
    for (const r of await DB.kvList('mu:')) { const d = r.data; if (d && d.name && String(d.name).toLowerCase() === low && /^mu:\d+$/.test(r.k || r.key || '')) return { id: +String(r.k || r.key).slice(3), name: d.name, cls: d.cls, lvl: d.level | 0, rs: d.resets | 0 }; }
    return null; }
  API['POST /api/mu/guild'] = async (b, req) => {
    if (limited(ipOf(req), 90)) return [429, { error: 'rate' }];
    const t = verify(b && b.token); if (!t) return [401, { error: 'auth' }];
    const row = await DB.charById(+b.char); if (!row || row.account_id !== t.a) return [400, { error: 'char' }];
    const me = row.id, act = String(b.act || 'me');
    if (act === 'rank') return { ok: true, list: await ranking() };
    return serial(async () => {
      const sv = await DB.kvGet('mu:' + me); if (!sv) return [400, { error: 'char' }];
      const myName = sv.name, mine = await getG(await DB.kvGet(OF(me)));
      const g = mine && mine.members.some(m => m.id === me) ? mine : null, my = g ? g.members.find(m => m.id === me) : null;
      if (g && my) { my.lvl = sv.level | 0; my.rs = sv.resets | 0; my.name = sv.name; }
      const invites = ((await DB.kvGet('mugiv:' + me)) || []).filter(x => x.at > Date.now() - 7 * 864e5);
      const done = async extra => Object.assign({ ok: true, guild: g ? await view(g, me) : null, invites, cost: COST, need: NEED_LVL, syms: SYMS }, extra || {});
      if (act === 'me') return done();
      if (act === 'create') {
        if (g) return [400, { error: 'in_guild' }];
        const name = String(b.name || '').trim(); if (!/^[A-Za-z0-9]{3,12}$/.test(name)) return [400, { error: 'name' }];
        if (!((sv.level | 0) >= NEED_LVL || (sv.resets | 0) > 0)) return [400, { error: 'level' }];
        if ((+sv.gold || 0) < COST) return [400, { error: 'gold' }];
        if (await getG(name) || (await listG()).includes(name.toLowerCase())) return [409, { error: 'taken' }];
        const mk = b.mark || {}, mark = { s: SYMS.includes(mk.s) ? mk.s : SYMS[0], c1: /^#[0-9a-f]{6}$/i.test(mk.c1) ? mk.c1 : '#c8102e', c2: /^#[0-9a-f]{6}$/i.test(mk.c2) ? mk.c2 : '#ffd24a' };
        sv.gold = Math.floor((+sv.gold || 0) - COST); await DB.kvSet('mu:' + me, sv);
        const ng = { name, mark, created: Date.now(), master: me, notice: '', chat: [], members: [{ id: me, name: myName, cls: sv.cls, rank: 'master', lvl: sv.level | 0, rs: sv.resets | 0, at: Date.now() }] };
        await putG(ng); await DB.kvSet(OF(me), name.toLowerCase()); const L = await listG(); L.push(name.toLowerCase()); await DB.kvSet('mugl:list', L);
        DB.log('mu_guild_create', { char: me, name, cost: COST }); retag(me, name);
        if (MU.announce) MU.announce('🏰 ' + myName + ' founded the guild ' + name + '!', '🏰 {0} founded the guild {1}!', [myName, name]);
        return done({ guild: await view(ng, me), sv: await muOutSv(me, sv), done: 'created' });
      }
      if (act === 'accept' || act === 'decline') {
        const gname = String(b.g || '').toLowerCase(), inv = invites.find(x => x.g === gname);
        await DB.kvSet('mugiv:' + me, invites.filter(x => x.g !== gname));
        if (act === 'decline' || !inv) return done({ invites: invites.filter(x => x.g !== gname), done: 'declined' });
        if (g) return [400, { error: 'in_guild' }];
        const G = await getG(gname); if (!G) return [404, { error: 'gone' }];
        if (G.members.length >= MAXM) return [400, { error: 'full' }];
        G.members.push({ id: me, name: myName, cls: sv.cls, rank: 'member', lvl: sv.level | 0, rs: sv.resets | 0, at: Date.now() }); await putG(G); await DB.kvSet(OF(me), gname);
        DB.log('mu_guild_join', { char: me, g: G.name }); retag(me, G.name); pushAll(G, { t: 'g_upd', k: '{0} joined the guild.', a: [myName] });
        return done({ guild: await view(G, me), invites: invites.filter(x => x.g !== gname), done: 'joined' });
      }
      if (!g) return [400, { error: 'no_guild' }];
      const boss = my.rank === 'master', staff = boss || my.rank === 'assist';
      const tgId = +b.id || 0, tg = tgId ? g.members.find(m => m.id === tgId) : null;
      if (act === 'invite') {
        if (!staff) return [403, { error: 'rank' }];
        if (g.members.length >= MAXM) return [400, { error: 'full' }];
        const who = tgId ? await (async () => { const s2 = await DB.kvGet('mu:' + tgId); return s2 ? { id: tgId, name: s2.name } : null; })() : await findChar(b.name);
        if (!who) return [404, { error: 'target' }]; if (who.id === me) return [400, { error: 'target' }];
        if (await tagOf(who.id)) return [409, { error: 'target_guild' }];
        const L = ((await DB.kvGet('mugiv:' + who.id)) || []).filter(x => x.g !== g.name.toLowerCase() && x.at > Date.now() - 7 * 864e5); L.push({ g: g.name.toLowerCase(), name: g.name, mark: g.mark, by: myName, at: Date.now() });
        await DB.kvSet('mugiv:' + who.id, L.slice(-10)); push(who.id, { t: 'g_inv', g: g.name, by: myName });
        return done({ done: 'invited', who: who.name });
      }
      if (act === 'leave') {
        if (boss && g.members.length > 1) return [400, { error: 'master_leave' }];
        g.members = g.members.filter(m => m.id !== me); await DB.kvDel?.(OF(me)); await DB.kvSet(OF(me), ''); retag(me, '');
        if (!g.members.length) { cache.delete(g.name.toLowerCase()); await DB.kvDel(GK(g.name)); await DB.kvSet('mugl:list', (await listG()).filter(x => x !== g.name.toLowerCase())); DB.log('mu_guild_end', { g: g.name }); return done({ guild: null, done: 'left' }); }
        await putG(g); pushAll(g, { t: 'g_upd', k: '{0} left the guild.', a: [myName] }); DB.log('mu_guild_leave', { char: me, g: g.name });
        return done({ guild: null, done: 'left' });
      }
      if (act === 'disband') {
        if (!boss) return [403, { error: 'rank' }];
        for (const m of g.members) { await DB.kvSet(OF(m.id), ''); retag(m.id, ''); push(m.id, { t: 'g_upd', k: 'The guild {0} was disbanded.', a: [g.name], gone: 1 }); }
        cache.delete(g.name.toLowerCase()); await DB.kvDel(GK(g.name)); await DB.kvSet('mugl:list', (await listG()).filter(x => x !== g.name.toLowerCase()));
        DB.log('mu_guild_disband', { char: me, g: g.name, n: g.members.length }); return done({ guild: null, done: 'disbanded' });
      }
      if (act === 'kick') {
        if (!tg || tg.id === me) return [400, { error: 'target' }]; if (!staff || tg.rank === 'master' || (tg.rank === 'assist' && !boss)) return [403, { error: 'rank' }];
        g.members = g.members.filter(m => m.id !== tg.id); await DB.kvSet(OF(tg.id), ''); await putG(g); retag(tg.id, ''); push(tg.id, { t: 'g_upd', k: 'You were removed from the guild {0}.', a: [g.name], gone: 1 });
        pushAll(g, { t: 'g_upd', k: '{0} was removed from the guild.', a: [tg.name] }); DB.log('mu_guild_kick', { by: me, char: tg.id, g: g.name }); return done({ guild: await view(g, me), done: 'kicked' });
      }
      if (act === 'promote' || act === 'demote') {
        if (!boss || !tg || tg.id === me) return [403, { error: 'rank' }];
        tg.rank = act === 'promote' ? 'assist' : 'member'; await putG(g); pushAll(g, { t: 'g_upd', k: act === 'promote' ? '{0} is now a guild assistant.' : '{0} is now a guild member.', a: [tg.name] });
        return done({ guild: await view(g, me), done: act });
      }
      if (act === 'transfer') {
        if (!boss || !tg || tg.id === me) return [403, { error: 'rank' }];
        tg.rank = 'master'; my.rank = 'assist'; g.master = tg.id; await putG(g); pushAll(g, { t: 'g_upd', k: '{0} is the new guild master.', a: [tg.name] });
        return done({ guild: await view(g, me), done: 'transfer' });
      }
      if (act === 'notice') {
        if (!staff) return [403, { error: 'rank' }]; g.notice = String(b.text || '').replace(/[<>]/g, '').slice(0, 200); await putG(g);
        pushAll(g, { t: 'g_upd', k: 'Guild notice updated.', a: [] }); return done({ guild: await view(g, me), done: 'notice' });
      }
      if (act === 'chat') {
        const x = String(b.text || '').replace(/[<>]/g, '').trim().slice(0, 160); if (!x) return [400, { error: 'empty' }];
        const last = g.chat && g.chat.length ? g.chat[g.chat.length - 1] : null; if (last && last.id === me && Date.now() - last.t < 1200) return [429, { error: 'rate' }];
        const msg = { t: Date.now(), id: me, n: myName, x }; g.chat = (g.chat || []).concat(msg).slice(-60); await putG(g);
        pushAll(g, { t: 'g_chat', m: msg }); return done({ done: 'chat' });
      }
      return [400, { error: 'action' }];
    });
  };
  console.log('[GUILD] sistema de guilds carregado · custo', COST, 'Zen · até', MAXM, 'membros');
})();
/* ranking do jogo: resets, nível, monstros, PvP, chefes (atualiza a cada minuto) */
let muRankCache = { t: 0, v: null };
API['GET /api/mu/ranks'] = async () => {
  if (Date.now() - muRankCache.t < 60000 && muRankCache.v) return muRankCache.v;
  const rows = await DB.kvList('mu:'), heroes = [], pvp = {}, t = Date.now();
  for (const r of rows) { const k = String(r.key || ''), d = r.data; if (!d) continue;
    if (k.startsWith('mu:pvp:')) { pvp[+k.slice(7)] = d; continue; }
    const id = +k.slice(3); if (!id || !d.name || !d.cls) continue;
    heroes.push({ id, n: d.name, c: d.cls, l: d.level | 0, r: d.resets | 0, k: d.kills | 0 }); }
  const rank = {}, vipAcc = {}, bk = (await DB.kvGet('mubosskills')) || {};
  for (const r of await DB.kvList('murank:')) rank[+String(r.key).slice(7)] = r.data | 0;
  const mrc = {}; for (const r of await DB.kvList('mumr:')) mrc[+String(r.key).slice(5)] = (r.data && r.data.count) | 0;
  for (const r of await DB.kvList('muvip:')) { const v = r.data || {}; vipAcc[+String(r.key).slice(6)] = MUD.vipTierOf(v, t); }
  let accOf = {}; try { for (const c of await DB.allChars()) accOf[c.id] = c.account_id; } catch (_) {}
  for (const h of heroes) { h.e = rank[h.id] | 0; h.v = vipAcc[accOf[h.id]] || ''; h.pk = (pvp[h.id] && pvp[h.id].kills) | 0; h.pd = (pvp[h.id] && pvp[h.id].deaths) | 0; h.b = bk[h.id] | 0; h.mr = mrc[h.id] | 0; }
  const top = (f, n = 50) => [...heroes].sort(f).slice(0, n);
  const v = { t: Date.now(),
    resets: top((a, b) => (b.mr - a.mr) || (b.r - a.r) || (b.l - a.l)), level: top((a, b) => (b.l - a.l) || (b.r - a.r)),
    kills: top((a, b) => b.k - a.k).filter(h => h.k > 0), pvp: top((a, b) => (b.pk - a.pk) || (a.pd - b.pd)).filter(h => h.pk > 0),
    bosses: top((a, b) => b.b - a.b).filter(h => h.b > 0), total: heroes.length };
  muRankCache = { t: Date.now(), v }; return v;
};   // quantos jogadores em cada sala
let HEROES_GZ = null;
const STATIC_GZIP = new Map(); // Cache compressed HTML/JS/CSS to speed up first load on mobile
const httpRateBuckets = new Map();
const HTTP_RATE_WINDOW_MS = 60_000;
const HTTP_RATE_MAX = 180;
const API_RATE_MAX = 90;
function securityHeaders(res) {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'SAMEORIGIN');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');
  res.setHeader('Cross-Origin-Resource-Policy', 'same-site');
  res.setHeader('X-Permitted-Cross-Domain-Policies', 'none');
  res.setHeader('Cache-Control', 'no-store');
}
function requestAllowed(req, res, pathname) {
  const forwarded = String(req.headers['x-forwarded-for'] || '').split(',')[0].trim();
  const ip = (req.socket && req.socket.remoteAddress) || forwarded || 'unknown';
  const now = Date.now();
  let b = httpRateBuckets.get(ip);
  if (!b || now - b.start >= HTTP_RATE_WINDOW_MS) b = {start: now, all: 0, api: 0};
  b.all++;
  if (pathname.startsWith('/api/')) b.api++;
  httpRateBuckets.set(ip, b);
  // Periodic cleanup prevents the limiter map growing forever.
  if (httpRateBuckets.size > 5000) {
    for (const [k, v] of httpRateBuckets) if (now - v.start >= HTTP_RATE_WINDOW_MS) httpRateBuckets.delete(k);
  }
  if (b.all > HTTP_RATE_MAX || (pathname.startsWith('/api/') && b.api > API_RATE_MAX)) {
    res.writeHead(429, {'Content-Type':'application/json; charset=utf-8','Retry-After':'60','Cache-Control':'no-store'});
    res.end(JSON.stringify({error:'rate_limited'}));
    return false;
  }
  return true;
}
const server = http.createServer(async (req, res) => {
  securityHeaders(res);
  const earlyPath = String(req.url || '/').split('?')[0];
  if (!requestAllowed(req, res, earlyPath)) return;
  try {
    const url = new URL(req.url, 'http://x');
    if (!['GET', 'HEAD', 'POST', 'OPTIONS'].includes(req.method)) {
      res.setHeader('Allow', 'GET, HEAD, POST, OPTIONS');
      sendJson(res, 405, { error: 'method_not_allowed' }); return;
    }
    // Reject oversized declared bodies before buffering them in memory.
    const declaredLength = Number(req.headers['content-length'] || 0);
    if (req.method === 'POST' && Number.isFinite(declaredLength) && ((declaredLength > 256 * 1024 && url.pathname === '/api/stripe-webhook') || (declaredLength > 600 * 1024 && url.pathname === '/api/mkt/img'))) {
      sendJson(res, 413, { error: 'payload_too_large' }); return;
    }
    const key = req.method + ' ' + url.pathname;
    if (url.pathname.startsWith('/api/')) {
      res.setHeader('Access-Control-Allow-Origin', '*'); res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS'); res.setHeader('Access-Control-Allow-Headers', 'Content-Type'); res.setHeader('Access-Control-Max-Age', '86400');
      if (req.method === 'OPTIONS') { res.writeHead(204); res.end(); return; }
    }
    if (url.pathname === '/health') { res.end('ok'); return; }
    if (key === 'POST /api/stripe-webhook') { await MKT.webhook(req, res); return; }   // loja + mercado dos jogadores
    if (key === 'GET /pagar-comissao') { await MKT.payLink(req, res, url); return; }   // link direto (jogo, mercado e e-mail) para pagar a comissão devida
    if (key === 'POST /api/mkt/img') { await MKT.imgUpload(req, res); return; }
    if (key === 'GET /api/mkt/img' || key === 'HEAD /api/mkt/img') { await MKT.img(req, res, url); return; }
    if (API[key]) {
      const body = req.method === 'POST' ? await readBody(req) : {};
      const r = await API[key](body, req);
      if (Array.isArray(r)) sendJson(res, r[0], r[1]); else sendJson(res, 200, r);
      return;
    }
    if (url.pathname.startsWith('/api/')) { sendJson(res, 404, { error: 'not_found' }); return; }
    if (url.pathname === '/pixel') { res.writeHead(302, { Location: '/pixel.html' }); res.end(); return; }
    if (['/classic', '/index.html', '/heroes.js'].includes(url.pathname)) { res.writeHead(302, { Location: '/' }); res.end(); return; }
    if (url.pathname === '/status') url.pathname = '/status.html';
    if (['/wow', '/classico', '/wow.html'].includes(url.pathname)) { res.writeHead(302, { Location: '/jogar' }); res.end(); return; }   // só o MuOnlineClaude fica no ar (o jogo anterior saiu do site; as contas continuam valendo)
    if (url.pathname === '/jogar' || url.pathname === '/play') url.pathname = '/pixel.html';   // jogo agora 100% 2D (o 3D continua em /mu.html)
    if (url.pathname === '/mercado' || url.pathname === '/market') url.pathname = '/mu-market.html';
    if (url.pathname === '/app' || url.pathname === '/app/' || url.pathname === '/app.html') url.pathname = '/mu-app.html';   // página inicial do aplicativo (Play Store)
    let file = path.normalize(path.join(PUB, decodeURIComponent(url.pathname)));
    if (!file.startsWith(PUB)) { res.writeHead(403); res.end(); return; }
    if (FLAT && !(PUBLIC_FILES.has(path.basename(file))||/^(cls|mob|npc|mount)_[a-z]+\.glb$/.test(path.basename(file))||/^mu-[a-z0-9-]+\.(jpg|png|webp)$/.test(path.basename(file)))) file = HOME_FILE;
    if (url.pathname === '/' || !fs.existsSync(file) || fs.statSync(file).isDirectory()) file = HOME_FILE;
    const hdr = { 'Content-Type': MIME[path.extname(file)] || 'application/octet-stream', 'Cache-Control': file.endsWith('.html') ? 'no-cache' : 'public, max-age=300' };
    if (file.endsWith('.apk')) { hdr['Content-Disposition'] = 'attachment; filename="MuonlineClaude.apk"'; hdr['Content-Length'] = fs.statSync(file).size; hdr['X-Content-Type-Options'] = 'nosniff'; hdr['Cache-Control'] = 'public, max-age=60'; }
    if (file.endsWith('.glb')) hdr['Cache-Control'] = 'public, max-age=604800';
    if (file.endsWith('.mp4') || file.endsWith('.webm')) {   // vídeo do trailer: aceita pedaços (Range), senão o celular não toca
      const size = fs.statSync(file).size, rg = /^bytes=(\d*)-(\d*)$/.exec(String(req.headers.range || ''));
      hdr['Accept-Ranges'] = 'bytes'; hdr['Cache-Control'] = 'public, max-age=86400';
      if (rg && (rg[1] || rg[2])) {
        let a = rg[1] === '' ? Math.max(0, size - Number(rg[2])) : Number(rg[1]), b = rg[1] !== '' && rg[2] !== '' ? Math.min(size - 1, Number(rg[2])) : size - 1;
        if (!(a <= b) || a >= size) { res.writeHead(416, { 'Content-Range': 'bytes */' + size }); res.end(); return; }
        hdr['Content-Range'] = 'bytes ' + a + '-' + b + '/' + size; hdr['Content-Length'] = b - a + 1; res.writeHead(206, hdr);
        if (req.method === 'HEAD') { res.end(); return; }
        fs.createReadStream(file, { start: a, end: b }).on('error', () => res.destroy()).pipe(res); return;
      }
      hdr['Content-Length'] = size;
    }
    const ext = path.extname(file).toLowerCase();
    if (['.html', '.js', '.css', '.json', '.svg'].includes(ext)) hdr['Vary'] = 'Accept-Encoding';
    if (['.html', '.js', '.css', '.json', '.svg'].includes(ext) && /gzip/.test(String(req.headers['accept-encoding'] || ''))) {
      const st = fs.statSync(file); let packed = STATIC_GZIP.get(file);
      if (!packed || packed.m !== st.mtimeMs || packed.s !== st.size) {
        packed = { m: st.mtimeMs, s: st.size, z: require('zlib').gzipSync(fs.readFileSync(file), { level: 6 }) };
        STATIC_GZIP.set(file, packed);
        if (STATIC_GZIP.size > 80) STATIC_GZIP.delete(STATIC_GZIP.keys().next().value);
      }
      hdr['Content-Encoding'] = 'gzip'; hdr['Vary'] = 'Accept-Encoding'; hdr['Content-Length'] = packed.z.length;
      res.writeHead(200, hdr); res.end(req.method === 'HEAD' ? undefined : packed.z); return;
    }
    if (path.basename(file) === 'heroes.js') {   // modelos 3D dos heróis: grande, então vai comprimido e fica em cache por 1 dia (a URL muda a cada versão)
      hdr['Cache-Control'] = 'public, max-age=86400';
      const ae = String(req.headers['accept-encoding'] || '');
      if (!HEROES_GZ || HEROES_GZ.m !== fs.statSync(file).mtimeMs) HEROES_GZ = { m: fs.statSync(file).mtimeMs, z: require('zlib').gzipSync(fs.readFileSync(file), { level: 9 }) };
      if (/gzip/.test(ae)) { hdr['Content-Encoding'] = 'gzip'; hdr['Content-Length'] = HEROES_GZ.z.length; res.writeHead(200, hdr); res.end(req.method === 'HEAD' ? undefined : HEROES_GZ.z); return; }
    }
    res.writeHead(200, hdr);
    if (req.method === 'HEAD') { res.end(); return; }
    fs.createReadStream(file).on('error', () => res.destroy()).pipe(res);
  } catch (e) { console.error(e); if (!res.headersSent) sendJson(res, 500, { error: 'server' }); else res.end(); }
});

/* =============================== WEBSOCKET (RFC 6455) =============================== */
class WS {
  constructor(sock) {
    this.sock = sock; this.buf = Buffer.alloc(0); this.frag = null; this.open = true; this.alive = true; this.h = {};
    sock.on('data', d => this._data(d)); sock.on('close', () => this._closed()); sock.on('error', () => this._closed());
  }
  on(ev, fn) { this.h[ev] = fn; }
  _emit(ev, a) { const f = this.h[ev]; if (f) try { f(a); } catch (e) { console.error(e); } }
  _data(d) {
    this.buf = this.buf.length ? Buffer.concat([this.buf, d]) : d;
    while (this.open) {
      const b = this.buf; if (b.length < 2) return;
      if (b.length > 256 * 1024) { this.close(1009); return; }
      const fin = b[0] & 0x80, op = b[0] & 0x0f, masked = b[1] & 0x80; let len = b[1] & 0x7f, off = 2;
      // RFC 6455: client-to-server frames must be masked; RSV bits are unsupported.
      if ((b[0] & 0x70) !== 0 || !masked) { this.close(1002); return; }
      if (len === 126) { if (b.length < 4) return; len = b.readUInt16BE(2); off = 4; }
      else if (len === 127) { if (b.length < 10) return; if (b.readUInt32BE(2)) { this.close(1009); return; } len = b.readUInt32BE(6); off = 10; }
      if (len > 65536) { this.close(1009); return; }
      const ml = masked ? 4 : 0; if (b.length < off + ml + len) return;
      let pl = Buffer.from(b.subarray(off + ml, off + ml + len));
      if (masked) { const m = b.subarray(off, off + 4); for (let i = 0; i < pl.length; i++) pl[i] ^= m[i & 3]; }
      this.buf = b.subarray(off + ml + len);
      if (op === 8) { this.close(); return; }
      if (op === 9) { this._send(10, pl); continue; }
      if (op === 10) { this.alive = true; continue; }
      if (op === 1 || op === 2) { if (fin) this._emit('message', pl.toString('utf8')); else this.frag = [pl]; }
      else if (op === 0 && this.frag) {
        this.frag.push(pl);
        if (this.frag.reduce((sum, part) => sum + part.length, 0) > 65536) { this.frag = null; this.close(1009); return; }
        if (fin) { const m = Buffer.concat(this.frag).toString('utf8'); this.frag = null; this._emit('message', m); }
      }
    }
  }
  _send(op, data) {
    if (!this.open || this.sock.destroyed) return;
    if (this.sock.writableLength > 2e6) { this.close(1008); return; }
    const n = data.length; let h;
    if (n < 126) h = Buffer.from([0x80 | op, n]);
    else if (n < 65536) { h = Buffer.alloc(4); h[0] = 0x80 | op; h[1] = 126; h.writeUInt16BE(n, 2); }
    else { h = Buffer.alloc(10); h[0] = 0x80 | op; h[1] = 127; h.writeUInt32BE(0, 2); h.writeUInt32BE(n, 6); }
    this.sock.write(Buffer.concat([h, data]));
  }
  send(o) { this._send(1, Buffer.from(typeof o === 'string' ? o : JSON.stringify(o))); }
  ping() { this._send(9, Buffer.alloc(0)); }
  close(code = 1000) { if (!this.open) return; const b = Buffer.alloc(2); b.writeUInt16BE(code); try { this._send(8, b); } catch (e) {} this.open = false; try { this.sock.end(); } catch (e) {} setTimeout(() => this._closed(), 200); }
  _closed() { if (this.closed) return; this.closed = true; this.open = false; try { this.sock.destroy(); } catch (e) {} this._emit('close'); }
}
// WebSocket separado para o cliente MU 3D (/wsmu). O servidor valida os golpes
// e bloqueia PvP em mapas-cidade e dentro das zonas seguras.
const muRTPlayers = new Map();
const muClamp = (v, a, b) => Math.max(a, Math.min(b, Number.isFinite(+v) ? +v : a));
const muDist = (a, b) => Math.hypot((a.x || 0) - (b.x || 0), (a.z || 0) - (b.z || 0));
function muVipMul(tier, k) { const T = tier && MUD.VIP_TIERS[tier]; return 1 + ((T && +T[k]) || 0); }
function muRoomCounts() { const c = { pvp: 0, safe: 0 }; for (const q of muRTPlayers.values()) c[muRoom(q.room)]++; return c; }
function muPublic(p) { return { id:p.id, m:p.map, n:p.name, c:p.cls, eq:p.eq||p.sv.equip||{}, x:p.x, z:p.z, ry:p.ry, l:p.level, r:p.resets, hp:Math.ceil(p.hp), maxHp:Math.ceil(p.maxHp), dead:!!(p.dead||p.pvpDead), kills:p.kills|0, deaths:p.deaths|0, v:p.vip||'', g:p.guild||'', gm:p.gmark||null }; }
/* PvP: atributos + equipamento reais do save (arma, defesa, absorção, vida dos itens) */
function muGear(sv) {
  const g = { dmg: 0, dmgPct: 0, def: 0, defPct: 0, absorb: 0, hp: 0, crit: 0 }, L = (sv.level | 0) + ((sv.resets | 0) > 0 ? 1000 : 0);
  for (const sl in (sv.equip || {})) { const it = sv.equip[sl]; if (!it || !MU_D.BASES[it.b]) continue; let st; try { st = MU_D.itemStats(it, L); } catch (_) { continue; }
    if (st.dmg) g.dmg += (st.dmg[0] + st.dmg[1]) / 2 * (sl === 'offhand' && MU_D.BASES[it.b].cat !== 'shield' ? .5 : 1);
    g.dmgPct += st.dmgPct || 0; g.def += st.def || 0; g.defPct += st.defPct || 0; g.absorb += st.absorb || 0; g.hp += st.hp || 0; g.crit += st.crit || 0; }
  g.absorb = Math.min(.6, g.absorb); g.crit = Math.min(.4, g.crit); return g;
}
function muMaxHp(sv) { const C = MU_D.CLASSES[sv.cls]; let h = 100; try { h = Number(C.hp(sv.level | 0 || 1, sv)) || 100; } catch (_) {} return Math.max(1, Math.round(h + muGear(sv).hp)); }
const muEqClean = e => { const o = {}; if (e && typeof e === 'object') for (const k of ['weapon','offhand','helm','armor','pants','gloves','boots','wings']) { const it = e[k]; if (it && MU_D.BASES[it.b] && MU_D.BASES[it.b].equip) o[k] = { b: it.b, r: muClamp(it.r, 0, 6) | 0, p: muClamp(it.p, 0, 15) | 0 }; } return o; };
/* salas: 'pvp' (todos podem se atacar fora da cidade) e 'safe' (sala spot: só monstros). Cada sala é um mundo separado. */
const muRoom = r => r === 'safe' ? 'safe' : 'pvp';
const muK = p => p.map + '|' + muRoom(p.room);
function muSendMap(key, data, except) { const i = String(key).indexOf('|'), map = i < 0 ? key : key.slice(0, i), room = i < 0 ? null : key.slice(i + 1);
  if (data && typeof data === 'object' && !data.m && ['pj','pl','ps','pe','pf','pvp_state','pvp_kill'].includes(data.t)) data.m = map;
  for (const q of muRTPlayers.values()) if (q.ws && q.ws.open !== false && q.map===map && (room === null || muRoom(q.room) === room) && q!==except) { try { q.ws.send(data); } catch (_) {} } }
function muInSafe(p) { const m=MU_D&&MU_D.MAPS&&MU_D.MAPS[p.map]; if(!m)return true; const z=m.safe; return !!(z && Math.hypot(p.x-z.x,p.z-z.z)<z.r); }
function muPvpAllowed(p) { return !!(p && p.ws && !p.pvpDead && muRoom(p.room) === 'pvp' && MU_D && MU_D.MAPS && MU_D.MAPS[p.map] && !muInSafe(p)); }
function muRegen(p, t) { if (p.pvpDead) return; const dt = Math.max(0, t - (p.lastRegen || t)) / 1000; p.lastRegen = t; if (t - (p.lastHurt || 0) > 15000) p.hp = p.maxHp; else p.hp = Math.min(p.maxHp, p.hp + p.maxHp * .012 * dt); }
function muSendState(p) { const o=muPublic(p); muSendMap(muK(p),{t:'pvp_state',...o}); if(p.ws)p.ws.send({t:'pvp_me',hp:Math.ceil(p.hp),maxHp:Math.ceil(p.maxHp),dead:!!p.pvpDead,kills:p.kills|0,deaths:p.deaths|0}); }
/* ===== PARTY (grupo para upar junto): até 5 heróis. Quem está no mesmo mapa e perto (40 m) ganha 50% da EXP de cada monstro
   que um companheiro mata (o jogo de quem recebe aplica as próprias regras de EXP). Cai a conexão: 60 s para voltar ao grupo. ===== */
const muParties = new Map(), muPartyInv = new Map(); let muPartySeq = 0;
const MU_PARTY_MAX = 5, MU_PARTY_RANGE = 40;
const muPartyOf = p => p && p.party ? muParties.get(p.party) || null : null;
function muPartySync(pt) { if (!pt) return; const list = [...pt.members].map(id => { const q = muRTPlayers.get(id); return q ? { id, n: q.name, c: q.cls, l: q.level, r: q.resets, m: q.map, x: Math.round(q.x), z: Math.round(q.z), on: 1 } : { id, n: pt.names.get(id) || '?', on: 0 }; });
  for (const id of pt.members) { const q = muRTPlayers.get(id); if (q && q.ws) q.ws.send({ t: 'party', id: pt.id, lead: pt.lead, list }); } }
function muPartyLeave(id, why) { for (const pt of muParties.values()) if (pt.members.has(id)) {
  pt.members.delete(id); const p = muRTPlayers.get(id); if (p) { p.party = 0; if (p.ws) p.ws.send({ t: 'party', id: 0, why }); }
  if (pt.members.size <= 1) { for (const o of pt.members) { const q = muRTPlayers.get(o); if (q) { q.party = 0; if (q.ws) q.ws.send({ t: 'party', id: 0, why: 'dissolved' }); } } muParties.delete(pt.id); return; }
  if (pt.lead === id) pt.lead = [...pt.members][0]; muPartySync(pt); return; } }
const muPartyMsg = (p, k, a) => { if (p && p.ws) p.ws.send({ t: 'p_msg', k, a: a || [] }); };
setInterval(() => { for (const pt of muParties.values()) muPartySync(pt); }, 5000);
function muPartyHandle(p, m) {
  const t = Date.now();
  if (m.t === 'p_inv') {
    if (t - (p.lastInv || 0) < 1500) return; p.lastInv = t;
    const nm = String(m.name || '').trim().toLowerCase(); let q = m.target ? muRTPlayers.get(+m.target) : null;
    if (!q && nm) for (const x of muRTPlayers.values()) if (String(x.name).toLowerCase() === nm) { q = x; break; }
    if (!q || q === p) return muPartyMsg(p, 'Player not found or offline.');
    if (q.party && q.party === p.party) return muPartyMsg(p, '{0} is already in your party.', [q.name]);
    if (q.party) return muPartyMsg(p, '{0} is already in another party.', [q.name]);
    const pt = muPartyOf(p); if (pt && pt.members.size >= MU_PARTY_MAX) return muPartyMsg(p, 'Your party is full (5 players).');
    muPartyInv.set(q.id, { from: p.id, at: t }); if (q.ws) q.ws.send({ t: 'p_inv', from: p.id, n: p.name, l: p.level, r: p.resets });
    return muPartyMsg(p, 'Invite sent to {0}.', [q.name]);
  }
  if (m.t === 'p_acc' || m.t === 'p_dec') {
    const inv = muPartyInv.get(p.id); muPartyInv.delete(p.id); if (!inv || inv.from !== +m.from || t - inv.at > 60000) return muPartyMsg(p, 'This invite has expired.');
    const q = muRTPlayers.get(inv.from); if (!q) return muPartyMsg(p, 'Player not found or offline.');
    if (m.t === 'p_dec') return muPartyMsg(q, '{0} declined your invite.', [p.name]);
    if (p.party) muPartyLeave(p.id, 'left');
    let pt = muPartyOf(q); if (!pt) { pt = { id: ++muPartySeq, lead: q.id, members: new Set([q.id]), names: new Map([[q.id, q.name]]) }; muParties.set(pt.id, pt); q.party = pt.id; }
    if (pt.members.size >= MU_PARTY_MAX) return muPartyMsg(p, 'This party is full (5 players).');
    pt.members.add(p.id); pt.names.set(p.id, p.name); p.party = pt.id; muPartySync(pt);
    for (const id of pt.members) if (id !== p.id) muPartyMsg(muRTPlayers.get(id), '{0} joined the party.', [p.name]);
    return;
  }
  if (m.t === 'p_leave') return muPartyLeave(p.id, 'left');
  if (m.t === 'p_kick') { const pt = muPartyOf(p); if (!pt || pt.lead !== p.id || !pt.members.has(+m.id) || +m.id === p.id) return; const q = muRTPlayers.get(+m.id); muPartyLeave(+m.id, 'kicked'); if (q) muPartyMsg(q, 'You were removed from the party.'); return; }
  if (m.t === 'p_exp') {   // EXP dividida: só para quem está no mesmo mapa, na mesma sala e perto de quem matou
    const pt = muPartyOf(p); if (!pt) return;
    // aceita o formato antigo {b,ml} e o novo {k:[[b,ml],...]} (várias mortes juntas). Cada morte é conferida com o máximo possível no mapa.
    const raw = Array.isArray(m.k) ? m.k.slice(0, 60) : [[m.b, m.ml]], k = [];
    if (t - (p.pexpT || 0) > 1000) { p.pexpT = t; p.pexpN = 0; }
    for (const e of raw) { if (!Array.isArray(e)) continue; const ml = Math.max(1, Math.min(muPexpLvl(p.map), e[1] | 0)), b = Math.min(+e[0], muPexpMax(ml));
      if (!(b > 0)) continue; if (++p.pexpN > 40) break; k.push([Math.round(b), ml]); }
    if (!k.length) return;
    for (const id of pt.members) { if (id === p.id) continue; const q = muRTPlayers.get(id);
      if (!q || !q.ws || q.map !== p.map || muRoom(q.room) !== muRoom(p.room) || Math.hypot(q.x - p.x, q.z - p.z) > MU_PARTY_RANGE) continue;
      q.ws.send({ t: 'p_exp', k, n: p.name }); }
    return;
  }
}
// limites da EXP compartilhada: nível máximo de monstro do mapa (+ eventos) e EXP máxima de um monstro desse nível (chefe x evento)
const muPexpLvlC = new Map();
function muPexpLvl(map) { if (muPexpLvlC.has(map)) return muPexpLvlC.get(map); const M = MU_D && MU_D.MAPS && MU_D.MAPS[map];
  const v = M && Array.isArray(M.spawns) && M.spawns.length ? Math.max(...M.spawns.map(s => s.lvl | 0)) + 10 : 2000; muPexpLvlC.set(map, v); return v; }
function muPexpMax(l) { return (l * l * .9 + l * 8 + 10) * 12 * 1.2; }
async function onMuSocket(ws, ip) {
  let p=null; const authTimer=setTimeout(()=>{if(!p)ws.close(4001)},10000);
  // Anti-cheat básico no servidor: limita spam de mensagens por conexão.
  let msgWindow=Date.now(), msgCount=0, badCount=0;
  ws.on('message',async raw=>{
    const nowMs=Date.now(); if(Buffer.byteLength(raw)>8192){DB.log('anticheat_ws_payload',{ip:String(ip||'').slice(0,80),id:p&&p.id});try{ws.close(1009)}catch(_){}return;}
    if(nowMs-msgWindow>5000){msgWindow=nowMs;msgCount=0;}
    if(++msgCount>1500){DB.log('anticheat_ws_rate',{ip:String(ip||'').slice(0,80),id:p&&p.id});try{ws.close(1008)}catch(_){}return;}
    if(msgCount>300)return;   // excesso é descartado, sem derrubar o jogador
    let m;try{m=JSON.parse(raw)}catch(_){if(++badCount>=5)try{ws.close(1008)}catch(_){};return} if(!m||typeof m!=='object'||Array.isArray(m))return;
    if(!p){
      if(m.t!=='hello'||!MU_D){ws.close(4001);return}
      const tok=verify(m.token); if(!tok){ws.send({t:'err',e:'auth'});ws.close(4001);return}
      const id=+m.char; let row;try{row=await DB.charById(id)}catch(_){row=null}
      if(!row||row.account_id!==tok.a){ws.send({t:'err',e:'session'});ws.close(4003);return}
      let sv;try{sv=await DB.kvGet('mu:'+id)}catch(_){sv=null}
      if(!sv||!MU_D.CLASSES[sv.cls]){ws.send({t:'err',e:'session'});ws.close(4003);return}
      const cls=sv.cls,level=muClamp(sv.level||1,1,1000),resets=muClamp(sv.resets||0,0,1000000),map=MU_D.MAPS[m.m]&&((MU_D.MAPS[m.m].lvl||1)<=level||resets>0)?m.m:(MU_D.MAPS[sv.map]?sv.map:'lorencia');
      const C=MU_D.CLASSES[cls],maxHp=muMaxHp(sv),maxMp=Math.max(1,Number(C.mp(level,sv))||50);
      let pv={kills:0,deaths:0};try{pv=await DB.kvGet('mu:pvp:'+id)||pv}catch(_){}
      let vipT='';try{const vv=(await DB.kvGet('muvip:'+row.account_id))||{},tn=Date.now();vipT=MUD.vipTierOf(vv,tn)||((vv.free||0)>tn?'free':'')}catch(_){}
      const old=muRTPlayers.get(id);if(old&&old.ws&&old.ws!==ws){try{old.ws.close(4002)}catch(_){}muRTPlayers.delete(id)}
      p={id,accId:tok.a,ws,ip,name:String(sv.name||row.name||'Player').slice(0,24),cls,sv,level,resets,map,
        x:muClamp(m.x,-95,95),z:muClamp(m.z,-95,95),ry:muClamp(m.ry,-Math.PI*2,Math.PI*2),moving:false,dead:false,pvpDead:false,
        maxHp,hp:maxHp,maxMp,mp:maxMp,kills:pv.kills|0,deaths:pv.deaths|0,lastMove:Date.now()-10000,lastHit:0,skillHits:new Map(),lastMpAt:Date.now(),eq:muEqClean(sv.equip),seen:Date.now(),dirty:1,pvpOn:m.pvp!==0,room:muRoom(m.room),vip:vipT,acc:row.account_id,svAt:Date.now(),lastTp:0};
      p.maxHp=Math.round(p.maxHp*muVipMul(vipT,'hp'));p.hp=p.maxHp;p.lastTp=0;   // portal/pergaminho: a nova posição é aceita (antes ficava NaN e o servidor demorava para acompanhar)
      try{if(MU.guildTag){p.guild=await MU.guildTag(id);p.gmark=p.guild?await MU.guildMark(p.guild):null}}catch(_){}
      muRTPlayers.set(id,p);clearTimeout(authTimer);
      for(const pt of muParties.values())if(pt.members.has(id)){p.party=pt.id;setTimeout(()=>muPartySync(pt),300);break}   // voltou depois de cair: continua no grupo
      ws.send({t:'pall',m:p.map,list:[...muRTPlayers.values()].filter(q=>q!==p&&q.map===p.map&&muRoom(q.room)===muRoom(p.room)).map(muPublic)});
      muSendMap(muK(p),{t:'pj',p:muPublic(p)},p);ws.send({t:'pvp_me',hp:p.hp,maxHp:p.maxHp,dead:false,kills:p.kills,deaths:p.deaths});
      return;
    }
    if(p.ws!==ws)return;
    p.seen=Date.now();
    if(m.t&&m.t.startsWith('p_')&&m.t!=='pvp_hit'){muPartyHandle(p,m);return}
    if(m.t==='pvp_toggle'){p.pvpOn=true;return}
    if(m.t==='eq'){p.eq=muEqClean(m.eq);muSendMap(muK(p),{t:'pe',id:p.id,eq:p.eq},p);return}
    if(m.t==='list'){ws.send({t:'pall',m:p.map,list:[...muRTPlayers.values()].filter(q=>q!==p&&q.map===p.map&&muRoom(q.room)===muRoom(p.room)).map(muPublic)});return}
    if(m.t==='st'){
      const requested=String(m.m||p.map), next=MU_D.MAPS[requested];
      if(next&&requested!==p.map){
        const oldMap=p.map;muSendMap(oldMap+'|'+muRoom(p.room),{t:'pl',id:p.id},p);p.map=requested;p.x=muClamp(m.x,-95,95);p.z=muClamp(m.z,-95,95);p.lastMove=Date.now();
        muSendMap(muK(p),{t:'pj',p:muPublic(p)},p);ws.send({t:'pall',m:p.map,list:[...muRTPlayers.values()].filter(q=>q!==p&&q.map===p.map&&muRoom(q.room)===muRoom(p.room)).map(muPublic)});
      } else if(requested===p.map){
        const t=Date.now(),elapsed=Math.max(.05,(t-p.lastMove)/1000),nx=muClamp(m.x,-95,95),nz=muClamp(m.z,-95,95),dist=Math.hypot(nx-p.x,nz-p.z);
        if(dist<=Math.max(3,elapsed*13)){p.x=nx;p.z=nz;p.lastMove=t}
        else if(t-p.lastTp>3000){p.x=nx;p.z=nz;p.lastMove=t;p.lastTp=t}   // portal / pergaminho / renascer
      }
      p.ry=muClamp(m.ry,-Math.PI*2,Math.PI*2);p.moving=!!m.mv;p.dead=p.pvpDead?true:!!m.d;
      // Nunca aceite nível/reset enviados pelo navegador: a fonte oficial é o save do servidor.
      p.level=muClamp(p.sv.level||p.level,1,1000);p.resets=muClamp(p.sv.resets||p.resets,0,1000000);
      p.dirty=1;return;
    }
    if(m.t==='fx'){const o={t:'pf',id:p.id,k:['slash','bow','cast'].includes(m.k)?m.k:'slash'};const sid=String(m.s||'').slice(0,32);if(sid&&/^[a-z0-9_]+$/i.test(sid))o.s=sid;if(Number.isFinite(+m.tx)&&Number.isFinite(+m.tz)){o.tx=Math.round(muClamp(+m.tx,-200,200)*10)/10;o.tz=Math.round(muClamp(+m.tz,-200,200)*10)/10}muSendMap(muK(p),o,p);return}
    if(m.t==='pvp_hit'){
      const q=muRTPlayers.get(+m.target),t=Date.now();
      if(!q||q===p||q.map!==p.map||muRoom(q.room)!==muRoom(p.room))return;
      if(!muPvpAllowed(p)||!muPvpAllowed(q)){ws.send({t:'pvp_notice',k:muRoom(p.room)!=='pvp'?'room':'safe'});return}
      if(p.guild&&p.guild===q.guild){ws.send({t:'pvp_notice',k:'guild'});return}   // mesma guild: aliados não se atacam
      muRegen(q,t);muRegen(p,t);
      const skillId=String(m.skill||'').slice(0,32),skill=skillId?(MU_D.SKILLS[p.cls]||[]).find(x=>x.id===skillId):null;
      if(skillId&&!skill){return} if(skill&&p.level<(skill.lvl||1))return;
      let freshCast=true;   // um poder de área pode acertar vários jogadores no mesmo uso
      if(skill){let cast=p.castSet&&p.castSet.id===skillId&&t-p.castSet.t<600?p.castSet:null;
        if(cast){if(cast.hit.has(q.id)||cast.hit.size>=8)return;freshCast=false}
        else{const last=p.skillHits.get(skillId)||0;if(t-last<(skill.cd||1)*1000-250)return;p.skillHits.set(skillId,t);cast=p.castSet={id:skillId,t,hit:new Set()}}
        cast.hit.add(q.id)}
      else {const cd=p.sv.cls==='elf'?520:p.sv.cls==='dw'?650:500;if(t-p.lastHit<cd)return;p.lastHit=t}
      const range=skill?(skill.type==='aoe'?(skill.range||12)+(skill.r||4):skill.type==='chain'?(skill.range||12)+8:(skill.range||skill.r||(skill.type==='melee'?3.2:10))):((m.style==='melee')?4.5:18);
      if(muDist(p,q)>range+2.5)return;
      const dt=Math.max(0,t-p.lastMpAt)/1000;p.mp=Math.min(p.maxMp,p.mp+dt*p.maxMp*.025);p.lastMpAt=t;
      if(skill&&freshCast){const cost=Number(skill.mp)||0;if(p.mp<cost)return;p.mp-=cost}
      for(const x of [p,q])if(t-(x.svAt||0)>10000){x.svAt=t;try{const f=await DB.kvGet('mu:'+x.id);if(f&&MU_D.CLASSES[f.cls]){x.sv=f;x.level=muClamp(f.level||x.level,1,1000);x.resets=muClamp(f.resets||x.resets,0,1000000);const mh=Math.round(muMaxHp(f)*muVipMul(x.vip,'hp'));if(mh!==x.maxHp){x.hp=Math.min(mh,x.hp*mh/x.maxHp);x.maxHp=mh}}}catch(_){}}
      if(q.pvpDead)return;
      const a=p.sv,def=q.sv;let raw;
      const style=skill?(skill.kind==='magic'?'cast':(skill.type==='proj'&&p.cls==='elf'?'bow':m.style)):(m.style==='magic'?'cast':m.style);
      if(style==='cast')raw=(Number(a.ene)||0)*.24+p.level*1.9;
      else if(style==='bow')raw=(Number(a.agi)||0)*.22+(Number(a.str)||0)*.08+p.level*1.7;
      else raw=(Number(a.str)||0)*.24+p.level*1.8;
      const ga=muGear(a),gd=muGear(def);raw=(raw+ga.dmg)*(1+ga.dmgPct)*muVipMul(p.vip,'dmg');
      if(skill)raw*=Math.max(1,Math.min(5,Number(skill.mult)||1));
      const crit=Math.random()<.05+ga.crit;if(crit)raw*=1.5;
      const defense=((Number(def.agi)||0)*.10+(Number(def.vit)||0)*.08+q.level*.35+gd.def)*(1+gd.defPct);
      let damage=Math.max(1,Math.round((raw*(.85+Math.random()*.3)-defense*.5)*(1-gd.absorb)));damage=Math.min(damage,Math.max(10,Math.round(q.maxHp*.22)));
      q.hp=Math.max(0,q.hp-damage);q.lastHitBy=p.name;q.lastHurt=t;
      const dead=q.hp<=0&&!q.pvpDead;
      if(dead){q.pvpDead=true;q.dead=true;q.deaths++;p.kills++;DB.kvSet('mu:pvp:'+p.id,{kills:p.kills,deaths:p.deaths}).catch(()=>{});DB.kvSet('mu:pvp:'+q.id,{kills:q.kills,deaths:q.deaths}).catch(()=>{});}
      const hit={t:'pvp_damage',attacker:p.id,target:q.id,damage,crit,hp:Math.ceil(q.hp),maxHp:Math.ceil(q.maxHp),dead:!!q.pvpDead,by:p.name,style,skill:skillId||''};
      muSendMap(muK(p),hit);if(freshCast&&m.fx!==0)muSendMap(muK(p),{t:'pf',id:p.id,k:style==='cast'?'cast':style==='bow'?'bow':'slash',s:skillId||undefined,tx:Math.round(q.x*10)/10,tz:Math.round(q.z*10)/10,tid:q.id},p);
      if(dead){muSendMap(muK(p),{t:'pvp_kill',killer:p.name,victim:q.name});if(q.ws)q.ws.send({t:'pvp_me',hp:0,maxHp:q.maxHp,dead:true,by:p.name});
        const victimId=q.id;setTimeout(()=>{const v=muRTPlayers.get(victimId);if(!v||!v.pvpDead)return;const map=MU_D.MAPS[v.map];v.pvpDead=false;v.dead=false;v.hp=v.maxHp;v.mp=v.maxMp;v.x=map&&map.start?muClamp(map.start.x,-95,95):0;v.z=map&&map.start?muClamp(map.start.z,-95,95):0;v.moving=false;v.lastMove=Date.now();if(v.ws)v.ws.send({t:'pvp_me',hp:v.hp,maxHp:v.maxHp,dead:false,respawn:true,x:v.x,z:v.z,map:v.map});muSendMap(muK(v),{t:'pvp_state',...muPublic(v)});muSendMap(muK(v),{t:'ps',p:[...muRTPlayers.values()].filter(a=>a.map===v.map&&muRoom(a.room)===muRoom(v.room)).map(a=>[a.id,a.x,a.z,a.ry,a.moving?1:0,(a.dead||a.pvpDead)?1:0])});},5000);
      } else if(q.ws)q.ws.send({t:'pvp_me',hp:q.hp,maxHp:q.maxHp,dead:false});
      return;
    }
  });
  ws.on('close',()=>{clearTimeout(authTimer);if(p&&p.ws===ws){muRTPlayers.delete(p.id);muSendMap(muK(p),{t:'pl',id:p.id});if(p.party){const id=p.id;setTimeout(()=>{if(!muRTPlayers.has(id))muPartyLeave(id,'offline')},60000)}}});
}
setInterval(() => {   // posições ~7 vezes por segundo, em lote, só de quem se mexeu
  const t = Date.now(), byMap = new Map();
  for (const p of muRTPlayers.values()) {
    if (t - (p.seen || t) > 60000 || (p.ws && p.ws.closed)) { muRTPlayers.delete(p.id); muSendMap(muK(p), { t: 'pl', id: p.id }); try { p.ws.close(); } catch (_) {} continue; }
    let a = byMap.get(muK(p)); if (!a) byMap.set(muK(p), a = []); a.push(p);
  }
  for (const [map, list] of byMap) {
    if (list.length < 2) { for (const p of list) p.dirty = 0; continue; }
    const d = list.filter(p => p.dirty).map(q => [q.id, Math.round(q.x * 10) / 10, Math.round(q.z * 10) / 10, Math.round(q.ry * 100) / 100, q.moving ? 1 : 0, (q.dead || q.pvpDead) ? 1 : 0]);
    for (const p of list) p.dirty = 0;
    if (!d.length) continue;
    const mapId = String(map).split('|')[0]; for (const p of list) { const mine = d.filter(x => x[0] !== p.id); if (mine.length && p.ws) try { p.ws.send({ t: 'ps', m: mapId, p: mine }); } catch (_) {} }
  }
}, 140);
const wsHandshakeBuckets = new Map();
server.on('upgrade', (req, sock) => {
  const ip = (req.socket && req.socket.remoteAddress) || 'unknown';
  const now = Date.now();
  let b = wsHandshakeBuckets.get(ip);
  if (!b || now - b.start >= 60_000) b = {start: now, count: 0};
  b.count++;
  wsHandshakeBuckets.set(ip, b);
  if (b.count > 60) { sock.destroy(); return; }
  if (wsHandshakeBuckets.size > 5000) for (const [k,v] of wsHandshakeBuckets) if (now-v.start>=60_000) wsHandshakeBuckets.delete(k);
  const key = req.headers['sec-websocket-key'];
  const wsPath = new URL(req.url, 'http://x').pathname;
  if ((wsPath !== '/ws' && wsPath !== '/ws3d' && wsPath !== '/wsmu') ||
      typeof key !== 'string' || !/^[A-Za-z0-9+/]{22}==$/.test(key) ||
      String(req.headers.upgrade).toLowerCase() !== 'websocket' ||
      !String(req.headers.connection || '').toLowerCase().split(',').map(x => x.trim()).includes('upgrade')) { sock.destroy(); return; }
  const accept = crypto.createHash('sha1').update(key + '258EAFA5-E914-47DA-95CA-C5AB0DC85B11').digest('base64');
  sock.write('HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: ' + accept + '\r\n\r\n');
  sock.setNoDelay(true);
  if (wsPath === '/ws3d') RT.onSocket(new WS(sock), ipOf(req));
  else if (wsPath === '/wsmu') onMuSocket(new WS(sock), ipOf(req));
  else onSocket(new WS(sock), ipOf(req));
});
setInterval(() => { for (const ws of sockets) { if (!ws.alive) { ws.close(1001); continue; } ws.alive = false; ws.ping(); } }, 20000);

/* =============================== MUNDO =============================== */
let SYS = null;                   // módulo systems.js (criado depois do banco)
const rooms = new Map();          // "mapa:canal" -> Room
const byChar = new Map();         // charId -> jogador (online ou em período de reconexão)
const sockets = new Set();
const parties = new Map();
const guilds = new Map();         // nome minúsculo -> guilda
let partySeq = 1;
const CH_CAP = 40, GRACE = 30000;

class Room {
  constructor(mapId, ch) {
    this.map = mapId; this.ch = ch; this.key = mapId + ':' + ch; this.cfg = S.MAPS[mapId];
    this.players = new Map(); this.mons = []; this.drops = new Map(); this.dropSeq = 1; this.dropsDirty = false; this.emptySince = now();
    this.bossPos = { x: this.cfg.bossPos[0], z: this.cfg.bossPos[1] };
    const dens = (this.cfg.boost && this.cfg.boost.dens) || 1;   // mapas com Fenda: mais monstros
    for (const def of this.cfg.mons) for (let i = 0; i < Math.round(def.count * dens * 1.4); i++) {
      const p = this.spot(def.r[0], def.r[1]); const t = (p.r - def.r[0]) / (def.r[1] - def.r[0]);
      this.addMon(def, clamp(Math.round(def.lvl[0] + t * (def.lvl[1] - def.lvl[0]) + rand(-1, 1)), def.lvl[0], def.lvl[1]), p);
    }
    this.addMon(this.cfg.boss, this.cfg.boss.lvl[0], { x: this.bossPos.x, z: this.bossPos.z });
  }
  spot(a, b) { for (let i = 0; i < 60; i++) { const ang = rand(0, 6.283), r = rand(a, b), x = Math.cos(ang) * r, z = Math.sin(ang) * r; if (Math.hypot(x - this.bossPos.x, z - this.bossPos.z) > 17) return { x, z, r }; } return { x: a, z: 0, r: a }; }
  addMon(def, lvl, p) {
    const k = lvl - def.lvl[0];
    const m = { id: this.mons.length, def, lvl, sx: p.x, sz: p.z, radius: def.radius, boss: !!def.boss,
      maxHp: Math.round(def.hp * (1 + k * .25)), dmg: def.dmg * (1 + k * .12), defn: def.def * (1 + k * .14), atkN: 0 };
    this.mons.push(m); this.respawn(m);
  }
  respawn(m) {
    Object.assign(m, { alive: true, hp: m.maxHp, x: m.sx, z: m.sz, h: rand(0, 6.28), state: 'idle', target: null, atkCd: 0, slowT: 0, timer: rand(0, 4), wx: null, wz: null, specialT: 6, dmgBy: m.boss ? new Map() : null });
    if (m.boss) { this.broadcast({ t: 'msg', k: 'boss_up', n: m.def.name }); }
  }
  send(o, except) { const s = JSON.stringify(o); for (const p of this.players.values()) if (p.ws && p !== except) p.ws.send(s); }
  broadcast(o) { this.send(o); }
  fx(o) { this.send({ t: 'fx', ...o }); }
}
function getRoom(mapId, prefer) {
  if (prefer && prefer.map === mapId && prefer.players.size < CH_CAP) return prefer;
  for (let ch = 1; ch <= 50; ch++) {
    const key = mapId + ':' + ch; let r = rooms.get(key);
    if (!r) { r = new Room(mapId, ch); rooms.set(key, r); log('[canal]', key, 'criado'); return r; }
    if (r.players.size < CH_CAP) return r;
  }
  return null;
}
const inTown = p => Math.hypot(p.x, p.z) < S.TOWN_R;
// zona de combate segura: um pouco menor que a cidade, para quem luta na borda (corpo a corpo) não ser tratado como 'dentro da cidade'
const inSafe = p => Math.hypot(p.x, p.z) < S.TOWN_R - 3;

/* ---------- jogador ---------- */
function msgTo(p, k, extra) { if (p.ws) p.ws.send({ t: 'msg', k, ...extra }); }
function markDirty(p) { p.dirty = true; }
function joinRoom(p, mapId, pos) {
  if (p.room) leaveRoom(p);
  let prefer = null;
  if (p.party) for (const id of p.party.members) { const q = byChar.get(id); if (q && q !== p && q.room && q.room.map === mapId) { prefer = q.room; break; } }
  const room = getRoom(mapId, prefer);
  p.room = room; p.c.map = mapId; room.players.set(p.id, p);
  if (SYS) SYS.onMap(p, mapId);
  const sp = pos || { x: rand(-2, 2), z: 4 + rand(-1, 1) }; p.x = sp.x; p.z = sp.z; p.h = Math.PI; p.target = null;
  sendInit(p);
  if (SYS && SYS.onRoomJoin) SYS.onRoomJoin(p);
  room.send({ t: 'join', p: playerInfo(p) }, p);
}
function leaveRoom(p) {
  const r = p.room; if (!r) return;
  r.players.delete(p.id); r.send({ t: 'leave', id: p.id });
  for (const m of r.mons) if (m.target === p.id) { m.target = null; m.state = 'return'; }
  if (!r.players.size) r.emptySince = now();
  p.room = null;
}
const wingInfo = c => (c.equip && c.equip.asas) ? { style: (c.sys && c.sys.ap && c.sys.ap.w != null) ? c.sys.ap.w : (c.equip.asas.style || 0) } : null;
const playerInfo = p => ({ id: p.id, name: p.c.name, cls: p.c.cls, lvl: p.c.lvl, guild: p.c.guild || null, asas: wingInfo(p.c), ti: (p.c.sys && p.c.sys.title) || null, ap: (SYS && SYS.apInfo) ? SYS.apInfo(p.c, p) : null });
function sendInit(p) {
  if (!p.ws || !p.room) return;
  const r = p.room;
  p.ws.send({ t: 'init', id: p.id, map: r.map, ch: r.ch, c: p.c, x: p.x, z: p.z, hp: p.hp, mp: p.mp,
    mons: r.mons.map(m => ({ k: m.def.model, tint: m.def.tint || 0, s: m.def.scale || 1, n: m.def.name, lvl: m.lvl, mhp: m.maxHp, r: m.radius, b: m.boss ? 1 : 0 })),
    players: [...r.players.values()].filter(q => q !== p && !q.ghost).map(playerInfo),
    drops: dropList(r), boost: r.cfg.boost || null, ver: BUILD });
  if (p.party) sendParty(p.party);
  if (p.c.guild) sendGuild(guilds.get(p.c.guild.toLowerCase()));
}
function regen(p, dt) {
  if (p.dead) return; const t = inTown(p), mh = S.maxHp(p.c), mm = S.maxMp(p.c);
  p.hp = Math.min(mh, p.hp + mh * (t ? .08 : .006) * dt); p.mp = Math.min(mm, p.mp + mm * (t ? .08 : .025) * dt);
}

/* ---------- combate ---------- */
function canPvp(a, b) {
  if (!a || !b || a === b || a.dead || b.dead || b.ghost || a.room !== b.room) return false;
  if (!a.pvp) return false;
  if (a.c.lvl < 10 || b.c.lvl < 10) return false;
  if (inTown(a) || inTown(b)) return false;
  if (a.party && a.party === b.party) return false;
  if (a.c.guild && a.c.guild === b.c.guild) return false;
  return true;
}
function resolveTarget(p, msg) {
  const r = p.room;
  if (msg.m != null) { const m = r.mons[msg.m | 0]; if (m && m.alive) return { kind: 'm', o: m, x: m.x, z: m.z, radius: m.radius }; }
  if (msg.p != null) { const q = r.players.get(+msg.p); if (q && canPvp(p, q)) return { kind: 'p', o: q, x: q.x, z: q.z, radius: .5 }; }
  return null;
}
function hitTarget(p, tg, base) { if (tg.kind === 'm') hitMonster(p.room, p, tg.o, base); else hitPlayer(p, tg.o, base); }
function hitMonster(room, p, m, base) {
  if (!m.alive || !p || p.room !== room) return;
  m.hurtT = now(); m.hurtBy = p.id;                                  // quem bateu por último: o monstro passa a lutar com ele (e não desiste nem cura)
  if (inSafe(p)) { if (!p.safeT || now() - p.safeT > 1500) { p.safeT = now(); msgTo(p, 'safe_atk'); } return; }   // não se ataca de dentro da zona segura
  const crit = Math.random() < S.critChance(p.c);
  const dmg = Math.max(1, Math.ceil(base * .12), Math.round(base * rand(.88, 1.12) * (crit ? 1.6 : 1) - m.defn * .5));   // piso de 12% do ataque: defesa alta nunca deixa o monstro imortal
  m.hp -= dmg; room.fx({ e: 'dmg', m: m.id, v: dmg, c: crit ? 1 : 0, by: p.id });
  { const ls = S.mods(p.c).ls; if (ls > 0 && !p.dead) p.hp = Math.min(S.maxHp(p.c), p.hp + Math.round(dmg * ls)); }
  if (m.boss && SYS) SYS.onBossDamage(p, Math.min(dmg, m.hp + dmg));
  if (m.state !== 'return') { m.target = p.id; m.state = 'chase'; }
  if (m.dmgBy) m.dmgBy.set(p.charId, (m.dmgBy.get(p.charId) || 0) + Math.min(dmg, m.hp + dmg));
  if (m.hp <= 0) killMonster(room, m, p);
}
function hitPlayer(p, q, base) {
  if (!canPvp(p, q)) return;
  const crit = Math.random() < S.critChance(p.c);
  let dmg = Math.round((base * rand(.88, 1.12) * (crit ? 1.5 : 1) - S.defense(q.c) * .6) * .6);
  dmg = Math.max(1, dmg); q.lastHitBy = p.id; q.lastHitAt = now();
  if (SYS) SYS.onPvpHit(p, q, dmg, p.lastSkillKey);
  hurtPlayer(q, dmg, p, crit);
}
function hurtPlayer(p, raw, src, crit, isMon) {
  if (p.dead || p.ghost) return;
  if (isMon && Math.random() < Math.min(.5, p.c.stats.agi / 900 + S.mods(p.c).dodge)) { p.room.fx({ e: 'dodge', p: p.id }); return; }
  const dmg = isMon ? Math.max(1, Math.round(raw * rand(.88, 1.12) - S.defense(p.c) * .6)) : raw;
  p.hp -= dmg; p.room.fx({ e: 'pdmg', p: p.id, v: dmg, c: crit ? 1 : 0 });
  if (p.hp <= 0) die(p, isMon ? null : src);
}
function die(p, killer) {
  p.dead = true; p.hp = 0; p.target = null; p.actN++; p.act = 'death';
  const lost = killer ? 0 : Math.floor(p.c.gold * .05); p.c.gold -= lost;
  if (!killer && SYS) SYS.helpers.track(p, 'death', 1);
  if (killer) {
    try { eventOnPvpKill(killer); } catch (e) { console.error('eventOnPvpKill', e); }
    killer.c.pvpKills = (killer.c.pvpKills || 0) + 1; p.c.pvpDeaths = (p.c.pvpDeaths || 0) + 1;
    if (SYS) SYS.onPvpKill(killer, p);
    p.room.send({ t: 'msg', k: 'pvp_kill', a: killer.c.name, b: p.c.name }); markDirty(killer); saveSoon(killer);
    DB.log('pvp', { killer: killer.c.name, victim: p.c.name, map: p.room.key });
  }
  for (const m of p.room.mons) if (m.target === p.id) { m.target = null; m.state = 'return'; }
  if (p.ws) p.ws.send({ t: 'dead', lost, by: killer ? killer.c.name : null });
  markDirty(p);
  setTimeout(() => {
    if (!p.room) return;
    p.dead = false; p.hp = S.maxHp(p.c); p.mp = S.maxMp(p.c); p.act = null; p.actN++;
    p.x = rand(-2, 2); p.z = 4; if (p.ws) p.ws.send({ t: 'revive', x: p.x, z: p.z });
  }, 4000);
}
const BUILD = '2026-10-11-mu-legends-v1';   // conferir no log, em /api/stats e no jogo se esta versão está no ar
const SET_DROP = Math.min(.008, Math.max(0, +(process.env.SET_DROP || .008))), EGG_DROP = Math.min(.02, Math.max(0, +(process.env.EGG_DROP || .015))); // HARD: set 0,8% máx.; ovos 1,5% padrão, sem env tornar o drop fácil
function killMonster(room, m, killer) {
  try { eventOnKill(killer, m); } catch (e) { console.error('eventOnKill', e); }
  try { if (SYS) SYS.onKill(killer, m, room); } catch (e) { console.error('sys onKill', e); }
  if (m.invader && !m.boss) { try { killer.c.gold += m.lvl * 6; if (SYS) { SYS.onEvent(killer, 3); SYS.onGold(killer, m.lvl * 6); } if (Math.random() < .08) killer.c.crystals = (killer.c.crystals || 0) + 1; } catch (e) { console.error('invader', e); } }
  m.alive = false; m.respawnT = m.boss ? (room.cfg.boost ? room.cfg.boost.respawn : (m.def.respawn || 12)) : 2; m.target = null; // monstros comuns renascem em 2 segundos; chefes mantêm o temporizador próprio
  const base = Math.round(m.lvl * m.lvl * 1.8 + 8);
  if (m.boss) { bossRewards(room, m, killer, base); return; }
  let group = [killer];
  if (killer.party) group = killer.party.members.map(id => byChar.get(id)).filter(q => q && q.room === room && !q.dead && !q.ghost && dist(q, m) < 40);
  if (!group.includes(killer)) group.push(killer);
  const total = base * (1 + .15 * (group.length - 1));
  const bst = room.cfg.boost;
  for (const q of group) { let xp = Math.max(1, Math.round(total / group.length * clamp(1 - (q.c.lvl - m.lvl - 5) * .12, .1, 1))); if (bst) xp = boostXp(q, xp, bst); gainXp(q, xp); }
  const owners = group.map(q => q.id);
  spawnDrop(room, m, 'gold', Math.round(m.lvl * rand(4, 9) + 3), owners);
  if (Math.random() < .22) spawnDrop(room, m, Math.random() < .6 ? 'hpPot' : 'mpPot', 1, owners);
  const km = S.mods(killer.c);   // bônus da árvore (Fortuna): itens raros, item extra
  if (Math.random() < Math.min(.05, .045 * (SYS ? SYS.dropMul(killer.c) : 1))) {
    spawnDrop(room, m, 'item', genItem(m.lvl, false, killer.c.cls, km.rare), owners);
    if (Math.random() < km.qty) spawnDrop(room, m, 'item', genItem(m.lvl, false, killer.c.cls, km.rare), owners);   // "Mãos Largas": item extra
  }
  if (Math.random() < .035) spawnDrop(room, m, 'crystal', 1, owners);
  if (Math.random() < Math.min(.012, SET_DROP * (1 + km.rare))) spawnDrop(room, m, 'item', S.genSetDrop(m.lvl, killer.c.cls), owners);   // HARD: peças dos sets são raras (0,8% base, máximo 1,2%)
}
function bossRewards(room, m, killer, base) {
  const list = [...m.dmgBy.entries()].sort((a, b) => b[1] - a[1]);
  const total = list.reduce((s, e) => s + e[1], 0) || 1;
  const rank = list.slice(0, 10).map(([cid, d]) => { const q = byChar.get(cid); return { name: q ? q.c.name : '?', dmg: Math.round(d), pct: Math.round(d / total * 100) }; });
  list.forEach(([cid, d], i) => {
    const q = byChar.get(cid); if (!q || q.room !== room) return;
    const share = d / total;
    gainXp(q, Math.round((base * 12 * Math.max(.05, share) + base) * (room.cfg.boost ? room.cfg.boost.xp : 1)));
    { const g = Math.round(2000 * share + 150); q.c.gold += g; if (SYS) SYS.onGold(q, g); } q.c.bossKills = (q.c.bossKills || 0) + 1;
    if (i === 0 || Math.random() < share * 2) { const it = genItem(m.lvl, true, q.c.cls); if (q.c.inv.length < S.INV_MAX) { q.c.inv.push(it); msgTo(q, 'loot_item', { it }); } }
    if (i < 3) { q.c.crystals += 3 - i; }
    if (Math.random() < Math.min(.012, SET_DROP * (1 + S.mods(q.c).rare)) && q.c.inv.length < S.INV_MAX) { const it = S.genSetDrop(m.lvl, q.c.cls); q.c.inv.push(it); msgTo(q, 'loot_item', { it }); }
    if (Math.random() < EGG_DROP * (1 + S.mods(q.c).egg) && q.c.inv.length < S.INV_MAX) { const it = S.makeEgg(S.EGG_PETS[randi(0, S.EGG_PETS.length - 1)]); q.c.inv.push(it); msgTo(q, 'loot_item', { it }); }
    markDirty(q); saveSoon(q);
  });
  for (let i = 0; i < 3; i++) spawnDrop(room, m, 'item', genItem(m.lvl, true, killer.c.cls), null);
  spawnDrop(room, m, 'gold', 3000, null);
  room.send({ t: 'boss', n: m.def.name, rank });
  broadcastAll({ t: 'chat', ch: 'sys', k: 'boss_dead', n: m.def.name, by: rank[0] ? rank[0].name : killer.c.name, map: room.map });
  DB.log('boss', { boss: m.def.name.pt, room: room.key, rank });
}
function genItem(lvl, boss, cls, rareBonus) {
  const slot = S.SLOTS[randi(0, S.SLOTS.length - 1)];
  const tier = boss ? 5 : clamp(1 + Math.floor(lvl / 7) + (Math.random() < .15 ? 1 : 0), 1, 5);
  const r = Math.random(); let plus = r < .6 ? 0 : r < .85 ? 1 : r < .95 ? 2 : 3; if (boss) plus += 3;
  return S.makeItem(slot, tier, plus, boss || Math.random() < .12 * (1 + (rareBonus || 0)), cls);
}
// Fenda do Caos: multiplicador do mapa + frenesi (abates seguidos somam XP) + cura de vida e mana a cada abate
function boostXp(q, xp, b) {
  const t = now(); q.cbN = (q.cbT && t - q.cbT < b.window * 1000) ? Math.min(b.max, (q.cbN || 0) + 1) : 1; q.cbT = t;
  const mul = b.xp * (1 + b.per * (q.cbN - 1));
  q.hp = Math.min(S.maxHp(q.c), q.hp + S.maxHp(q.c) * b.heal); q.mp = Math.min(S.maxMp(q.c), q.mp + S.maxMp(q.c) * b.heal);
  if (q.ws) q.ws.send({ t: 'combo', n: q.cbN, mul: Math.round(mul * 100) / 100, ms: b.window * 1000 });
  return Math.max(1, Math.round(xp * mul));
}
function gainXp(p, n) {
  if (typeof nightActive !== 'undefined' && nightActive && currentEvent && currentEvent.id === 'nightdead') n *= 5;
  if (SYS) n = Math.round(n * SYS.xpMul(p.c));
  if (p.c.lvl >= S.MAX_LVL) { p.c.xp = 0; return; }   // nível máximo: use o Reset
  p.c.xp += n; if (p.ws) p.ws.send({ t: 'fx', e: 'xp', v: n });
  while (p.c.lvl < S.MAX_LVL && p.c.xp >= S.xpNeed(p.c.lvl)) {
    p.c.xp -= S.xpNeed(p.c.lvl); p.c.lvl++; p.c.points += 5; p.hp = S.maxHp(p.c); p.mp = S.maxMp(p.c);
    p.room.fx({ e: 'lvl', p: p.id, l: p.c.lvl }); saveSoon(p); if (SYS) SYS.onLevel(p);
    if (p.c.guild) { const g = guilds.get(p.c.guild.toLowerCase()); const mm = g && g.members.find(x => x.id === p.charId); if (mm) { mm.lvl = p.c.lvl; DB.saveGuild(g); } }
  }
  markDirty(p);
}
function aoe(p, x, z, r, mult, extra, exclude) {
  const room = p.room; if (!room) return; const base = S.atk(p.c) * mult;
  for (const m of room.mons) if (m.alive && m !== exclude && Math.hypot(m.x - x, m.z - z) <= r + m.radius) { hitMonster(room, p, m, base); if (extra) extra(m); }
  if (p.pvp) for (const q of room.players.values()) if (q !== exclude && canPvp(p, q) && Math.hypot(q.x - x, q.z - z) <= r + .5) { hitPlayer(p, q, base); }
}
const later = (p, ms, fn) => setTimeout(() => { try { if (p.room && !p.dead) fn(); } catch (e) { console.error('later', e); } }, ms);
const aoe2 = (dm, p, x, z, r, mult, ...rest) => aoe(p, x, z, r, mult * dm, ...rest);
function useSkill(p, i, msg) {
  const sk = (S.SKILLS[p.c.cls] || [])[i | 0]; if (!sk || p.dead) return;
  const t = now(); if (t < (p.skillCd[i] || 0) - 150) return;
  if (p.mp < sk.mp) { msgTo(p, 'no_mana'); return; }
  let tg = null;
  if (sk.target) {
    tg = resolveTarget(p, msg); if (!tg) { msgTo(p, 'no_target'); return; }
    if (Math.hypot(tg.x - p.x, tg.z - p.z) - tg.radius > sk.range + 2) { msgTo(p, 'out_range'); return; }
    p.h = Math.atan2(tg.x - p.x, tg.z - p.z);
  }
  const tm = S.mods(p.c), dm = 1 + (i | 0 ? tm.s1 : tm.s0);
  p.mp -= sk.mp; p.skillCd[i] = t + sk.cd * 1000 * clamp(1 - tm.cd, .4, 1); p.act = sk.anim; p.actN++; p.lastSkillKey = sk.key; if (SYS) SYS.onSkill(p);
  const room = p.room, A = 1, fx = o => room.fx(o);
  switch (sk.key) {
    case 'spin': later(p, 350, () => { fx({ e: 'ring', x: p.x, z: p.z, r: 4.4, c: 0xff6a1a }); aoe2(dm, p, p.x, p.z, 4.4, 1.9); }); break;
    case 'dash': {
      const dx = tg.x - p.x, dz = tg.z - p.z, len = Math.hypot(dx, dz) || 1, k = Math.max(0, len - (tg.radius + .8)) / len;
      p.x += dx * k; p.z += dz * k; p.lastMove = t; if (p.ws) p.ws.send({ t: 'tp', x: p.x, z: p.z, dash: 1 });
      fx({ e: 'ring', x: p.x, z: p.z, r: 2.6, c: 0xffee88 });
      later(p, 180, () => { hitTarget(p, tg, (S.atk(p.c) * dm) * 2.6); aoe2(dm, p, p.x, p.z, 2.6, 1, null, tg.o); }); break; }
    case 'comet': { const x = tg.x, z = tg.z; fx({ e: 'meteor', x, z, c: 0x6fb8ff }); later(p, 450, () => aoe2(dm, p, x, z, 5, 2.4)); break; }
    case 'nova': later(p, 400, () => { fx({ e: 'ring', x: p.x, z: p.z, r: 6.5, c: 0x88e0ff }); aoe2(dm, p, p.x, p.z, 6.5, 1.5, m => { m.slowT = 3.5; }); }); break;
    case 'triple': case 'orbs': {
      const kind = sk.key === 'triple' ? 'arrow' : 'void', mult = sk.key === 'triple' ? 1.45 : 1.3;
      const list = [tg];
      if (tg.kind === 'm') for (const m of room.mons.filter(m => m.alive && m !== tg.o && Math.hypot(m.x - p.x, m.z - p.z) < 12).sort((a, b) => Math.hypot(a.x - p.x, a.z - p.z) - Math.hypot(b.x - p.x, b.z - p.z)).slice(0, 2)) list.push({ kind: 'm', o: m });
      while (list.length < 3) list.push(tg);
      list.forEach(x => fx({ e: 'proj', p: p.id, [x.kind === 'm' ? 'm' : 'q']: x.kind === 'm' ? x.o.id : x.o.id, k: kind }));
      later(p, 280, () => list.forEach(x => hitTarget(p, x, (S.atk(p.c) * dm) * mult))); break; }
    case 'rain': { const x = tg.x, z = tg.z; fx({ e: 'ring', x, z, r: 5, c: 0x7aee5a }); later(p, 550, () => { fx({ e: 'col', x, z, c: 0x7aee5a }); aoe2(dm, p, x, z, 5, 1.9); }); break; }
    case 'astral': later(p, 500, () => { fx({ e: 'ring', x: p.x, z: p.z, r: 4.5, c: 0xb98aff }); aoe2(dm, p, p.x, p.z, 4.5, 2); }); break;
    case 'rune': { const x = tg.x, z = tg.z; fx({ e: 'ring', x, z, r: 4, c: 0x7aa8ff }); later(p, 350, () => { fx({ e: 'col', x, z, c: 0xa46bff }); aoe2(dm, p, x, z, 4, 2.3); }); break; }
    case 'quake': later(p, 600, () => { fx({ e: 'ring', x: p.x, z: p.z, r: 5.5, c: 0xff2030 }); fx({ e: 'col', x: p.x, z: p.z, c: 0xff3040 }); aoe2(dm, p, p.x, p.z, 5.5, 2.1, m => { m.slowT = 2; }); }); break;
    case 'blood': later(p, 300, () => {
      if (tg.kind === 'm' && !tg.o.alive) return;
      const before = tg.o.hp; hitTarget(p, tg, (S.atk(p.c) * dm) * 3);
      const h = Math.round(Math.max(0, before - Math.max(0, tg.o.hp)) * .25);
      if (h > 0) { p.hp = Math.min(S.maxHp(p.c), p.hp + h); fx({ e: 'heal', p: p.id, v: h }); } }); break;
    case 'wolf': { const x = tg.x, z = tg.z; later(p, 600, () => { fx({ e: 'ring', x, z, r: 3.5, c: 0xb05aff }); fx({ e: 'col', x, z, c: 0xb05aff }); aoe2(dm, p, x, z, 3.5, 2.4); }); break; }
  }
}
function basicAttack(p, msg) {
  if (p.dead) return; p.lastSkillKey = null; const tg = resolveTarget(p, msg); if (!tg) return;
  const t = now(), cls = S.CLASSES[p.c.cls];
  if (t - p.lastAtk < S.atkInterval(p.c) * 1000 * .78) return;
  if (Math.hypot(tg.x - p.x, tg.z - p.z) > cls.range + tg.radius + 2) return;
  p.lastAtk = t; p.act = 'attack'; p.actN++; p.h = Math.atan2(tg.x - p.x, tg.z - p.z);
  if (cls.proj) p.room.fx({ e: 'proj', p: p.id, [tg.kind === 'm' ? 'm' : 'q']: tg.o.id, k: cls.proj });
  later(p, cls.proj ? 300 : 220, () => hitTarget(p, tg, S.atk(p.c)));
}

/* ---------- drops ---------- */
function spawnDrop(room, at, kind, payload, owners) {
  const id = room.dropSeq++;
  room.drops.set(id, { id, x: at.x + rand(-1, 1), z: at.z + rand(-1, 1), kind, payload, born: now(), owners, until: now() + 10000 });
  room.dropsDirty = true;
}
const dropList = r => [...r.drops.values()].map(d => ({ id: d.id, x: r1(d.x), z: r1(d.z), k: d.kind, r: d.kind === 'item' && d.payload.rare ? 1 : 0 }));
function tryPickup(p, d) {
  const c = p.c;
  if (SYS && SYS.pickOk && !SYS.pickOk(p, d)) return false;   // filtro de coleta do jogador (por tipo ou nome)
  if (d.kind === 'gold') { const g = SYS ? Math.round(d.payload * SYS.goldMul(c)) : d.payload; c.gold += g; if (p.ws) p.ws.send({ t: 'fx', e: 'gold', v: g }); if (SYS) SYS.onGold(p, g); }
  else if (d.kind === 'hpPot') { c.hpPot++; msgTo(p, 'loot_hp'); }
  else if (d.kind === 'mpPot') { c.mpPot++; msgTo(p, 'loot_mp'); }
  else if (d.kind === 'crystal') { c.crystals += d.payload; msgTo(p, 'loot_crystal', { n: d.payload }); }
  else { if (c.inv.length >= S.INV_MAX) { if (!d.warned) d.warned = new Set(); if (!d.warned.has(p.id)) { d.warned.add(p.id); msgTo(p, 'inv_full'); } return false; }
    c.inv.push(d.payload); msgTo(p, 'loot_item', { it: d.payload }); saveSoon(p); }
  markDirty(p); return true;
}

/* ---------- laço do servidor (10 Hz) ---------- */
// destino de passeio: perto do ponto de nascimento, sempre fora da cidade e dentro do mundo
function wanderSpot(m, spread) {
  const sp = spread || 11; let x = m.sx + rand(-sp, sp), z = m.sz + rand(-sp, sp), r = Math.hypot(x, z);
  const lo = S.TOWN_R + 4, hi = S.WORLD_R - 3;
  if (r < lo) { const k = lo / Math.max(r, .1); x *= k; z *= k; if (r < .1) { x = lo; z = 0; } }
  else if (r > hi) { const k = hi / r; x *= k; z *= k; }
  return [x, z];
}
function stepToward(m, tx, tz, sp, dt) {
  const dx = tx - m.x, dz = tz - m.z, len = Math.hypot(dx, dz); if (len < .05) return false;
  const st = Math.min(len, sp * dt), nx = m.x + dx / len * st, nz = m.z + dz / len * st, rr = Math.hypot(nx, nz);
  m.h = Math.atan2(dx, dz); if (rr < S.TOWN_R + 1 || rr > S.WORLD_R) return false; m.x = nx; m.z = nz; return true;
}
function tickRoom(r, dt, t) {
  for (const p of r.players.values()) regen(p, dt);
  for (const m of r.mons) {
    if (!m.alive) { m.respawnT -= dt; if (m.respawnT <= 0) r.respawn(m); continue; }
    m.atkCd -= dt; m.slowT -= dt;
    const sp = m.def.speed * (m.slowT > 0 ? .45 : 1);
    // monstro atacado recentemente reage a quem bateu: não desiste (sem coleira curta) e não cura enquanto apanha
    const hp0 = (m.hurtT && t - m.hurtT < 12000) ? r.players.get(m.hurtBy) : null, hurtOk = !!hp0 && !hp0.dead && !hp0.ghost && !inSafe(hp0) && dist(hp0, m) < 70;
    let tp = m.target != null ? r.players.get(m.target) : null;
    if (tp && (tp.dead || tp.ghost || inSafe(tp))) { tp = null; m.target = null; if (m.state === 'chase') m.state = 'idle'; }   // jogador entrou na zona segura: o monstro só para (antes voltava para casa e curava 50%/s)
    if (!tp && hurtOk) { tp = hp0; m.target = hp0.id; m.state = 'chase'; }
    { const rr = Math.hypot(m.x, m.z); if (rr < S.TOWN_R + 1) { const k = (S.TOWN_R + 2) / Math.max(rr, .1); m.x *= k; m.z *= k; } }   // nunca fica preso dentro da cidade
    if (!tp && (m.def.aggro || m.invader) && m.state !== 'return') {
      let best = null, bd = m.invader ? 13 : 8;
      for (const p of r.players.values()) { if (p.dead || p.ghost || inSafe(p)) continue; const d = dist(p, m); if (d < bd) { bd = d; best = p; } }
      if (best) { tp = best; m.target = best.id; m.state = 'chase'; }
    }
    if (tp && m.state === 'chase') {
      if (Math.hypot(m.x - m.sx, m.z - m.sz) > (hurtOk ? 90 : (m.boss ? 22 : 28))) { m.state = 'return'; m.target = null; }
      else {
        const d = dist(m, tp), reach = m.radius + 1.3;
        if (d > reach) stepToward(m, tp.x, tp.z, sp * 1.15, dt);
        else { m.h = Math.atan2(tp.x - m.x, tp.z - m.z);
          if (m.atkCd <= 0) { const enr = m.boss && m.hp < m.maxHp * .5; m.atkCd = (m.def.atkSpd || 1.5) * (enr ? .75 : 1); m.atkN++; hurtPlayer(tp, m.dmg * (SYS ? SYS.monDmgMul() : 1), null, false, true); } }
        if (m.boss) { m.specialT -= dt; if (m.specialT <= 0) { const enr = m.hp < m.maxHp * .5; m.specialT = enr ? 4.5 : 7; const cx = m.x, cz = m.z;
          r.fx({ e: 'ring', x: cx, z: cz, r: enr ? 7 : 5.5, c: enr ? 0xff3030 : 0x55ff88, d: 1 });
          setTimeout(() => { if (!m.alive) return; for (const p of r.players.values()) if (!p.dead && !p.ghost && Math.hypot(p.x - cx, p.z - cz) < (enr ? 7.3 : 5.8)) hurtPlayer(p, m.dmg * 1.4, null, false, true); }, 900); } }
      }
    } else if (m.state === 'return' || (m.state === 'chase' && !tp)) {
      m.state = 'return'; m.hp = Math.min(m.maxHp, m.hp + m.maxHp * dt * .08);   // volta para casa curando devagar (antes 50%/s)
      if (Math.hypot(m.x - m.sx, m.z - m.sz) < 1) { m.state = 'idle'; m.hp = m.maxHp; if (m.dmgBy) m.dmgBy.clear(); m.blockT = 0; }
      else if (!stepToward(m, m.sx, m.sz, sp * 1.5, dt)) { m.blockT = (m.blockT || 0) + dt; if (m.blockT > 2) { m.state = 'idle'; m.blockT = 0; } }
      else m.blockT = 0;
    } else {
      if (m.hp < m.maxHp && !(m.hurtT && t - m.hurtT < 10000)) m.hp = Math.min(m.maxHp, m.hp + m.maxHp * dt * .03);   // parado e sem apanhar: recupera aos poucos
      m.timer -= dt; if (m.timer <= 0) { m.timer = rand(2.5, 6); const w = wanderSpot(m); m.wx = w[0]; m.wz = w[1]; }
      if (m.wx != null && (Math.hypot(m.x - m.wx, m.z - m.wz) < .4 || !stepToward(m, m.wx, m.wz, sp * .55, dt))) { if (m.wx != null && Math.hypot(m.x - m.wx, m.z - m.wz) >= .4) m.timer = 0; m.wx = null; }   // bloqueado: escolhe outro destino já no próximo ciclo
    }
    // vigia: monstro que deveria andar (passeio ou perseguição) mas não saiu do lugar por muito tempo
    { const mv = Math.hypot(m.x - (m.lx ?? m.x), m.z - (m.lz ?? m.z)); m.lx = m.x; m.lz = m.z;
      const wants = m.state === 'chase' || m.state === 'return' || m.wx != null;
      if (wants && mv < .002) m.stillT = (m.stillT || 0) + dt; else m.stillT = 0;
      if (m.stillT > 5) { m.stillT = 0; const w = wanderSpot(m, 14); m.sx = w[0]; m.sz = w[1]; if (m.state === 'return' || m.state === 'chase') { m.state = 'idle'; m.target = null; m.hurtT = 0; } m.wx = w[0]; m.wz = w[1]; }
    }
  }
  for (const d of r.drops.values()) {
    if (t - d.born > 120000) { r.drops.delete(d.id); r.dropsDirty = true; continue; }
    if (t - d.born < 350) continue;
    for (const p of r.players.values()) {
      if (p.dead || p.ghost || Math.hypot(p.x - d.x, p.z - d.z) > 1.9) continue;
      if (d.owners && t < d.until && !d.owners.includes(p.id)) continue;
      if (tryPickup(p, d)) { r.drops.delete(d.id); r.dropsDirty = true; break; }
    }
  }
  // fotografia do mundo para cada jogador (só o que está por perto)
  const list = [...r.players.values()].filter(p => !p.ghost);
  for (const p of list) {
    if (!p.ws) continue;
    const ps = [], ms = [];
    for (const q of list) if (q === p || dist(q, p) < 80) ps.push([q.id, r1(q.x), r1(q.z), r2(q.h), Math.ceil(q.hp), S.maxHp(q.c), Math.floor(q.mp), S.maxMp(q.c), q.dead ? 1 : 0, (q.moving && now() - q.lastMove < 600) ? 1 : 0, q.act || '', q.actN, q.party ? q.party.id : 0, q.pvp ? 1 : 0, q.c.lvl]);
    for (const m of r.mons) if (dist(m, p) < 62) ms.push([m.id, r1(m.x), r1(m.z), r2(m.h), Math.max(0, Math.ceil(m.hp)), m.alive ? 1 : 0, m.atkN, m.state === 'return' ? 1 : 0]);
    p.ws.send({ t: 's', p: ps, m: ms });
    if (p.dirty) { p.dirty = false; p.ws.send({ t: 'me', c: p.c }); }
  }
  if (r.dropsDirty) { r.dropsDirty = false; r.send({ t: 'drops', d: dropList(r) }); }
}
let lastTick = now();
setInterval(() => {
  const t = now(), dt = Math.min(.25, (t - lastTick) / 1000); lastTick = t;
  for (const [k, r] of rooms) {
    if (!r.players.size && t - r.emptySince > 300000 && r.ch > 1) { rooms.delete(k); log('[canal]', k, 'fechado'); continue; }
    if (!r.players.size && t - r.emptySince > 60000) continue; // canal vazio fica congelado
    try { tickRoom(r, dt, t); } catch (e) { console.error('tickRoom', k, e); }
  }
  for (const p of byChar.values()) if (p.ghost && t - p.offlineAt > GRACE) removePlayer(p);
}, 100);
setInterval(() => { for (const pt of parties.values()) sendParty(pt); }, 1000);
setInterval(() => { for (const p of byChar.values()) saveNow(p); }, 30000);

/* ---------- persistência ---------- */
function saveNow(p) { p.saveTimer = null; return DB.saveChar(p.charId, p.c).catch(e => console.error('save', e.message)); }
function saveSoon(p) { if (!p.saveTimer) p.saveTimer = setTimeout(() => saveNow(p), 3000); }
function removePlayer(p) {
  saveNow(p); leaveRoom(p); byChar.delete(p.charId);
  if (p.party) partyLeave(p, true);
  if (p.c.guild) sendGuild(guilds.get(p.c.guild.toLowerCase()));
}
function broadcastAll(o) { const s = JSON.stringify(o); for (const p of byChar.values()) if (p.ws) p.ws.send(s); }

/* ---------- grupo (party) ---------- */
function sendParty(pt) {
  if (!pt) return;
  const members = pt.members.map(id => { const q = byChar.get(id); return q ? { id: q.id, cid: id, name: q.c.name, cls: q.c.cls, lvl: q.c.lvl, hp: Math.ceil(q.hp), mhp: S.maxHp(q.c), map: q.room ? q.room.map : null, ch: q.room ? q.room.ch : 0, x: r1(q.x), z: r1(q.z), on: !!q.ws } : null; }).filter(Boolean);
  for (const id of pt.members) { const q = byChar.get(id); if (q && q.ws) q.ws.send({ t: 'party', id: pt.id, leader: pt.leader, members }); }
}
function partyLeave(p, silent) {
  const pt = p.party; if (!pt) return;
  pt.members = pt.members.filter(id => id !== p.charId); p.party = null; if (p.ws) p.ws.send({ t: 'party', id: 0 });
  if (pt.members.length <= 1) { for (const id of pt.members) { const q = byChar.get(id); if (q) { q.party = null; if (q.ws) q.ws.send({ t: 'party', id: 0 }); msgTo(q, 'party_gone'); } } parties.delete(pt.id); return; }
  if (pt.leader === p.charId) pt.leader = pt.members[0];
  sendParty(pt);
}

/* ---------- guildas ---------- */
function sendGuild(g) {
  if (!g) return;
  const info = { t: 'guild', name: g.name, leader: g.leader, members: g.members.map(m => { const q = byChar.get(m.id); return { id: m.id, name: m.name, rank: m.rank, lvl: q ? q.c.lvl : m.lvl, on: !!(q && q.ws) }; }) };
  for (const m of g.members) { const q = byChar.get(m.id); if (q && q.ws) q.ws.send(info); }
}
function guildOf(p) { return p.c.guild ? guilds.get(p.c.guild.toLowerCase()) : null; }
function rankOf(g, cid) { const m = g.members.find(x => x.id === cid); return m ? m.rank : null; }
async function setCharGuild(cid, gname) {
  const q = byChar.get(cid);
  if (q) { q.c.guild = gname; markDirty(q); saveSoon(q); if (q.room) q.room.send({ t: 'join', p: playerInfo(q) }, q); return; }
  const row = await DB.charById(cid); if (row) { row.data.guild = gname; await DB.saveChar(cid, row.data); }
}

/* ---------- chat ---------- */
const clean = s => String(s || '').replace(/[\u0000-\u001f\u007f]/g, '').trim().slice(0, 140);
function chat(p, msg) {
  const text = clean(msg.text); if (!text) return;
  const t = now(); if (t - p.lastChat < 600) { msgTo(p, 'slow_chat'); return; } p.lastChat = t;
  const out = { t: 'chat', ch: msg.ch, from: p.c.name, text };
  const deliver = q => { if (q.ws && !(q.c.blocked || []).includes(p.c.name.toLowerCase())) q.ws.send(out); };
  switch (msg.ch) {
    case 'global': for (const q of byChar.values()) deliver(q); break;
    case 'local': if (p.room) for (const q of p.room.players.values()) if (dist(q, p) < 40) deliver(q); break;
    case 'party': if (!p.party) { msgTo(p, 'no_party'); return; } for (const id of p.party.members) { const q = byChar.get(id); if (q) deliver(q); } break;
    case 'guild': { const g = guildOf(p); if (!g) { msgTo(p, 'no_guild'); return; } for (const m of g.members) { const q = byChar.get(m.id); if (q) deliver(q); } break; }
    case 'w': {
      const to = [...byChar.values()].find(q => q.c.name.toLowerCase() === String(msg.to || '').toLowerCase() && q.ws);
      if (!to) { msgTo(p, 'not_online', { n: msg.to }); return; }
      out.to = to.c.name; deliver(to); if (p.ws) p.ws.send(out); break; }
    default: return;
  }
}

/* ---------- mensagens do cliente ---------- */
const HANDLERS = {
  m(p, a) { // movimento [x,z,h,andando]
    if (p.dead || !Array.isArray(a)) return;
    let [x, z, h, mv] = a; x = +x; z = +z; h = +h; if (![x, z, h].every(Number.isFinite)) return;
    const t = now(), dt = Math.max(.05, (t - p.lastMove) / 1000); p.lastMove = t;
    const maxd = S.moveSpeed(p.c) * dt * 1.5 + .8, d = Math.hypot(x - p.x, z - p.z);
    if (d > maxd) { p.strikes = (p.strikes || 0) + 1; if (p.strikes > 20) { DB.log('speed', { name: p.c.name, d }); p.strikes = 0; } p.moving = false; if (p.ws) p.ws.send({ t: 'tp', x: p.x, z: p.z }); return; }
    const rr = Math.hypot(x, z); if (rr > S.WORLD_R) { x *= S.WORLD_R / rr; z *= S.WORLD_R / rr; }
    p.x = x; p.z = z; p.h = h; p.moving = !!mv;
  },
  a(p, msg) { basicAttack(p, msg || {}); },
  k(p, msg) { if (msg) useSkill(p, msg.i, msg); },
  pot(p, k) {
    if (p.dead || now() - p.lastPot < 550) return; p.lastPot = now(); const c = p.c;
    if (k === 'hp') { if (c.hpPot <= 0) { msgTo(p, 'no_hp_pot'); return; } c.hpPot--; const h = Math.round(S.maxHp(c) * .4); p.hp = Math.min(S.maxHp(c), p.hp + h); p.room.fx({ e: 'heal', p: p.id, v: h }); }
    else { if (c.mpPot <= 0) { msgTo(p, 'no_mp_pot'); return; } c.mpPot--; p.mp = Math.min(S.maxMp(c), p.mp + Math.round(S.maxMp(c) * .5)); }
    markDirty(p);
  },
  stat(p, m) {
    const k = m && m.k; if (!['str', 'agi', 'vit', 'ene'].includes(k)) return;
    if (p.c.stats[k] >= S.MAX_STAT) { msgTo(p, 'stat_max'); return; }
    const n = Math.min(+m.n | 0, p.c.points, S.MAX_STAT - p.c.stats[k]); if (n <= 0) return;
    p.c.stats[k] += n; p.c.points -= n; markDirty(p); saveSoon(p);
  },
  reset(p) {   // nível 1000 -> volta ao 1 ganhando pontos; mantém atributos, itens e equipamentos
    const c = p.c;
    if (c.lvl < S.MAX_LVL) { msgTo(p, 'need_max_lvl'); return; }
    if ((c.resets || 0) >= S.MAX_RESETS) { msgTo(p, 'max_resets'); return; }
    c.resets = (c.resets || 0) + 1; c.lvl = 1; c.xp = 0; c.points += S.STAT_PER_RESET;
    p.hp = S.maxHp(c); p.mp = S.maxMp(c); markDirty(p); saveNow(p);
    if (SYS) SYS.onReset(p);
    msgTo(p, 'reset_ok', { n: c.resets }); if (p.ws) p.ws.send({ t: 'me', c });
    DB.log('reset', { name: c.name, resets: c.resets });
  },
  equip(p, id) {
    const c = p.c, i = c.inv.findIndex(x => x.id === id); if (i < 0) return; const it = c.inv[i];
    if (it.slot === 'egg') { if (SYS && SYS.hatch) SYS.hatch(p, id); return; }   // 'equipar' um ovo choca o pet
    if (S.itemReq(it) > c.lvl) { msgTo(p, 'need_lvl_item'); return; }
    if (it.slot === 'arma' && it.cls && it.cls !== c.cls) { msgTo(p, 'wrong_class'); return; }
    const old = c.equip[it.slot]; c.equip[it.slot] = it; c.inv.splice(i, 1); if (old) c.inv.push(old);
    p.hp = Math.min(p.hp, S.maxHp(c)); markDirty(p); saveNow(p);
    if (it.slot === 'asas' && p.room) p.room.send({ t: 'wings', id: p.id, asas: wingInfo(c) }, p);
    if (SYS && SYS.sendAp) SYS.sendAp(p);
  },
  unequip(p, slot) { const c = p.c; if (!c.equip[slot]) return; if (c.inv.length >= S.INV_MAX) { msgTo(p, 'inv_full'); return; } c.inv.push(c.equip[slot]); c.equip[slot] = null; markDirty(p); saveNow(p);
    if (slot === 'asas' && p.room) p.room.send({ t: 'wings', id: p.id, asas: null }, p);
    if (SYS && SYS.sendAp) SYS.sendAp(p); },
  refine(p, id) {
    const c = p.c; const it = c.inv.find(x => x.id === id) || Object.values(c.equip).find(x => x && x.id === id); if (!it) return;
    if (c.crystals < 1 || it.plus >= 12) return; c.crystals--;
    if (Math.random() < S.refineChance(it)) { it.plus++; msgTo(p, 'refine_ok', { it }); if (it.plus >= 9) DB.log('refine', { name: c.name, item: S.itemName(it) }); }
    else if (it.plus >= 6) { it.plus--; msgTo(p, 'refine_down', { it }); } else msgTo(p, 'refine_fail');
    markDirty(p); saveSoon(p);
  },
  sell(p, id) {
    if (Math.hypot(p.x - S.MERCHANT_POS.x, p.z - S.MERCHANT_POS.z) > 6) { msgTo(p, 'far_merchant'); return; }
    const c = p.c, i = c.inv.findIndex(x => x.id === id); if (i < 0) return; const it = c.inv[i];
    if (it.bound) { msgTo(p, 'bound'); return; }   // item sagrado/administrativo: não vende
    c.gold += S.itemPrice(it); c.inv.splice(i, 1); msgTo(p, 'sold', { it, g: S.itemPrice(it) }); markDirty(p); saveSoon(p);
  },
  discard(p, id) { const c = p.c, i = c.inv.findIndex(x => x.id === id); if (i >= 0) { c.inv.splice(i, 1); markDirty(p); saveSoon(p); } },
  buy(p, m) {
    // Compatibilidade: algumas versões antigas do cliente enviavam o equipamento
    // pelo mesmo comando `buy`, usando `id` em vez de `k`.
    if (m && m.id) return HANDLERS.buynpc(p, m);
    if (Math.hypot(p.x - S.MERCHANT_POS.x, p.z - S.MERCHANT_POS.z) > 6) { msgTo(p, 'far_merchant'); return; }
    const row = S.SHOP.find(s => s[0] === (m && m.k)); const n = clamp(+m.n | 0, 1, 50); if (!row) return;
    const cost = Math.round(row[3] * n * eventDiscount()); if (p.c.gold < cost) { msgTo(p, 'no_gold'); return; }
    p.c.gold -= cost; if (row[0] === 'hp') p.c.hpPot += n; else if (row[0] === 'mp') p.c.mpPot += n; else p.c.crystals += n;
    markDirty(p); saveSoon(p);
  },
  async buynpc(p, m) {
    // Compra AUTORITATIVA de equipamento. O servidor altera o personagem,
    // salva no PostgreSQL e envia o estado novo ao cliente.
    const id = String(m && m.id || '').trim();
    if (!id) { msgTo(p, 'buy_error'); return; }

    const src = S.NPC_ITEMS.find(it => String(it.id) === id);
    if (!src) { msgTo(p, 'buy_error'); console.warn('[SHOP] item inexistente:', id); return; }

    const c = p.c;
    const price = Math.round(Math.max(0, Number(src.price) || 0) * eventDiscount());
    const reqLvl = Math.max(1, Number(src.reqLvl) || 1);

    // A loja só pode ser aberta normalmente perto do mercador. Usamos uma
    // margem maior no servidor para evitar rejeitar a compra por pequena
    // diferença de posição entre cliente e servidor.
    const merchantDistance = Math.hypot(p.x - S.MERCHANT_POS.x, p.z - S.MERCHANT_POS.z);
    if (merchantDistance > 12) { msgTo(p, 'far_merchant'); return; }
    if (c.lvl < reqLvl) { msgTo(p, 'need_lvl', { n: reqLvl }); return; }
    if (Number(c.gold) < price) { msgTo(p, 'no_gold'); return; }
    if (!Array.isArray(c.inv)) c.inv = [];
    if (c.inv.length >= S.INV_MAX) { msgTo(p, 'inv_full'); return; }

    // Item comprado é uma cópia independente do catálogo.
    const it = Object.assign({}, src, {
      id: 'it_' + Date.now().toString(36) + '_' + crypto.randomBytes(6).toString('hex'),
    });
    delete it.price;
    delete it.reqLvl;
    delete it.cls_req;

    c.gold = Math.max(0, Number(c.gold) - price);
    c.inv.push(it);
    markDirty(p);

    // Persiste imediatamente para a compra não desaparecer ao relogar.
    try {
      await DB.saveChar(p.charId, c);
    } catch (e) {
      // Se o banco falhar, desfaz a operação para não cobrar o jogador sem item.
      c.inv.pop();
      c.gold += price;
      p.dirty = true;
      console.error('[SHOP] falha ao salvar compra:', e);
      msgTo(p, 'buy_error');
      return;
    }

    console.log('[SHOP] compra', c.name, id, 'preco=', price, 'ouro_restante=', c.gold, 'inv=', c.inv.length);

    // Confirmação da compra + estado autoritativo completo.
    msgTo(p, 'bought', { it, g: price });
    if (p.ws) p.ws.send({ t: 'me', c: p.c });
    p.dirty = false;
  },
  travel(p, map) {
    const cfg = S.MAPS[map]; if (!cfg || p.dead) return;
    if (p.c.lvl < cfg.minLvl) { msgTo(p, 'need_lvl', { n: cfg.minLvl }); return; }
    if (p.c.gold < cfg.cost) { msgTo(p, 'no_gold'); return; }
    p.c.gold -= cfg.cost; joinRoom(p, map); markDirty(p); saveSoon(p);
  },
  pvp(p, on) { if (p.c.lvl < 10) { msgTo(p, 'pvp_lvl'); return; } p.pvp = !!on; msgTo(p, on ? 'pvp_on' : 'pvp_off'); },
  chat(p, m) { if (m) chat(p, m); },
  block(p, name) {
    name = clean(name).toLowerCase(); if (!name) return; const b = p.c.blocked || (p.c.blocked = []);
    const i = b.indexOf(name); if (i >= 0) { b.splice(i, 1); msgTo(p, 'unblocked', { n: name }); } else if (b.length < 100) { b.push(name); msgTo(p, 'blocked', { n: name }); }
    markDirty(p); saveSoon(p);
  },
  // grupo
  pinv(p, m) {
    const q = m.id != null ? p.room && p.room.players.get(+m.id) : [...byChar.values()].find(x => x.ws && x.c.name.toLowerCase() === String(m.name || '').toLowerCase());
    if (!q || q === p) { msgTo(p, 'not_online', { n: m.name || '' }); return; }
    if (q.party) { msgTo(p, 'has_party', { n: q.c.name }); return; }
    if (p.party && p.party.members.length >= 5) { msgTo(p, 'party_full'); return; }
    if (p.party && p.party.leader !== p.charId) { msgTo(p, 'not_leader'); return; }
    q.invites.set('p' + p.charId, now()); if (q.ws) q.ws.send({ t: 'invite', kind: 'party', from: p.charId, name: p.c.name });
    msgTo(p, 'invite_sent', { n: q.c.name });
  },
  pans(p, m) {
    const key = 'p' + m.from; if (!p.invites.has(key)) return; p.invites.delete(key);
    const q = byChar.get(+m.from); if (!q) return;
    if (!m.ok) { msgTo(q, 'invite_no', { n: p.c.name }); return; }
    if (p.party) partyLeave(p, true);
    let pt = q.party; if (!pt) { pt = { id: partySeq++, leader: q.charId, members: [q.charId] }; parties.set(pt.id, pt); q.party = pt; }
    if (pt.members.length >= 5) { msgTo(p, 'party_full'); return; }
    pt.members.push(p.charId); p.party = pt; sendParty(pt);
    for (const id of pt.members) { const x = byChar.get(id); if (x) msgTo(x, 'party_join', { n: p.c.name }); }
  },
  pleave(p) { partyLeave(p); },
  pkick(p, cid) { const pt = p.party; if (!pt || pt.leader !== p.charId || cid === p.charId) return; const q = byChar.get(cid); if (q) { partyLeave(q); msgTo(q, 'kicked'); } },
  // guilda
  async gcreate(p, name) {
    name = clean(name); if (!/^[A-Za-zÀ-ÿ0-9 ]{3,16}$/.test(name)) { msgTo(p, 'guild_name'); return; }
    if (p.c.guild) { msgTo(p, 'has_guild'); return; } if (p.c.lvl < 10) { msgTo(p, 'guild_lvl'); return; }
    if (p.c.gold < 1000) { msgTo(p, 'no_gold'); return; } if (guilds.has(name.toLowerCase())) { msgTo(p, 'guild_taken'); return; }
    p.c.gold -= 1000; const g = { name, leader: p.charId, created: now(), members: [{ id: p.charId, name: p.c.name, rank: 'leader', lvl: p.c.lvl }] };
    guilds.set(name.toLowerCase(), g); await DB.saveGuild(g); await setCharGuild(p.charId, name); sendGuild(g); msgTo(p, 'guild_created', { n: name });
    DB.log('guild_create', { guild: name, by: p.c.name });
  },
  ginv(p, name) {
    const g = guildOf(p); if (!g) { msgTo(p, 'no_guild'); return; }
    if (!['leader', 'officer'].includes(rankOf(g, p.charId))) { msgTo(p, 'not_officer'); return; }
    if (g.members.length >= 30) { msgTo(p, 'guild_full'); return; }
    const q = [...byChar.values()].find(x => x.ws && x.c.name.toLowerCase() === String(name || '').toLowerCase());
    if (!q) { msgTo(p, 'not_online', { n: name }); return; } if (q.c.guild) { msgTo(p, 'has_guild_other', { n: q.c.name }); return; }
    q.invites.set('g' + g.name.toLowerCase(), now()); if (q.ws) q.ws.send({ t: 'invite', kind: 'guild', from: g.name, name: p.c.name });
    msgTo(p, 'invite_sent', { n: q.c.name });
  },
  async gans(p, m) {
    const key = 'g' + String(m.guild || '').toLowerCase(); if (!p.invites.has(key)) return; p.invites.delete(key);
    const g = guilds.get(String(m.guild).toLowerCase()); if (!g || !m.ok || p.c.guild) return;
    if (g.members.length >= 30) { msgTo(p, 'guild_full'); return; }
    g.members.push({ id: p.charId, name: p.c.name, rank: 'member', lvl: p.c.lvl }); await DB.saveGuild(g); await setCharGuild(p.charId, g.name); sendGuild(g);
    for (const mm of g.members) { const q = byChar.get(mm.id); if (q) msgTo(q, 'guild_join', { n: p.c.name }); }
  },
  async gleave(p) {
    const g = guildOf(p); if (!g) return;
    g.members = g.members.filter(m => m.id !== p.charId); await setCharGuild(p.charId, null); if (p.ws) p.ws.send({ t: 'guild', name: null });
    if (!g.members.length) { guilds.delete(g.name.toLowerCase()); await DB.deleteGuild(g.name); return; }
    if (g.leader === p.charId) { const nx = g.members.find(m => m.rank === 'officer') || g.members[0]; nx.rank = 'leader'; g.leader = nx.id; }
    await DB.saveGuild(g); sendGuild(g);
  },
  async gkick(p, cid) {
    const g = guildOf(p); if (!g) return; const me = rankOf(g, p.charId), them = rankOf(g, cid);
    if (!them || cid === p.charId || !(me === 'leader' || (me === 'officer' && them === 'member'))) { msgTo(p, 'not_officer'); return; }
    g.members = g.members.filter(m => m.id !== cid); await setCharGuild(cid, null); await DB.saveGuild(g); sendGuild(g);
    const q = byChar.get(cid); if (q) { msgTo(q, 'kicked_guild'); if (q.ws) q.ws.send({ t: 'guild', name: null }); }
  },
  async grank(p, m) {
    const g = guildOf(p); if (!g || g.leader !== p.charId) { msgTo(p, 'not_leader'); return; }
    const mm = g.members.find(x => x.id === m.id); if (!mm || mm.id === p.charId || !['officer', 'member'].includes(m.rank)) return;
    mm.rank = m.rank; await DB.saveGuild(g); sendGuild(g);
  },
};

/* ---------- conexão ---------- */
function onSocket(ws, ip) {
  sockets.add(ws); let p = null;
  const authTimer = setTimeout(() => { if (!p) ws.close(4001); }, 10000);
  ws.on('message', async raw => {
    let msg; try { msg = JSON.parse(raw); } catch (e) { return; }
    if (!p) {
      if (msg.t !== 'auth') return;
      const tok = verify(msg.token); if (!tok) { ws.send({ t: 'authfail', k: 'auth' }); ws.close(4001); return; }
      const cid = +msg.char; const row = byChar.get(cid) ? null : await DB.charById(cid);
      const live = byChar.get(cid);
      if (live) {
        if (live.accId !== tok.a) { ws.close(4003); return; }
        if (live.ws && live.ws !== ws) { live.ws.send({ t: 'kick', k: 'other_device' }); const old = live.ws; live.ws = null; old.close(4002); }
        p = live; p.ws = ws; p.ghost = false; p.offlineAt = null; clearTimeout(authTimer);
        if (SYS) SYS.onEnter(p);
        if (!p.room) joinRoom(p, p.c.map); else { sendInit(p); p.room.send({ t: 'join', p: playerInfo(p) }, p); }
        return;
      }
      if (!row || row.account_id !== tok.a) { ws.send({ t: 'authfail', k: 'no_char' }); ws.close(4003); return; }
      clearTimeout(authTimer);
      const c = row.data;
      for (const s of S.SLOTS) if (c.equip[s] === undefined) c.equip[s] = null;
      if (!Object.prototype.hasOwnProperty.call(c.equip,'asas')) c.equip.asas = null;
      if (c.resets === undefined) c.resets = 0;
      Object.assign(c, { pvpKills: c.pvpKills || 0, pvpDeaths: c.pvpDeaths || 0, bossKills: c.bossKills || 0, blocked: c.blocked || [] });
      if (c.guild && !guilds.has(c.guild.toLowerCase())) c.guild = null;
      let accRow = null; try { accRow = await DB.accountById(tok.a); } catch (e) {}
      p = { id: row.id, charId: row.id, accId: tok.a, role: (SYS && SYS.roleOf) ? SYS.roleOf(accRow) : null, ws, c, x: 0, z: 4, h: Math.PI, hp: S.maxHp(c), mp: S.maxMp(c), dead: false, moving: false,
        lastAtk: 0, lastMove: now(), lastPot: 0, lastChat: 0, skillCd: [0, 0], act: null, actN: 0, party: null, pvp: false, invites: new Map(), dirty: false, ghost: false };
      byChar.set(row.id, p);
      if (SYS) SYS.onEnter(p);
      const cfg = S.MAPS[c.map]; joinRoom(p, cfg && c.lvl >= cfg.minLvl ? c.map : 'valoria');
      broadcastAll({ t: 'chat', ch: 'sys', k: 'online', n: c.name });
      return;
    }
    if (p.ws !== ws) return;
    const h = HANDLERS[msg.t];
    if (h && p.room) { try { await h(p, msg.d); } catch (e) { console.error('handler', msg.t, e); } }
  });
  ws.on('close', () => {
    sockets.delete(ws); clearTimeout(authTimer);
    if (p && p.ws === ws) { p.ws = null; p.ghost = true; p.offlineAt = now(); p.moving = false; if (p.room) p.room.send({ t: 'leave', id: p.id }); saveNow(p); }
  });
}

/* =============================== INÍCIO =============================== */
(async () => {
  await DB.init();
  try { const SYSF = pickFile(__dirname, 'systems', '.js'); if (!SYSF) throw new Error('systems.js não encontrado na raiz'); SYS = require(SYSF)({ S, DB, byChar, rooms, HANDLERS, markDirty, saveNow, saveSoon, broadcastAll, now, log, genItem, hurtPlayer }); }
  catch (e) { console.error('[aviso] systems.js indisponível; o jogo roda sem os sistemas novos:', e.message); SYS = null; }
  for (const g of await DB.loadGuilds()) guilds.set(g.name.toLowerCase(), g);
  for (const m of S.MAP_ORDER) getRoom(m);
  server.listen(PORT, () => log(`Eternal Realms ouvindo na porta ${PORT} (banco: ${DB.kind()}) · versão ${BUILD}`));
})().catch(e => { console.error('Falha ao iniciar', e); process.exit(1); });
async function shutdown() { log('salvando antes de desligar…'); await Promise.all([...byChar.values()].map(saveNow)); process.exit(0); }
process.on('SIGTERM', shutdown); process.on('SIGINT', shutdown);
process.on('uncaughtException', e => console.error('[uncaughtException]', e));
process.on('unhandledRejection', e => console.error('[unhandledRejection]', e));

// ═══════════════════════════════════════════════════════════
// SISTEMA DE EVENTOS AUTOMÁTICOS — MuonlineClaude
// Cada evento tem uma mecânica real: pontos por abates, coleta de objetos, XP em dobro, desconto na loja.
// ═══════════════════════════════════════════════════════════
const EVENTS = {
  arena:         { name: 'Arena das Almas',    icon: '⚔️', duration: 8 * 60e3,  minPlayers: 1, cooldown: 90 * 60e3,  lastRun: 0, desc: 'Derrote o máximo de monstros! Quem somar mais pontos ganha prêmios.' },
  invasion:      { name: 'Invasão do Caos',    icon: '🌑', duration: 10 * 60e3, minPlayers: 1, cooldown: 60 * 60e3,  lastRun: 0, desc: 'Hordas das trevas invadem o mundo! Cada abate vale pontos em dobro.' },
  treasure:      { name: 'Caça ao Tesouro',    icon: '💰', duration: 6 * 60e3,  minPlayers: 1, cooldown: 45 * 60e3,  lastRun: 0, desc: 'Baús de tesouro surgiram pelo mapa. Toque neles antes dos outros!' },
  worldboss:     { name: 'Caçada aos Chefes',  icon: '🐉', duration: 15 * 60e3, minPlayers: 1, cooldown: 120 * 60e3, lastRun: 0, desc: 'Cada chefe derrotado vale 100 pontos! Una forças com outros jogadores.' },
  pvptournament: { name: 'Torneio PvP',        icon: '🏆', duration: 12 * 60e3, minPlayers: 2, cooldown: 100 * 60e3, lastRun: 0, desc: 'Ative o PvP e vença duelos: cada vitória vale 20 pontos!' },
  nightdead:     { name: 'Noite da Sabedoria', icon: '💀', duration: 7 * 60e3,  minPlayers: 1, cooldown: 75 * 60e3,  lastRun: 0, desc: 'Experiência 5× por tempo limitado! Aproveite para subir de nível.' },
  crystalrain:   { name: 'Chuva de Cristais',  icon: '💎', duration: 5 * 60e3,  minPlayers: 1, cooldown: 40 * 60e3,  lastRun: 0, desc: 'Cristais caíram do céu! Toque neles para coletar.' },
  merchant:      { name: 'Festa do Mercador',  icon: '🎪', duration: 10 * 60e3, minPlayers: 1, cooldown: 80 * 60e3,  lastRun: 0, desc: 'Todos os itens das lojas com 50% de desconto!' },
};
let currentEvent = null;   // { id, ev, endAt, scores: Map(playerId -> pts), names, objs: Map(objId -> {type,x,z}) }
let eventTimer = null;
let nightActive = false;

const onlinePlayers = () => [...byChar.values()].filter(p => p.ws && !p.ghost);
const eventDiscount = () => (currentEvent && currentEvent.id === 'merchant') ? .5 : 1;
function sysChat(msg, extra) { broadcastAll(Object.assign({ t: 'chat', ch: 'sys', msg }, extra || {})); }   // 'extra' deixa o cliente traduzir

function startEvent(id) {
  const ev = EVENTS[id]; if (!ev || currentEvent) return;
  if (onlinePlayers().length < ev.minPlayers) return;
  ev.lastRun = Date.now();
  currentEvent = { id, ev, endAt: Date.now() + ev.duration, scores: new Map(), names: new Map(), objs: new Map() };
  broadcastAll({ t: 'event_start', id, name: ev.name, icon: ev.icon, desc: ev.desc, duration: ev.duration });
  sysChat(`${ev.icon} EVENTO: ${ev.name} começou! ${ev.desc}`, { ev: 'start', id, icon: ev.icon });
  if (id === 'nightdead') { nightActive = true; broadcastAll({ t: 'night_start' }); }
  if (id === 'crystalrain') {
    const list = Array.from({ length: 20 }, (_, i) => ({ id: 'cr_' + i, x: Math.round((Math.random() - .5) * 200), z: Math.round((Math.random() - .5) * 200) }));
    list.forEach(o => currentEvent.objs.set(o.id, { type: 'crystal', x: o.x, z: o.z }));
    broadcastAll({ t: 'crystal_rain', crystals: list });
  }
  if (id === 'treasure') {
    const list = Array.from({ length: 8 }, (_, i) => ({ id: 'ch_' + i, x: Math.round((Math.random() - .5) * 180), z: Math.round((Math.random() - .5) * 180) }));
    list.forEach(o => currentEvent.objs.set(o.id, { type: 'chest', x: o.x, z: o.z }));
    broadcastAll({ t: 'treasure_spawn', chests: list });
  }
  eventTimer = setTimeout(() => { try { endEvent(); } catch (e) { console.error('endEvent', e); currentEvent = null; nightActive = false; } }, ev.duration);
}

function endEvent() {
  if (!currentEvent) return;
  const { id, ev, scores, names } = currentEvent;
  clearTimeout(eventTimer);
  const ranking = [...scores.entries()].filter(([, sc]) => sc > 0).sort((a, b) => b[1] - a[1]).slice(0, 3);
  const goldPrize = [5000, 2500, 1000], crystalPrize = [6, 4, 2];
  ranking.forEach(([pid, sc], i) => {
    const p = byChar.get(pid); if (!p) return;
    p.c.gold += goldPrize[i]; p.c.crystals = (p.c.crystals || 0) + crystalPrize[i];
    markDirty(p); saveNow(p);
    if (p.ws) p.ws.send({ t: 'event_prize', gold: goldPrize[i], crystals: crystalPrize[i], rank: i + 1 });
  });
  if (id === 'nightdead') { nightActive = false; broadcastAll({ t: 'night_end' }); }
  const top = ranking[0];
  const winnerName = top ? (names.get(top[0]) || '?') : null;
  broadcastAll({ t: 'event_end', id, name: ev.name, icon: ev.icon, winner: winnerName, topScore: top ? top[1] : 0 });
  sysChat(`${ev.icon} EVENTO ENCERRADO: ${ev.name}` + (winnerName ? ` — Campeão: ${winnerName} (${top[1]} pts)!` : ''), { ev: 'end', id, icon: ev.icon, w: winnerName, p: top ? top[1] : 0 });
  currentEvent = null;
}

function addEventScore(p, pts) {
  if (!currentEvent || !p || !(pts > 0)) return;
  const sc = (currentEvent.scores.get(p.id) || 0) + pts;
  currentEvent.scores.set(p.id, sc); currentEvent.names.set(p.id, p.c.name);
  if (SYS) SYS.onEvent(p, pts);
  broadcastAll({ t: 'event_score', pid: p.id, name: p.c.name, score: sc });
}
function eventOnKill(p, m) {
  if (!currentEvent || !p) return;
  const id = currentEvent.id, base = Math.max(1, Math.round(m.lvl / 5));
  if (id === 'arena' || id === 'nightdead') addEventScore(p, base);
  else if (id === 'invasion') addEventScore(p, base * 2);
  else if (id === 'worldboss') addEventScore(p, m.boss ? 100 : base);
}
function eventOnPvpKill(p) { if (currentEvent && currentEvent.id === 'pvptournament') addEventScore(p, 20); }

// Coleta de cristais e baús: o servidor valida se o objeto existe, se ainda não foi pego e se o jogador está perto
function handleEventCollect(p, m) {
  if (!currentEvent || !m || typeof m.id !== 'string') return;
  const o = currentEvent.objs.get(m.id); if (!o) return;
  if (Math.hypot(o.x - p.x, o.z - p.z) > 14) return;
  currentEvent.objs.delete(m.id);
  if (o.type === 'crystal') {
    const n = 1 + Math.floor(Math.random() * 3);
    p.c.crystals = (p.c.crystals || 0) + n; markDirty(p); saveNow(p);
    msgTo(p, 'loot_crystal', { n }); addEventScore(p, n * 5);
    broadcastAll({ t: 'crystal_collected', id: m.id, by: p.c.name });
  } else if (o.type === 'chest') {
    const gold = 500 + Math.floor(Math.random() * 2000), crystals = Math.floor(Math.random() * 5);
    p.c.gold += gold; p.c.crystals = (p.c.crystals || 0) + crystals; markDirty(p); saveNow(p);
    if (p.ws) p.ws.send({ t: 'fx', e: 'gold', v: gold });
    if (crystals) msgTo(p, 'loot_crystal', { n: crystals });
    addEventScore(p, Math.round(gold / 100));
    broadcastAll({ t: 'chest_opened', id: m.id, by: p.c.name });
  }
}

// ── Agenda (ciclo de 3 horas) ──
const EVENT_SCHEDULE = [[5, 'invasion'], [20, 'arena'], [35, 'treasure'], [50, 'crystalrain'], [65, 'nightdead'], [80, 'worldboss'],
  [100, 'pvptournament'], [120, 'merchant'], [140, 'invasion'], [155, 'arena'], [165, 'crystalrain']];
function checkEventSchedule() {
  if (currentEvent || !onlinePlayers().length) return;
  const nowMs = Date.now(), pos = nowMs % (180 * 60e3);
  for (const [min, id] of EVENT_SCHEDULE) {
    const ev = EVENTS[id], w = min * 60e3;
    if (ev && pos >= w && pos < w + 60e3 && nowMs - ev.lastRun > ev.cooldown) { console.log('[EVENT] iniciando', id); startEvent(id); return; }
  }
}
function checkEventWarnings() {
  if (currentEvent || !onlinePlayers().length) return;
  const nowMs = Date.now(), pos = nowMs % (180 * 60e3);
  for (const [min, id] of EVENT_SCHEDULE) {
    const ev = EVENTS[id], w = (min - 3) * 60e3;
    if (ev && w > 0 && pos >= w && pos < w + 60e3 && nowMs - ev.lastRun > ev.cooldown) sysChat(`${ev.icon} AVISO: ${ev.name} começa em 3 minutos!`, { ev: 'warn', id, icon: ev.icon });
  }
}
setInterval(() => { try { checkEventSchedule(); } catch (e) { console.error('schedule', e); } }, 60000);
setInterval(() => { try { checkEventWarnings(); } catch (e) { console.error('warnings', e); } }, 60000);

HANDLERS.event_collect = (p, m) => handleEventCollect(p, m);
HANDLERS.event_status = p => {
  if (currentEvent && p.ws) p.ws.send({ t: 'event_info', id: currentEvent.id, name: currentEvent.ev.name, icon: currentEvent.ev.icon,
    timeLeft: Math.max(0, currentEvent.endAt - Date.now()), score: currentEvent.scores.get(p.id) || 0 });
};
console.log('[EVENTS] sistema carregado:', Object.keys(EVENTS).join(', '));
